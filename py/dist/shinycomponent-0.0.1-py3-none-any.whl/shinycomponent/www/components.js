var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __esm = (fn2, res) => function __init() {
  return fn2 && (res = (0, fn2[__getOwnPropNames(fn2)[0]])(fn2 = 0)), res;
};
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i6 = decorators.length - 1, decorator; i6 >= 0; i6--)
    if (decorator = decorators[i6])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result)
    __defProp(target, key, result);
  return result;
};

// node_modules/preact/dist/preact.module.js
function h3(n8, l7) {
  for (var u5 in l7)
    n8[u5] = l7[u5];
  return n8;
}
function p2(n8) {
  var l7 = n8.parentNode;
  l7 && l7.removeChild(n8);
}
function y2(l7, u5, i6) {
  var t6, o8, r6, f4 = {};
  for (r6 in u5)
    "key" == r6 ? t6 = u5[r6] : "ref" == r6 ? o8 = u5[r6] : f4[r6] = u5[r6];
  if (arguments.length > 2 && (f4.children = arguments.length > 3 ? n5.call(arguments, 2) : i6), "function" == typeof l7 && null != l7.defaultProps)
    for (r6 in l7.defaultProps)
      void 0 === f4[r6] && (f4[r6] = l7.defaultProps[r6]);
  return d3(l7, f4, t6, o8, null);
}
function d3(n8, i6, t6, o8, r6) {
  var f4 = { type: n8, props: i6, key: t6, ref: o8, __k: null, __: null, __b: 0, __e: null, __d: void 0, __c: null, __h: null, constructor: void 0, __v: null == r6 ? ++u3 : r6 };
  return null == r6 && null != l4.vnode && l4.vnode(f4), f4;
}
function _2() {
  return { current: null };
}
function k2(n8) {
  return n8.children;
}
function b2(n8, l7) {
  this.props = n8, this.context = l7;
}
function g2(n8, l7) {
  if (null == l7)
    return n8.__ ? g2(n8.__, n8.__.__k.indexOf(n8) + 1) : null;
  for (var u5; l7 < n8.__k.length; l7++)
    if (null != (u5 = n8.__k[l7]) && null != u5.__e)
      return u5.__e;
  return "function" == typeof n8.type ? g2(n8) : null;
}
function m2(n8) {
  var l7, u5;
  if (null != (n8 = n8.__) && null != n8.__c) {
    for (n8.__e = n8.__c.base = null, l7 = 0; l7 < n8.__k.length; l7++)
      if (null != (u5 = n8.__k[l7]) && null != u5.__e) {
        n8.__e = n8.__c.base = u5.__e;
        break;
      }
    return m2(n8);
  }
}
function w2(n8) {
  (!n8.__d && (n8.__d = true) && t3.push(n8) && !x2.__r++ || o5 !== l4.debounceRendering) && ((o5 = l4.debounceRendering) || r4)(x2);
}
function x2() {
  var n8, l7, u5, i6, o8, r6, e9, c5;
  for (t3.sort(f2); n8 = t3.shift(); )
    n8.__d && (l7 = t3.length, i6 = void 0, o8 = void 0, e9 = (r6 = (u5 = n8).__v).__e, (c5 = u5.__P) && (i6 = [], (o8 = h3({}, r6)).__v = r6.__v + 1, L2(c5, r6, o8, u5.__n, void 0 !== c5.ownerSVGElement, null != r6.__h ? [e9] : null, i6, null == e9 ? g2(r6) : e9, r6.__h), M2(i6, r6), r6.__e != e9 && m2(r6)), t3.length > l7 && t3.sort(f2));
  x2.__r = 0;
}
function P2(n8, l7, u5, i6, t6, o8, r6, f4, e9, a5) {
  var h5, p4, y4, _4, b4, m4, w5, x5 = i6 && i6.__k || s5, P5 = x5.length;
  for (u5.__k = [], h5 = 0; h5 < l7.length; h5++)
    if (null != (_4 = u5.__k[h5] = null == (_4 = l7[h5]) || "boolean" == typeof _4 || "function" == typeof _4 ? null : "string" == typeof _4 || "number" == typeof _4 || "bigint" == typeof _4 ? d3(null, _4, null, null, _4) : v2(_4) ? d3(k2, { children: _4 }, null, null, null) : _4.__b > 0 ? d3(_4.type, _4.props, _4.key, _4.ref ? _4.ref : null, _4.__v) : _4)) {
      if (_4.__ = u5, _4.__b = u5.__b + 1, null === (y4 = x5[h5]) || y4 && _4.key == y4.key && _4.type === y4.type)
        x5[h5] = void 0;
      else
        for (p4 = 0; p4 < P5; p4++) {
          if ((y4 = x5[p4]) && _4.key == y4.key && _4.type === y4.type) {
            x5[p4] = void 0;
            break;
          }
          y4 = null;
        }
      L2(n8, _4, y4 = y4 || c3, t6, o8, r6, f4, e9, a5), b4 = _4.__e, (p4 = _4.ref) && y4.ref != p4 && (w5 || (w5 = []), y4.ref && w5.push(y4.ref, null, _4), w5.push(p4, _4.__c || b4, _4)), null != b4 ? (null == m4 && (m4 = b4), "function" == typeof _4.type && _4.__k === y4.__k ? _4.__d = e9 = C2(_4, e9, n8) : e9 = $3(n8, _4, y4, x5, b4, e9), "function" == typeof u5.type && (u5.__d = e9)) : e9 && y4.__e == e9 && e9.parentNode != n8 && (e9 = g2(y4));
    }
  for (u5.__e = m4, h5 = P5; h5--; )
    null != x5[h5] && ("function" == typeof u5.type && null != x5[h5].__e && x5[h5].__e == u5.__d && (u5.__d = A2(i6).nextSibling), q(x5[h5], x5[h5]));
  if (w5)
    for (h5 = 0; h5 < w5.length; h5++)
      O(w5[h5], w5[++h5], w5[++h5]);
}
function C2(n8, l7, u5) {
  for (var i6, t6 = n8.__k, o8 = 0; t6 && o8 < t6.length; o8++)
    (i6 = t6[o8]) && (i6.__ = n8, l7 = "function" == typeof i6.type ? C2(i6, l7, u5) : $3(u5, i6, i6, t6, i6.__e, l7));
  return l7;
}
function S3(n8, l7) {
  return l7 = l7 || [], null == n8 || "boolean" == typeof n8 || (v2(n8) ? n8.some(function(n9) {
    S3(n9, l7);
  }) : l7.push(n8)), l7;
}
function $3(n8, l7, u5, i6, t6, o8) {
  var r6, f4, e9;
  if (void 0 !== l7.__d)
    r6 = l7.__d, l7.__d = void 0;
  else if (null == u5 || t6 != o8 || null == t6.parentNode)
    n:
      if (null == o8 || o8.parentNode !== n8)
        n8.appendChild(t6), r6 = null;
      else {
        for (f4 = o8, e9 = 0; (f4 = f4.nextSibling) && e9 < i6.length; e9 += 1)
          if (f4 == t6)
            break n;
        n8.insertBefore(t6, o8), r6 = o8;
      }
  return void 0 !== r6 ? r6 : t6.nextSibling;
}
function A2(n8) {
  var l7, u5, i6;
  if (null == n8.type || "string" == typeof n8.type)
    return n8.__e;
  if (n8.__k) {
    for (l7 = n8.__k.length - 1; l7 >= 0; l7--)
      if ((u5 = n8.__k[l7]) && (i6 = A2(u5)))
        return i6;
  }
  return null;
}
function H2(n8, l7, u5, i6, t6) {
  var o8;
  for (o8 in u5)
    "children" === o8 || "key" === o8 || o8 in l7 || T2(n8, o8, null, u5[o8], i6);
  for (o8 in l7)
    t6 && "function" != typeof l7[o8] || "children" === o8 || "key" === o8 || "value" === o8 || "checked" === o8 || u5[o8] === l7[o8] || T2(n8, o8, l7[o8], u5[o8], i6);
}
function I2(n8, l7, u5) {
  "-" === l7[0] ? n8.setProperty(l7, null == u5 ? "" : u5) : n8[l7] = null == u5 ? "" : "number" != typeof u5 || a3.test(l7) ? u5 : u5 + "px";
}
function T2(n8, l7, u5, i6, t6) {
  var o8;
  n:
    if ("style" === l7)
      if ("string" == typeof u5)
        n8.style.cssText = u5;
      else {
        if ("string" == typeof i6 && (n8.style.cssText = i6 = ""), i6)
          for (l7 in i6)
            u5 && l7 in u5 || I2(n8.style, l7, "");
        if (u5)
          for (l7 in u5)
            i6 && u5[l7] === i6[l7] || I2(n8.style, l7, u5[l7]);
      }
    else if ("o" === l7[0] && "n" === l7[1])
      o8 = l7 !== (l7 = l7.replace(/Capture$/, "")), l7 = l7.toLowerCase() in n8 ? l7.toLowerCase().slice(2) : l7.slice(2), n8.l || (n8.l = {}), n8.l[l7 + o8] = u5, u5 ? i6 || n8.addEventListener(l7, o8 ? z2 : j2, o8) : n8.removeEventListener(l7, o8 ? z2 : j2, o8);
    else if ("dangerouslySetInnerHTML" !== l7) {
      if (t6)
        l7 = l7.replace(/xlink(H|:h)/, "h").replace(/sName$/, "s");
      else if ("width" !== l7 && "height" !== l7 && "href" !== l7 && "list" !== l7 && "form" !== l7 && "tabIndex" !== l7 && "download" !== l7 && "rowSpan" !== l7 && "colSpan" !== l7 && l7 in n8)
        try {
          n8[l7] = null == u5 ? "" : u5;
          break n;
        } catch (n9) {
        }
      "function" == typeof u5 || (null == u5 || false === u5 && "-" !== l7[4] ? n8.removeAttribute(l7) : n8.setAttribute(l7, u5));
    }
}
function j2(n8) {
  return this.l[n8.type + false](l4.event ? l4.event(n8) : n8);
}
function z2(n8) {
  return this.l[n8.type + true](l4.event ? l4.event(n8) : n8);
}
function L2(n8, u5, i6, t6, o8, r6, f4, e9, c5) {
  var s7, a5, p4, y4, d5, _4, g5, m4, w5, x5, C4, S4, $5, A5, H4, I4 = u5.type;
  if (void 0 !== u5.constructor)
    return null;
  null != i6.__h && (c5 = i6.__h, e9 = u5.__e = i6.__e, u5.__h = null, r6 = [e9]), (s7 = l4.__b) && s7(u5);
  try {
    n:
      if ("function" == typeof I4) {
        if (m4 = u5.props, w5 = (s7 = I4.contextType) && t6[s7.__c], x5 = s7 ? w5 ? w5.props.value : s7.__ : t6, i6.__c ? g5 = (a5 = u5.__c = i6.__c).__ = a5.__E : ("prototype" in I4 && I4.prototype.render ? u5.__c = a5 = new I4(m4, x5) : (u5.__c = a5 = new b2(m4, x5), a5.constructor = I4, a5.render = B2), w5 && w5.sub(a5), a5.props = m4, a5.state || (a5.state = {}), a5.context = x5, a5.__n = t6, p4 = a5.__d = true, a5.__h = [], a5._sb = []), null == a5.__s && (a5.__s = a5.state), null != I4.getDerivedStateFromProps && (a5.__s == a5.state && (a5.__s = h3({}, a5.__s)), h3(a5.__s, I4.getDerivedStateFromProps(m4, a5.__s))), y4 = a5.props, d5 = a5.state, a5.__v = u5, p4)
          null == I4.getDerivedStateFromProps && null != a5.componentWillMount && a5.componentWillMount(), null != a5.componentDidMount && a5.__h.push(a5.componentDidMount);
        else {
          if (null == I4.getDerivedStateFromProps && m4 !== y4 && null != a5.componentWillReceiveProps && a5.componentWillReceiveProps(m4, x5), !a5.__e && null != a5.shouldComponentUpdate && false === a5.shouldComponentUpdate(m4, a5.__s, x5) || u5.__v === i6.__v) {
            for (u5.__v !== i6.__v && (a5.props = m4, a5.state = a5.__s, a5.__d = false), a5.__e = false, u5.__e = i6.__e, u5.__k = i6.__k, u5.__k.forEach(function(n9) {
              n9 && (n9.__ = u5);
            }), C4 = 0; C4 < a5._sb.length; C4++)
              a5.__h.push(a5._sb[C4]);
            a5._sb = [], a5.__h.length && f4.push(a5);
            break n;
          }
          null != a5.componentWillUpdate && a5.componentWillUpdate(m4, a5.__s, x5), null != a5.componentDidUpdate && a5.__h.push(function() {
            a5.componentDidUpdate(y4, d5, _4);
          });
        }
        if (a5.context = x5, a5.props = m4, a5.__P = n8, S4 = l4.__r, $5 = 0, "prototype" in I4 && I4.prototype.render) {
          for (a5.state = a5.__s, a5.__d = false, S4 && S4(u5), s7 = a5.render(a5.props, a5.state, a5.context), A5 = 0; A5 < a5._sb.length; A5++)
            a5.__h.push(a5._sb[A5]);
          a5._sb = [];
        } else
          do {
            a5.__d = false, S4 && S4(u5), s7 = a5.render(a5.props, a5.state, a5.context), a5.state = a5.__s;
          } while (a5.__d && ++$5 < 25);
        a5.state = a5.__s, null != a5.getChildContext && (t6 = h3(h3({}, t6), a5.getChildContext())), p4 || null == a5.getSnapshotBeforeUpdate || (_4 = a5.getSnapshotBeforeUpdate(y4, d5)), P2(n8, v2(H4 = null != s7 && s7.type === k2 && null == s7.key ? s7.props.children : s7) ? H4 : [H4], u5, i6, t6, o8, r6, f4, e9, c5), a5.base = u5.__e, u5.__h = null, a5.__h.length && f4.push(a5), g5 && (a5.__E = a5.__ = null), a5.__e = false;
      } else
        null == r6 && u5.__v === i6.__v ? (u5.__k = i6.__k, u5.__e = i6.__e) : u5.__e = N2(i6.__e, u5, i6, t6, o8, r6, f4, c5);
    (s7 = l4.diffed) && s7(u5);
  } catch (n9) {
    u5.__v = null, (c5 || null != r6) && (u5.__e = e9, u5.__h = !!c5, r6[r6.indexOf(e9)] = null), l4.__e(n9, u5, i6);
  }
}
function M2(n8, u5) {
  l4.__c && l4.__c(u5, n8), n8.some(function(u6) {
    try {
      n8 = u6.__h, u6.__h = [], n8.some(function(n9) {
        n9.call(u6);
      });
    } catch (n9) {
      l4.__e(n9, u6.__v);
    }
  });
}
function N2(l7, u5, i6, t6, o8, r6, f4, e9) {
  var s7, a5, h5, y4 = i6.props, d5 = u5.props, _4 = u5.type, k5 = 0;
  if ("svg" === _4 && (o8 = true), null != r6) {
    for (; k5 < r6.length; k5++)
      if ((s7 = r6[k5]) && "setAttribute" in s7 == !!_4 && (_4 ? s7.localName === _4 : 3 === s7.nodeType)) {
        l7 = s7, r6[k5] = null;
        break;
      }
  }
  if (null == l7) {
    if (null === _4)
      return document.createTextNode(d5);
    l7 = o8 ? document.createElementNS("http://www.w3.org/2000/svg", _4) : document.createElement(_4, d5.is && d5), r6 = null, e9 = false;
  }
  if (null === _4)
    y4 === d5 || e9 && l7.data === d5 || (l7.data = d5);
  else {
    if (r6 = r6 && n5.call(l7.childNodes), a5 = (y4 = i6.props || c3).dangerouslySetInnerHTML, h5 = d5.dangerouslySetInnerHTML, !e9) {
      if (null != r6)
        for (y4 = {}, k5 = 0; k5 < l7.attributes.length; k5++)
          y4[l7.attributes[k5].name] = l7.attributes[k5].value;
      (h5 || a5) && (h5 && (a5 && h5.__html == a5.__html || h5.__html === l7.innerHTML) || (l7.innerHTML = h5 && h5.__html || ""));
    }
    if (H2(l7, d5, y4, o8, e9), h5)
      u5.__k = [];
    else if (P2(l7, v2(k5 = u5.props.children) ? k5 : [k5], u5, i6, t6, o8 && "foreignObject" !== _4, r6, f4, r6 ? r6[0] : i6.__k && g2(i6, 0), e9), null != r6)
      for (k5 = r6.length; k5--; )
        null != r6[k5] && p2(r6[k5]);
    e9 || ("value" in d5 && void 0 !== (k5 = d5.value) && (k5 !== l7.value || "progress" === _4 && !k5 || "option" === _4 && k5 !== y4.value) && T2(l7, "value", k5, y4.value, false), "checked" in d5 && void 0 !== (k5 = d5.checked) && k5 !== l7.checked && T2(l7, "checked", k5, y4.checked, false));
  }
  return l7;
}
function O(n8, u5, i6) {
  try {
    "function" == typeof n8 ? n8(u5) : n8.current = u5;
  } catch (n9) {
    l4.__e(n9, i6);
  }
}
function q(n8, u5, i6) {
  var t6, o8;
  if (l4.unmount && l4.unmount(n8), (t6 = n8.ref) && (t6.current && t6.current !== n8.__e || O(t6, null, u5)), null != (t6 = n8.__c)) {
    if (t6.componentWillUnmount)
      try {
        t6.componentWillUnmount();
      } catch (n9) {
        l4.__e(n9, u5);
      }
    t6.base = t6.__P = null, n8.__c = void 0;
  }
  if (t6 = n8.__k)
    for (o8 = 0; o8 < t6.length; o8++)
      t6[o8] && q(t6[o8], u5, i6 || "function" != typeof n8.type);
  i6 || null == n8.__e || p2(n8.__e), n8.__ = n8.__e = n8.__d = void 0;
}
function B2(n8, l7, u5) {
  return this.constructor(n8, u5);
}
function D(u5, i6, t6) {
  var o8, r6, f4;
  l4.__ && l4.__(u5, i6), r6 = (o8 = "function" == typeof t6) ? null : t6 && t6.__k || i6.__k, f4 = [], L2(i6, u5 = (!o8 && t6 || i6).__k = y2(k2, null, [u5]), r6 || c3, c3, void 0 !== i6.ownerSVGElement, !o8 && t6 ? [t6] : r6 ? null : i6.firstChild ? n5.call(i6.childNodes) : null, f4, !o8 && t6 ? t6 : r6 ? r6.__e : i6.firstChild, o8), M2(f4, u5);
}
function E2(n8, l7) {
  D(n8, l7, E2);
}
function F(l7, u5, i6) {
  var t6, o8, r6, f4, e9 = h3({}, l7.props);
  for (r6 in l7.type && l7.type.defaultProps && (f4 = l7.type.defaultProps), u5)
    "key" == r6 ? t6 = u5[r6] : "ref" == r6 ? o8 = u5[r6] : e9[r6] = void 0 === u5[r6] && void 0 !== f4 ? f4[r6] : u5[r6];
  return arguments.length > 2 && (e9.children = arguments.length > 3 ? n5.call(arguments, 2) : i6), d3(l7.type, e9, t6 || l7.key, o8 || l7.ref, null);
}
function G(n8, l7) {
  var u5 = { __c: l7 = "__cC" + e4++, __: n8, Consumer: function(n9, l8) {
    return n9.children(l8);
  }, Provider: function(n9) {
    var u6, i6;
    return this.getChildContext || (u6 = [], (i6 = {})[l7] = this, this.getChildContext = function() {
      return i6;
    }, this.shouldComponentUpdate = function(n10) {
      this.props.value !== n10.value && u6.some(function(n11) {
        n11.__e = true, w2(n11);
      });
    }, this.sub = function(n10) {
      u6.push(n10);
      var l8 = n10.componentWillUnmount;
      n10.componentWillUnmount = function() {
        u6.splice(u6.indexOf(n10), 1), l8 && l8.call(n10);
      };
    }), n9.children;
  } };
  return u5.Provider.__ = u5.Consumer.contextType = u5;
}
var n5, l4, u3, i3, t3, o5, r4, f2, e4, c3, s5, a3, v2;
var init_preact_module = __esm({
  "node_modules/preact/dist/preact.module.js"() {
    c3 = {};
    s5 = [];
    a3 = /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i;
    v2 = Array.isArray;
    n5 = s5.slice, l4 = { __e: function(n8, l7, u5, i6) {
      for (var t6, o8, r6; l7 = l7.__; )
        if ((t6 = l7.__c) && !t6.__)
          try {
            if ((o8 = t6.constructor) && null != o8.getDerivedStateFromError && (t6.setState(o8.getDerivedStateFromError(n8)), r6 = t6.__d), null != t6.componentDidCatch && (t6.componentDidCatch(n8, i6 || {}), r6 = t6.__d), r6)
              return t6.__E = t6;
          } catch (l8) {
            n8 = l8;
          }
      throw n8;
    } }, u3 = 0, i3 = function(n8) {
      return null != n8 && void 0 === n8.constructor;
    }, b2.prototype.setState = function(n8, l7) {
      var u5;
      u5 = null != this.__s && this.__s !== this.state ? this.__s : this.__s = h3({}, this.state), "function" == typeof n8 && (n8 = n8(h3({}, u5), this.props)), n8 && h3(u5, n8), null != n8 && this.__v && (l7 && this._sb.push(l7), w2(this));
    }, b2.prototype.forceUpdate = function(n8) {
      this.__v && (this.__e = true, n8 && this.__h.push(n8), w2(this));
    }, b2.prototype.render = k2, t3 = [], r4 = "function" == typeof Promise ? Promise.prototype.then.bind(Promise.resolve()) : setTimeout, f2 = function(n8, l7) {
      return n8.__v.__b - l7.__v.__b;
    }, x2.__r = 0, e4 = 0;
  }
});

// node_modules/preact/hooks/dist/hooks.module.js
function d4(t6, u5) {
  l4.__h && l4.__h(r5, t6, o6 || u5), o6 = 0;
  var i6 = r5.__H || (r5.__H = { __: [], __h: [] });
  return t6 >= i6.__.length && i6.__.push({ __V: c4 }), i6.__[t6];
}
function h4(n8) {
  return o6 = 1, s6(B3, n8);
}
function s6(n8, u5, i6) {
  var o8 = d4(t4++, 2);
  if (o8.t = n8, !o8.__c && (o8.__ = [i6 ? i6(u5) : B3(void 0, u5), function(n9) {
    var t6 = o8.__N ? o8.__N[0] : o8.__[0], r6 = o8.t(t6, n9);
    t6 !== r6 && (o8.__N = [r6, o8.__[1]], o8.__c.setState({}));
  }], o8.__c = r5, !r5.u)) {
    var f4 = function(n9, t6, r6) {
      if (!o8.__c.__H)
        return true;
      var u6 = o8.__c.__H.__.filter(function(n10) {
        return n10.__c;
      });
      if (u6.every(function(n10) {
        return !n10.__N;
      }))
        return !c5 || c5.call(this, n9, t6, r6);
      var i7 = false;
      return u6.forEach(function(n10) {
        if (n10.__N) {
          var t7 = n10.__[0];
          n10.__ = n10.__N, n10.__N = void 0, t7 !== n10.__[0] && (i7 = true);
        }
      }), !(!i7 && o8.__c.props === n9) && (!c5 || c5.call(this, n9, t6, r6));
    };
    r5.u = true;
    var c5 = r5.shouldComponentUpdate, e9 = r5.componentWillUpdate;
    r5.componentWillUpdate = function(n9, t6, r6) {
      if (this.__e) {
        var u6 = c5;
        c5 = void 0, f4(n9, t6, r6), c5 = u6;
      }
      e9 && e9.call(this, n9, t6, r6);
    }, r5.shouldComponentUpdate = f4;
  }
  return o8.__N || o8.__;
}
function p3(u5, i6) {
  var o8 = d4(t4++, 3);
  !l4.__s && z3(o8.__H, i6) && (o8.__ = u5, o8.i = i6, r5.__H.__h.push(o8));
}
function y3(u5, i6) {
  var o8 = d4(t4++, 4);
  !l4.__s && z3(o8.__H, i6) && (o8.__ = u5, o8.i = i6, r5.__h.push(o8));
}
function _3(n8) {
  return o6 = 5, F2(function() {
    return { current: n8 };
  }, []);
}
function A3(n8, t6, r6) {
  o6 = 6, y3(function() {
    return "function" == typeof n8 ? (n8(t6()), function() {
      return n8(null);
    }) : n8 ? (n8.current = t6(), function() {
      return n8.current = null;
    }) : void 0;
  }, null == r6 ? r6 : r6.concat(n8));
}
function F2(n8, r6) {
  var u5 = d4(t4++, 7);
  return z3(u5.__H, r6) ? (u5.__V = n8(), u5.i = r6, u5.__h = n8, u5.__V) : u5.__;
}
function T3(n8, t6) {
  return o6 = 8, F2(function() {
    return n8;
  }, t6);
}
function q2(n8) {
  var u5 = r5.context[n8.__c], i6 = d4(t4++, 9);
  return i6.c = n8, u5 ? (null == i6.__ && (i6.__ = true, u5.sub(r5)), u5.props.value) : n8.__;
}
function x3(t6, r6) {
  l4.useDebugValue && l4.useDebugValue(r6 ? r6(t6) : t6);
}
function P3(n8) {
  var u5 = d4(t4++, 10), i6 = h4();
  return u5.__ = n8, r5.componentDidCatch || (r5.componentDidCatch = function(n9, t6) {
    u5.__ && u5.__(n9, t6), i6[1](n9);
  }), [i6[0], function() {
    i6[1](void 0);
  }];
}
function V2() {
  var n8 = d4(t4++, 11);
  if (!n8.__) {
    for (var u5 = r5.__v; null !== u5 && !u5.__m && null !== u5.__; )
      u5 = u5.__;
    var i6 = u5.__m || (u5.__m = [0, 0]);
    n8.__ = "P" + i6[0] + "-" + i6[1]++;
  }
  return n8.__;
}
function b3() {
  for (var t6; t6 = f3.shift(); )
    if (t6.__P && t6.__H)
      try {
        t6.__H.__h.forEach(k3), t6.__H.__h.forEach(w3), t6.__H.__h = [];
      } catch (r6) {
        t6.__H.__h = [], l4.__e(r6, t6.__v);
      }
}
function j3(n8) {
  var t6, r6 = function() {
    clearTimeout(u5), g3 && cancelAnimationFrame(t6), setTimeout(n8);
  }, u5 = setTimeout(r6, 100);
  g3 && (t6 = requestAnimationFrame(r6));
}
function k3(n8) {
  var t6 = r5, u5 = n8.__c;
  "function" == typeof u5 && (n8.__c = void 0, u5()), r5 = t6;
}
function w3(n8) {
  var t6 = r5;
  n8.__c = n8.__(), r5 = t6;
}
function z3(n8, t6) {
  return !n8 || n8.length !== t6.length || t6.some(function(t7, r6) {
    return t7 !== n8[r6];
  });
}
function B3(n8, t6) {
  return "function" == typeof t6 ? t6(n8) : t6;
}
var t4, r5, u4, i4, o6, f3, c4, e5, a4, v3, l5, m3, g3;
var init_hooks_module = __esm({
  "node_modules/preact/hooks/dist/hooks.module.js"() {
    init_preact_module();
    o6 = 0;
    f3 = [];
    c4 = [];
    e5 = l4.__b;
    a4 = l4.__r;
    v3 = l4.diffed;
    l5 = l4.__c;
    m3 = l4.unmount;
    l4.__b = function(n8) {
      r5 = null, e5 && e5(n8);
    }, l4.__r = function(n8) {
      a4 && a4(n8), t4 = 0;
      var i6 = (r5 = n8.__c).__H;
      i6 && (u4 === r5 ? (i6.__h = [], r5.__h = [], i6.__.forEach(function(n9) {
        n9.__N && (n9.__ = n9.__N), n9.__V = c4, n9.__N = n9.i = void 0;
      })) : (i6.__h.forEach(k3), i6.__h.forEach(w3), i6.__h = [], t4 = 0)), u4 = r5;
    }, l4.diffed = function(t6) {
      v3 && v3(t6);
      var o8 = t6.__c;
      o8 && o8.__H && (o8.__H.__h.length && (1 !== f3.push(o8) && i4 === l4.requestAnimationFrame || ((i4 = l4.requestAnimationFrame) || j3)(b3)), o8.__H.__.forEach(function(n8) {
        n8.i && (n8.__H = n8.i), n8.__V !== c4 && (n8.__ = n8.__V), n8.i = void 0, n8.__V = c4;
      })), u4 = r5 = null;
    }, l4.__c = function(t6, r6) {
      r6.some(function(t7) {
        try {
          t7.__h.forEach(k3), t7.__h = t7.__h.filter(function(n8) {
            return !n8.__ || w3(n8);
          });
        } catch (u5) {
          r6.some(function(n8) {
            n8.__h && (n8.__h = []);
          }), r6 = [], l4.__e(u5, t7.__v);
        }
      }), l5 && l5(t6, r6);
    }, l4.unmount = function(t6) {
      m3 && m3(t6);
      var r6, u5 = t6.__c;
      u5 && u5.__H && (u5.__H.__.forEach(function(n8) {
        try {
          k3(n8);
        } catch (n9) {
          r6 = n9;
        }
      }), u5.__H = void 0, r6 && l4.__e(r6, u5.__v));
    };
    g3 = "function" == typeof requestAnimationFrame;
  }
});

// node_modules/preact/compat/dist/compat.module.js
function g4(n8, t6) {
  for (var e9 in t6)
    n8[e9] = t6[e9];
  return n8;
}
function C3(n8, t6) {
  for (var e9 in n8)
    if ("__source" !== e9 && !(e9 in t6))
      return true;
  for (var r6 in t6)
    if ("__source" !== r6 && n8[r6] !== t6[r6])
      return true;
  return false;
}
function E3(n8, t6) {
  return n8 === t6 && (0 !== n8 || 1 / n8 == 1 / t6) || n8 != n8 && t6 != t6;
}
function w4(n8) {
  this.props = n8;
}
function x4(n8, e9) {
  function r6(n9) {
    var t6 = this.props.ref, r7 = t6 == n9.ref;
    return !r7 && t6 && (t6.call ? t6(null) : t6.current = null), e9 ? !e9(this.props, n9) || !r7 : C3(this.props, n9);
  }
  function u5(e10) {
    return this.shouldComponentUpdate = r6, y2(n8, e10);
  }
  return u5.displayName = "Memo(" + (n8.displayName || n8.name) + ")", u5.prototype.isReactComponent = true, u5.__f = true, u5;
}
function k4(n8) {
  function t6(t7) {
    var e9 = g4({}, t7);
    return delete e9.ref, n8(e9, t7.ref || null);
  }
  return t6.$$typeof = N3, t6.render = t6, t6.prototype.isReactComponent = t6.__f = true, t6.displayName = "ForwardRef(" + (n8.displayName || n8.name) + ")", t6;
}
function L3(n8, t6, e9) {
  return n8 && (n8.__c && n8.__c.__H && (n8.__c.__H.__.forEach(function(n9) {
    "function" == typeof n9.__c && n9.__c();
  }), n8.__c.__H = null), null != (n8 = g4({}, n8)).__c && (n8.__c.__P === e9 && (n8.__c.__P = t6), n8.__c = null), n8.__k = n8.__k && n8.__k.map(function(n9) {
    return L3(n9, t6, e9);
  })), n8;
}
function U(n8, t6, e9) {
  return n8 && (n8.__v = null, n8.__k = n8.__k && n8.__k.map(function(n9) {
    return U(n9, t6, e9);
  }), n8.__c && n8.__c.__P === t6 && (n8.__e && e9.insertBefore(n8.__e, n8.__d), n8.__c.__e = true, n8.__c.__P = e9)), n8;
}
function D2() {
  this.__u = 0, this.t = null, this.__b = null;
}
function F3(n8) {
  var t6 = n8.__.__c;
  return t6 && t6.__a && t6.__a(n8);
}
function M3(n8) {
  var e9, r6, u5;
  function o8(o9) {
    if (e9 || (e9 = n8()).then(function(n9) {
      r6 = n9.default || n9;
    }, function(n9) {
      u5 = n9;
    }), u5)
      throw u5;
    if (!r6)
      throw e9;
    return y2(r6, o9);
  }
  return o8.displayName = "Lazy", o8.__f = true, o8;
}
function V3() {
  this.u = null, this.o = null;
}
function P4(n8) {
  return this.getChildContext = function() {
    return n8.context;
  }, n8.children;
}
function j4(n8) {
  var e9 = this, r6 = n8.i;
  e9.componentWillUnmount = function() {
    D(null, e9.l), e9.l = null, e9.i = null;
  }, e9.i && e9.i !== r6 && e9.componentWillUnmount(), n8.__v ? (e9.l || (e9.i = r6, e9.l = { nodeType: 1, parentNode: r6, childNodes: [], appendChild: function(n9) {
    this.childNodes.push(n9), e9.i.appendChild(n9);
  }, insertBefore: function(n9, t6) {
    this.childNodes.push(n9), e9.i.appendChild(n9);
  }, removeChild: function(n9) {
    this.childNodes.splice(this.childNodes.indexOf(n9) >>> 1, 1), e9.i.removeChild(n9);
  } }), D(y2(P4, { context: e9.context }, n8.__v), e9.l)) : e9.l && e9.componentWillUnmount();
}
function z4(n8, e9) {
  var r6 = y2(j4, { __v: n8, i: e9 });
  return r6.containerInfo = e9, r6;
}
function G2(n8, t6, e9) {
  return null == t6.__k && (t6.textContent = ""), D(n8, t6), "function" == typeof e9 && e9(), n8 ? n8.__c : null;
}
function J(n8, t6, e9) {
  return E2(n8, t6), "function" == typeof e9 && e9(), n8 ? n8.__c : null;
}
function Q() {
}
function X() {
  return this.cancelBubble;
}
function nn() {
  return this.defaultPrevented;
}
function fn(n8) {
  return y2.bind(null, n8);
}
function an(n8) {
  return !!n8 && n8.$$typeof === B4;
}
function sn(n8) {
  return an(n8) ? F.apply(null, arguments) : n8;
}
function hn(n8) {
  return !!n8.__k && (D(null, n8), true);
}
function vn(n8) {
  return n8 && (n8.base || 1 === n8.nodeType && n8) || null;
}
function yn(n8) {
  n8();
}
function _n(n8) {
  return n8;
}
function bn() {
  return [false, yn];
}
function gn(n8, t6) {
  var e9 = t6(), r6 = h4({ h: { __: e9, v: t6 } }), u5 = r6[0].h, o8 = r6[1];
  return y3(function() {
    u5.__ = e9, u5.v = t6, E3(u5.__, t6()) || o8({ h: u5 });
  }, [n8, e9, t6]), p3(function() {
    return E3(u5.__, u5.v()) || o8({ h: u5 }), n8(function() {
      E3(u5.__, u5.v()) || o8({ h: u5 });
    });
  }, [n8]), e9;
}
var R2, N3, A4, O2, T4, I3, W, B4, H3, Z, Y, $4, q3, K, tn, en, rn, un, on, ln, cn, dn, pn, mn, Sn, Cn;
var init_compat_module = __esm({
  "node_modules/preact/compat/dist/compat.module.js"() {
    init_preact_module();
    init_preact_module();
    init_hooks_module();
    init_hooks_module();
    (w4.prototype = new b2()).isPureReactComponent = true, w4.prototype.shouldComponentUpdate = function(n8, t6) {
      return C3(this.props, n8) || C3(this.state, t6);
    };
    R2 = l4.__b;
    l4.__b = function(n8) {
      n8.type && n8.type.__f && n8.ref && (n8.props.ref = n8.ref, n8.ref = null), R2 && R2(n8);
    };
    N3 = "undefined" != typeof Symbol && Symbol.for && Symbol.for("react.forward_ref") || 3911;
    A4 = function(n8, t6) {
      return null == n8 ? null : S3(S3(n8).map(t6));
    };
    O2 = { map: A4, forEach: A4, count: function(n8) {
      return n8 ? S3(n8).length : 0;
    }, only: function(n8) {
      var t6 = S3(n8);
      if (1 !== t6.length)
        throw "Children.only";
      return t6[0];
    }, toArray: S3 };
    T4 = l4.__e;
    l4.__e = function(n8, t6, e9, r6) {
      if (n8.then) {
        for (var u5, o8 = t6; o8 = o8.__; )
          if ((u5 = o8.__c) && u5.__c)
            return null == t6.__e && (t6.__e = e9.__e, t6.__k = e9.__k), u5.__c(n8, t6);
      }
      T4(n8, t6, e9, r6);
    };
    I3 = l4.unmount;
    l4.unmount = function(n8) {
      var t6 = n8.__c;
      t6 && t6.__R && t6.__R(), t6 && true === n8.__h && (n8.type = null), I3 && I3(n8);
    }, (D2.prototype = new b2()).__c = function(n8, t6) {
      var e9 = t6.__c, r6 = this;
      null == r6.t && (r6.t = []), r6.t.push(e9);
      var u5 = F3(r6.__v), o8 = false, i6 = function() {
        o8 || (o8 = true, e9.__R = null, u5 ? u5(l7) : l7());
      };
      e9.__R = i6;
      var l7 = function() {
        if (!--r6.__u) {
          if (r6.state.__a) {
            var n9 = r6.state.__a;
            r6.__v.__k[0] = U(n9, n9.__c.__P, n9.__c.__O);
          }
          var t7;
          for (r6.setState({ __a: r6.__b = null }); t7 = r6.t.pop(); )
            t7.forceUpdate();
        }
      }, c5 = true === t6.__h;
      r6.__u++ || c5 || r6.setState({ __a: r6.__b = r6.__v.__k[0] }), n8.then(i6, i6);
    }, D2.prototype.componentWillUnmount = function() {
      this.t = [];
    }, D2.prototype.render = function(n8, e9) {
      if (this.__b) {
        if (this.__v.__k) {
          var r6 = document.createElement("div"), o8 = this.__v.__k[0].__c;
          this.__v.__k[0] = L3(this.__b, r6, o8.__O = o8.__P);
        }
        this.__b = null;
      }
      var i6 = e9.__a && y2(k2, null, n8.fallback);
      return i6 && (i6.__h = null), [y2(k2, null, e9.__a ? null : n8.children), i6];
    };
    W = function(n8, t6, e9) {
      if (++e9[1] === e9[0] && n8.o.delete(t6), n8.props.revealOrder && ("t" !== n8.props.revealOrder[0] || !n8.o.size))
        for (e9 = n8.u; e9; ) {
          for (; e9.length > 3; )
            e9.pop()();
          if (e9[1] < e9[0])
            break;
          n8.u = e9 = e9[2];
        }
    };
    (V3.prototype = new b2()).__a = function(n8) {
      var t6 = this, e9 = F3(t6.__v), r6 = t6.o.get(n8);
      return r6[0]++, function(u5) {
        var o8 = function() {
          t6.props.revealOrder ? (r6.push(u5), W(t6, n8, r6)) : u5();
        };
        e9 ? e9(o8) : o8();
      };
    }, V3.prototype.render = function(n8) {
      this.u = null, this.o = /* @__PURE__ */ new Map();
      var t6 = S3(n8.children);
      n8.revealOrder && "b" === n8.revealOrder[0] && t6.reverse();
      for (var e9 = t6.length; e9--; )
        this.o.set(t6[e9], this.u = [1, 0, this.u]);
      return n8.children;
    }, V3.prototype.componentDidUpdate = V3.prototype.componentDidMount = function() {
      var n8 = this;
      this.o.forEach(function(t6, e9) {
        W(n8, e9, t6);
      });
    };
    B4 = "undefined" != typeof Symbol && Symbol.for && Symbol.for("react.element") || 60103;
    H3 = /^(?:accent|alignment|arabic|baseline|cap|clip(?!PathU)|color|dominant|fill|flood|font|glyph(?!R)|horiz|image(!S)|letter|lighting|marker(?!H|W|U)|overline|paint|pointer|shape|stop|strikethrough|stroke|text(?!L)|transform|underline|unicode|units|v|vector|vert|word|writing|x(?!C))[A-Z]/;
    Z = /^on(Ani|Tra|Tou|BeforeInp|Compo)/;
    Y = /[A-Z0-9]/g;
    $4 = "undefined" != typeof document;
    q3 = function(n8) {
      return ("undefined" != typeof Symbol && "symbol" == typeof Symbol() ? /fil|che|rad/ : /fil|che|ra/).test(n8);
    };
    b2.prototype.isReactComponent = {}, ["componentWillMount", "componentWillReceiveProps", "componentWillUpdate"].forEach(function(t6) {
      Object.defineProperty(b2.prototype, t6, { configurable: true, get: function() {
        return this["UNSAFE_" + t6];
      }, set: function(n8) {
        Object.defineProperty(this, t6, { configurable: true, writable: true, value: n8 });
      } });
    });
    K = l4.event;
    l4.event = function(n8) {
      return K && (n8 = K(n8)), n8.persist = Q, n8.isPropagationStopped = X, n8.isDefaultPrevented = nn, n8.nativeEvent = n8;
    };
    en = { enumerable: false, configurable: true, get: function() {
      return this.class;
    } };
    rn = l4.vnode;
    l4.vnode = function(n8) {
      "string" == typeof n8.type && function(n9) {
        var t6 = n9.props, e9 = n9.type, u5 = {};
        for (var o8 in t6) {
          var i6 = t6[o8];
          if (!("value" === o8 && "defaultValue" in t6 && null == i6 || $4 && "children" === o8 && "noscript" === e9 || "class" === o8 || "className" === o8)) {
            var l7 = o8.toLowerCase();
            "defaultValue" === o8 && "value" in t6 && null == t6.value ? o8 = "value" : "download" === o8 && true === i6 ? i6 = "" : "ondoubleclick" === l7 ? o8 = "ondblclick" : "onchange" !== l7 || "input" !== e9 && "textarea" !== e9 || q3(t6.type) ? "onfocus" === l7 ? o8 = "onfocusin" : "onblur" === l7 ? o8 = "onfocusout" : Z.test(o8) ? o8 = l7 : -1 === e9.indexOf("-") && H3.test(o8) ? o8 = o8.replace(Y, "-$&").toLowerCase() : null === i6 && (i6 = void 0) : l7 = o8 = "oninput", "oninput" === l7 && u5[o8 = l7] && (o8 = "oninputCapture"), u5[o8] = i6;
          }
        }
        "select" == e9 && u5.multiple && Array.isArray(u5.value) && (u5.value = S3(t6.children).forEach(function(n10) {
          n10.props.selected = -1 != u5.value.indexOf(n10.props.value);
        })), "select" == e9 && null != u5.defaultValue && (u5.value = S3(t6.children).forEach(function(n10) {
          n10.props.selected = u5.multiple ? -1 != u5.defaultValue.indexOf(n10.props.value) : u5.defaultValue == n10.props.value;
        })), t6.class && !t6.className ? (u5.class = t6.class, Object.defineProperty(u5, "className", en)) : (t6.className && !t6.class || t6.class && t6.className) && (u5.class = u5.className = t6.className), n9.props = u5;
      }(n8), n8.$$typeof = B4, rn && rn(n8);
    };
    un = l4.__r;
    l4.__r = function(n8) {
      un && un(n8), tn = n8.__c;
    };
    on = l4.diffed;
    l4.diffed = function(n8) {
      on && on(n8);
      var t6 = n8.props, e9 = n8.__e;
      null != e9 && "textarea" === n8.type && "value" in t6 && t6.value !== e9.value && (e9.value = null == t6.value ? "" : t6.value), tn = null;
    };
    ln = { ReactCurrentDispatcher: { current: { readContext: function(n8) {
      return tn.__n[n8.__c].props.value;
    } } } };
    cn = "17.0.2";
    dn = function(n8, t6) {
      return n8(t6);
    };
    pn = function(n8, t6) {
      return n8(t6);
    };
    mn = k2;
    Sn = y3;
    Cn = { useState: h4, useId: V2, useReducer: s6, useEffect: p3, useLayoutEffect: y3, useInsertionEffect: Sn, useTransition: bn, useDeferredValue: _n, useSyncExternalStore: gn, startTransition: yn, useRef: _3, useImperativeHandle: A3, useMemo: F2, useCallback: T3, useContext: q2, useDebugValue: x3, version: "17.0.2", Children: O2, render: G2, hydrate: J, unmountComponentAtNode: hn, createPortal: z4, createElement: y2, createContext: G, createFactory: fn, cloneElement: sn, createRef: _2, Fragment: k2, isValidElement: an, findDOMNode: vn, Component: b2, PureComponent: w4, memo: x4, forwardRef: k4, flushSync: pn, unstable_batchedUpdates: dn, StrictMode: mn, Suspense: D2, SuspenseList: V3, lazy: M3, __SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED: ln };
  }
});

// node_modules/react/index.mjs
var react_exports = {};
__export(react_exports, {
  Children: () => O2,
  Component: () => b2,
  Fragment: () => k2,
  PureComponent: () => w4,
  StrictMode: () => mn,
  Suspense: () => D2,
  SuspenseList: () => V3,
  __SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED: () => ln,
  cloneElement: () => sn,
  createContext: () => G,
  createElement: () => y2,
  createFactory: () => fn,
  createPortal: () => z4,
  createRef: () => _2,
  default: () => Cn,
  findDOMNode: () => vn,
  flushSync: () => pn,
  forwardRef: () => k4,
  hydrate: () => J,
  isValidElement: () => an,
  lazy: () => M3,
  memo: () => x4,
  render: () => G2,
  startTransition: () => yn,
  unmountComponentAtNode: () => hn,
  unstable_batchedUpdates: () => dn,
  useCallback: () => T3,
  useContext: () => q2,
  useDebugValue: () => x3,
  useDeferredValue: () => _n,
  useEffect: () => p3,
  useErrorBoundary: () => P3,
  useId: () => V2,
  useImperativeHandle: () => A3,
  useInsertionEffect: () => Sn,
  useLayoutEffect: () => y3,
  useMemo: () => F2,
  useReducer: () => s6,
  useRef: () => _3,
  useState: () => h4,
  useSyncExternalStore: () => gn,
  useTransition: () => bn,
  version: () => cn
});
var init_react = __esm({
  "node_modules/react/index.mjs"() {
    init_compat_module();
    init_compat_module();
  }
});

// node_modules/lodash/_freeGlobal.js
var require_freeGlobal = __commonJS({
  "node_modules/lodash/_freeGlobal.js"(exports2, module2) {
    var freeGlobal2 = typeof global == "object" && global && global.Object === Object && global;
    module2.exports = freeGlobal2;
  }
});

// node_modules/lodash/_root.js
var require_root = __commonJS({
  "node_modules/lodash/_root.js"(exports2, module2) {
    var freeGlobal2 = require_freeGlobal();
    var freeSelf2 = typeof self == "object" && self && self.Object === Object && self;
    var root2 = freeGlobal2 || freeSelf2 || Function("return this")();
    module2.exports = root2;
  }
});

// node_modules/lodash/_Symbol.js
var require_Symbol = __commonJS({
  "node_modules/lodash/_Symbol.js"(exports2, module2) {
    var root2 = require_root();
    var Symbol3 = root2.Symbol;
    module2.exports = Symbol3;
  }
});

// node_modules/lodash/_getRawTag.js
var require_getRawTag = __commonJS({
  "node_modules/lodash/_getRawTag.js"(exports2, module2) {
    var Symbol3 = require_Symbol();
    var objectProto16 = Object.prototype;
    var hasOwnProperty13 = objectProto16.hasOwnProperty;
    var nativeObjectToString3 = objectProto16.toString;
    var symToStringTag3 = Symbol3 ? Symbol3.toStringTag : void 0;
    function getRawTag2(value) {
      var isOwn = hasOwnProperty13.call(value, symToStringTag3), tag = value[symToStringTag3];
      try {
        value[symToStringTag3] = void 0;
        var unmasked = true;
      } catch (e9) {
      }
      var result = nativeObjectToString3.call(value);
      if (unmasked) {
        if (isOwn) {
          value[symToStringTag3] = tag;
        } else {
          delete value[symToStringTag3];
        }
      }
      return result;
    }
    module2.exports = getRawTag2;
  }
});

// node_modules/lodash/_objectToString.js
var require_objectToString = __commonJS({
  "node_modules/lodash/_objectToString.js"(exports2, module2) {
    var objectProto16 = Object.prototype;
    var nativeObjectToString3 = objectProto16.toString;
    function objectToString2(value) {
      return nativeObjectToString3.call(value);
    }
    module2.exports = objectToString2;
  }
});

// node_modules/lodash/_baseGetTag.js
var require_baseGetTag = __commonJS({
  "node_modules/lodash/_baseGetTag.js"(exports2, module2) {
    var Symbol3 = require_Symbol();
    var getRawTag2 = require_getRawTag();
    var objectToString2 = require_objectToString();
    var nullTag2 = "[object Null]";
    var undefinedTag2 = "[object Undefined]";
    var symToStringTag3 = Symbol3 ? Symbol3.toStringTag : void 0;
    function baseGetTag2(value) {
      if (value == null) {
        return value === void 0 ? undefinedTag2 : nullTag2;
      }
      return symToStringTag3 && symToStringTag3 in Object(value) ? getRawTag2(value) : objectToString2(value);
    }
    module2.exports = baseGetTag2;
  }
});

// node_modules/lodash/isArray.js
var require_isArray = __commonJS({
  "node_modules/lodash/isArray.js"(exports2, module2) {
    var isArray2 = Array.isArray;
    module2.exports = isArray2;
  }
});

// node_modules/lodash/isObjectLike.js
var require_isObjectLike = __commonJS({
  "node_modules/lodash/isObjectLike.js"(exports2, module2) {
    function isObjectLike2(value) {
      return value != null && typeof value == "object";
    }
    module2.exports = isObjectLike2;
  }
});

// node_modules/lodash/isString.js
var require_isString = __commonJS({
  "node_modules/lodash/isString.js"(exports2, module2) {
    var baseGetTag2 = require_baseGetTag();
    var isArray2 = require_isArray();
    var isObjectLike2 = require_isObjectLike();
    var stringTag3 = "[object String]";
    function isString(value) {
      return typeof value == "string" || !isArray2(value) && isObjectLike2(value) && baseGetTag2(value) == stringTag3;
    }
    module2.exports = isString;
  }
});

// node_modules/lodash/_createBaseFor.js
var require_createBaseFor = __commonJS({
  "node_modules/lodash/_createBaseFor.js"(exports2, module2) {
    function createBaseFor2(fromRight) {
      return function(object, iteratee, keysFunc) {
        var index = -1, iterable = Object(object), props = keysFunc(object), length = props.length;
        while (length--) {
          var key = props[fromRight ? length : ++index];
          if (iteratee(iterable[key], key, iterable) === false) {
            break;
          }
        }
        return object;
      };
    }
    module2.exports = createBaseFor2;
  }
});

// node_modules/lodash/_baseFor.js
var require_baseFor = __commonJS({
  "node_modules/lodash/_baseFor.js"(exports2, module2) {
    var createBaseFor2 = require_createBaseFor();
    var baseFor2 = createBaseFor2();
    module2.exports = baseFor2;
  }
});

// node_modules/lodash/_baseTimes.js
var require_baseTimes = __commonJS({
  "node_modules/lodash/_baseTimes.js"(exports2, module2) {
    function baseTimes2(n8, iteratee) {
      var index = -1, result = Array(n8);
      while (++index < n8) {
        result[index] = iteratee(index);
      }
      return result;
    }
    module2.exports = baseTimes2;
  }
});

// node_modules/lodash/_baseIsArguments.js
var require_baseIsArguments = __commonJS({
  "node_modules/lodash/_baseIsArguments.js"(exports2, module2) {
    var baseGetTag2 = require_baseGetTag();
    var isObjectLike2 = require_isObjectLike();
    var argsTag4 = "[object Arguments]";
    function baseIsArguments2(value) {
      return isObjectLike2(value) && baseGetTag2(value) == argsTag4;
    }
    module2.exports = baseIsArguments2;
  }
});

// node_modules/lodash/isArguments.js
var require_isArguments = __commonJS({
  "node_modules/lodash/isArguments.js"(exports2, module2) {
    var baseIsArguments2 = require_baseIsArguments();
    var isObjectLike2 = require_isObjectLike();
    var objectProto16 = Object.prototype;
    var hasOwnProperty13 = objectProto16.hasOwnProperty;
    var propertyIsEnumerable3 = objectProto16.propertyIsEnumerable;
    var isArguments2 = baseIsArguments2(function() {
      return arguments;
    }()) ? baseIsArguments2 : function(value) {
      return isObjectLike2(value) && hasOwnProperty13.call(value, "callee") && !propertyIsEnumerable3.call(value, "callee");
    };
    module2.exports = isArguments2;
  }
});

// node_modules/lodash/stubFalse.js
var require_stubFalse = __commonJS({
  "node_modules/lodash/stubFalse.js"(exports2, module2) {
    function stubFalse2() {
      return false;
    }
    module2.exports = stubFalse2;
  }
});

// node_modules/lodash/isBuffer.js
var require_isBuffer = __commonJS({
  "node_modules/lodash/isBuffer.js"(exports2, module2) {
    var root2 = require_root();
    var stubFalse2 = require_stubFalse();
    var freeExports4 = typeof exports2 == "object" && exports2 && !exports2.nodeType && exports2;
    var freeModule4 = freeExports4 && typeof module2 == "object" && module2 && !module2.nodeType && module2;
    var moduleExports4 = freeModule4 && freeModule4.exports === freeExports4;
    var Buffer4 = moduleExports4 ? root2.Buffer : void 0;
    var nativeIsBuffer2 = Buffer4 ? Buffer4.isBuffer : void 0;
    var isBuffer2 = nativeIsBuffer2 || stubFalse2;
    module2.exports = isBuffer2;
  }
});

// node_modules/lodash/_isIndex.js
var require_isIndex = __commonJS({
  "node_modules/lodash/_isIndex.js"(exports2, module2) {
    var MAX_SAFE_INTEGER3 = 9007199254740991;
    var reIsUint2 = /^(?:0|[1-9]\d*)$/;
    function isIndex2(value, length) {
      var type = typeof value;
      length = length == null ? MAX_SAFE_INTEGER3 : length;
      return !!length && (type == "number" || type != "symbol" && reIsUint2.test(value)) && (value > -1 && value % 1 == 0 && value < length);
    }
    module2.exports = isIndex2;
  }
});

// node_modules/lodash/isLength.js
var require_isLength = __commonJS({
  "node_modules/lodash/isLength.js"(exports2, module2) {
    var MAX_SAFE_INTEGER3 = 9007199254740991;
    function isLength2(value) {
      return typeof value == "number" && value > -1 && value % 1 == 0 && value <= MAX_SAFE_INTEGER3;
    }
    module2.exports = isLength2;
  }
});

// node_modules/lodash/_baseIsTypedArray.js
var require_baseIsTypedArray = __commonJS({
  "node_modules/lodash/_baseIsTypedArray.js"(exports2, module2) {
    var baseGetTag2 = require_baseGetTag();
    var isLength2 = require_isLength();
    var isObjectLike2 = require_isObjectLike();
    var argsTag4 = "[object Arguments]";
    var arrayTag3 = "[object Array]";
    var boolTag3 = "[object Boolean]";
    var dateTag3 = "[object Date]";
    var errorTag3 = "[object Error]";
    var funcTag3 = "[object Function]";
    var mapTag4 = "[object Map]";
    var numberTag3 = "[object Number]";
    var objectTag5 = "[object Object]";
    var regexpTag3 = "[object RegExp]";
    var setTag4 = "[object Set]";
    var stringTag3 = "[object String]";
    var weakMapTag3 = "[object WeakMap]";
    var arrayBufferTag3 = "[object ArrayBuffer]";
    var dataViewTag4 = "[object DataView]";
    var float32Tag2 = "[object Float32Array]";
    var float64Tag2 = "[object Float64Array]";
    var int8Tag2 = "[object Int8Array]";
    var int16Tag2 = "[object Int16Array]";
    var int32Tag2 = "[object Int32Array]";
    var uint8Tag2 = "[object Uint8Array]";
    var uint8ClampedTag2 = "[object Uint8ClampedArray]";
    var uint16Tag2 = "[object Uint16Array]";
    var uint32Tag2 = "[object Uint32Array]";
    var typedArrayTags2 = {};
    typedArrayTags2[float32Tag2] = typedArrayTags2[float64Tag2] = typedArrayTags2[int8Tag2] = typedArrayTags2[int16Tag2] = typedArrayTags2[int32Tag2] = typedArrayTags2[uint8Tag2] = typedArrayTags2[uint8ClampedTag2] = typedArrayTags2[uint16Tag2] = typedArrayTags2[uint32Tag2] = true;
    typedArrayTags2[argsTag4] = typedArrayTags2[arrayTag3] = typedArrayTags2[arrayBufferTag3] = typedArrayTags2[boolTag3] = typedArrayTags2[dataViewTag4] = typedArrayTags2[dateTag3] = typedArrayTags2[errorTag3] = typedArrayTags2[funcTag3] = typedArrayTags2[mapTag4] = typedArrayTags2[numberTag3] = typedArrayTags2[objectTag5] = typedArrayTags2[regexpTag3] = typedArrayTags2[setTag4] = typedArrayTags2[stringTag3] = typedArrayTags2[weakMapTag3] = false;
    function baseIsTypedArray2(value) {
      return isObjectLike2(value) && isLength2(value.length) && !!typedArrayTags2[baseGetTag2(value)];
    }
    module2.exports = baseIsTypedArray2;
  }
});

// node_modules/lodash/_baseUnary.js
var require_baseUnary = __commonJS({
  "node_modules/lodash/_baseUnary.js"(exports2, module2) {
    function baseUnary2(func) {
      return function(value) {
        return func(value);
      };
    }
    module2.exports = baseUnary2;
  }
});

// node_modules/lodash/_nodeUtil.js
var require_nodeUtil = __commonJS({
  "node_modules/lodash/_nodeUtil.js"(exports2, module2) {
    var freeGlobal2 = require_freeGlobal();
    var freeExports4 = typeof exports2 == "object" && exports2 && !exports2.nodeType && exports2;
    var freeModule4 = freeExports4 && typeof module2 == "object" && module2 && !module2.nodeType && module2;
    var moduleExports4 = freeModule4 && freeModule4.exports === freeExports4;
    var freeProcess2 = moduleExports4 && freeGlobal2.process;
    var nodeUtil2 = function() {
      try {
        var types = freeModule4 && freeModule4.require && freeModule4.require("util").types;
        if (types) {
          return types;
        }
        return freeProcess2 && freeProcess2.binding && freeProcess2.binding("util");
      } catch (e9) {
      }
    }();
    module2.exports = nodeUtil2;
  }
});

// node_modules/lodash/isTypedArray.js
var require_isTypedArray = __commonJS({
  "node_modules/lodash/isTypedArray.js"(exports2, module2) {
    var baseIsTypedArray2 = require_baseIsTypedArray();
    var baseUnary2 = require_baseUnary();
    var nodeUtil2 = require_nodeUtil();
    var nodeIsTypedArray2 = nodeUtil2 && nodeUtil2.isTypedArray;
    var isTypedArray2 = nodeIsTypedArray2 ? baseUnary2(nodeIsTypedArray2) : baseIsTypedArray2;
    module2.exports = isTypedArray2;
  }
});

// node_modules/lodash/_arrayLikeKeys.js
var require_arrayLikeKeys = __commonJS({
  "node_modules/lodash/_arrayLikeKeys.js"(exports2, module2) {
    var baseTimes2 = require_baseTimes();
    var isArguments2 = require_isArguments();
    var isArray2 = require_isArray();
    var isBuffer2 = require_isBuffer();
    var isIndex2 = require_isIndex();
    var isTypedArray2 = require_isTypedArray();
    var objectProto16 = Object.prototype;
    var hasOwnProperty13 = objectProto16.hasOwnProperty;
    function arrayLikeKeys2(value, inherited) {
      var isArr = isArray2(value), isArg = !isArr && isArguments2(value), isBuff = !isArr && !isArg && isBuffer2(value), isType = !isArr && !isArg && !isBuff && isTypedArray2(value), skipIndexes = isArr || isArg || isBuff || isType, result = skipIndexes ? baseTimes2(value.length, String) : [], length = result.length;
      for (var key in value) {
        if ((inherited || hasOwnProperty13.call(value, key)) && !(skipIndexes && // Safari 9 has enumerable `arguments.length` in strict mode.
        (key == "length" || // Node.js 0.10 has enumerable non-index properties on buffers.
        isBuff && (key == "offset" || key == "parent") || // PhantomJS 2 has enumerable non-index properties on typed arrays.
        isType && (key == "buffer" || key == "byteLength" || key == "byteOffset") || // Skip index properties.
        isIndex2(key, length)))) {
          result.push(key);
        }
      }
      return result;
    }
    module2.exports = arrayLikeKeys2;
  }
});

// node_modules/lodash/_isPrototype.js
var require_isPrototype = __commonJS({
  "node_modules/lodash/_isPrototype.js"(exports2, module2) {
    var objectProto16 = Object.prototype;
    function isPrototype2(value) {
      var Ctor = value && value.constructor, proto = typeof Ctor == "function" && Ctor.prototype || objectProto16;
      return value === proto;
    }
    module2.exports = isPrototype2;
  }
});

// node_modules/lodash/_overArg.js
var require_overArg = __commonJS({
  "node_modules/lodash/_overArg.js"(exports2, module2) {
    function overArg2(func, transform) {
      return function(arg) {
        return func(transform(arg));
      };
    }
    module2.exports = overArg2;
  }
});

// node_modules/lodash/_nativeKeys.js
var require_nativeKeys = __commonJS({
  "node_modules/lodash/_nativeKeys.js"(exports2, module2) {
    var overArg2 = require_overArg();
    var nativeKeys2 = overArg2(Object.keys, Object);
    module2.exports = nativeKeys2;
  }
});

// node_modules/lodash/_baseKeys.js
var require_baseKeys = __commonJS({
  "node_modules/lodash/_baseKeys.js"(exports2, module2) {
    var isPrototype2 = require_isPrototype();
    var nativeKeys2 = require_nativeKeys();
    var objectProto16 = Object.prototype;
    var hasOwnProperty13 = objectProto16.hasOwnProperty;
    function baseKeys2(object) {
      if (!isPrototype2(object)) {
        return nativeKeys2(object);
      }
      var result = [];
      for (var key in Object(object)) {
        if (hasOwnProperty13.call(object, key) && key != "constructor") {
          result.push(key);
        }
      }
      return result;
    }
    module2.exports = baseKeys2;
  }
});

// node_modules/lodash/isObject.js
var require_isObject = __commonJS({
  "node_modules/lodash/isObject.js"(exports2, module2) {
    function isObject2(value) {
      var type = typeof value;
      return value != null && (type == "object" || type == "function");
    }
    module2.exports = isObject2;
  }
});

// node_modules/lodash/isFunction.js
var require_isFunction = __commonJS({
  "node_modules/lodash/isFunction.js"(exports2, module2) {
    var baseGetTag2 = require_baseGetTag();
    var isObject2 = require_isObject();
    var asyncTag2 = "[object AsyncFunction]";
    var funcTag3 = "[object Function]";
    var genTag2 = "[object GeneratorFunction]";
    var proxyTag2 = "[object Proxy]";
    function isFunction2(value) {
      if (!isObject2(value)) {
        return false;
      }
      var tag = baseGetTag2(value);
      return tag == funcTag3 || tag == genTag2 || tag == asyncTag2 || tag == proxyTag2;
    }
    module2.exports = isFunction2;
  }
});

// node_modules/lodash/isArrayLike.js
var require_isArrayLike = __commonJS({
  "node_modules/lodash/isArrayLike.js"(exports2, module2) {
    var isFunction2 = require_isFunction();
    var isLength2 = require_isLength();
    function isArrayLike2(value) {
      return value != null && isLength2(value.length) && !isFunction2(value);
    }
    module2.exports = isArrayLike2;
  }
});

// node_modules/lodash/keys.js
var require_keys = __commonJS({
  "node_modules/lodash/keys.js"(exports2, module2) {
    var arrayLikeKeys2 = require_arrayLikeKeys();
    var baseKeys2 = require_baseKeys();
    var isArrayLike2 = require_isArrayLike();
    function keys2(object) {
      return isArrayLike2(object) ? arrayLikeKeys2(object) : baseKeys2(object);
    }
    module2.exports = keys2;
  }
});

// node_modules/lodash/_baseForOwn.js
var require_baseForOwn = __commonJS({
  "node_modules/lodash/_baseForOwn.js"(exports2, module2) {
    var baseFor2 = require_baseFor();
    var keys2 = require_keys();
    function baseForOwn2(object, iteratee) {
      return object && baseFor2(object, iteratee, keys2);
    }
    module2.exports = baseForOwn2;
  }
});

// node_modules/lodash/identity.js
var require_identity = __commonJS({
  "node_modules/lodash/identity.js"(exports2, module2) {
    function identity2(value) {
      return value;
    }
    module2.exports = identity2;
  }
});

// node_modules/lodash/_castFunction.js
var require_castFunction = __commonJS({
  "node_modules/lodash/_castFunction.js"(exports2, module2) {
    var identity2 = require_identity();
    function castFunction2(value) {
      return typeof value == "function" ? value : identity2;
    }
    module2.exports = castFunction2;
  }
});

// node_modules/lodash/forOwn.js
var require_forOwn = __commonJS({
  "node_modules/lodash/forOwn.js"(exports2, module2) {
    var baseForOwn2 = require_baseForOwn();
    var castFunction2 = require_castFunction();
    function forOwn(object, iteratee) {
      return object && baseForOwn2(object, castFunction2(iteratee));
    }
    module2.exports = forOwn;
  }
});

// node_modules/lodash/_getPrototype.js
var require_getPrototype = __commonJS({
  "node_modules/lodash/_getPrototype.js"(exports2, module2) {
    var overArg2 = require_overArg();
    var getPrototype2 = overArg2(Object.getPrototypeOf, Object);
    module2.exports = getPrototype2;
  }
});

// node_modules/lodash/isPlainObject.js
var require_isPlainObject = __commonJS({
  "node_modules/lodash/isPlainObject.js"(exports2, module2) {
    var baseGetTag2 = require_baseGetTag();
    var getPrototype2 = require_getPrototype();
    var isObjectLike2 = require_isObjectLike();
    var objectTag5 = "[object Object]";
    var funcProto4 = Function.prototype;
    var objectProto16 = Object.prototype;
    var funcToString4 = funcProto4.toString;
    var hasOwnProperty13 = objectProto16.hasOwnProperty;
    var objectCtorString2 = funcToString4.call(Object);
    function isPlainObject2(value) {
      if (!isObjectLike2(value) || baseGetTag2(value) != objectTag5) {
        return false;
      }
      var proto = getPrototype2(value);
      if (proto === null) {
        return true;
      }
      var Ctor = hasOwnProperty13.call(proto, "constructor") && proto.constructor;
      return typeof Ctor == "function" && Ctor instanceof Ctor && funcToString4.call(Ctor) == objectCtorString2;
    }
    module2.exports = isPlainObject2;
  }
});

// node_modules/lodash/_arrayMap.js
var require_arrayMap = __commonJS({
  "node_modules/lodash/_arrayMap.js"(exports2, module2) {
    function arrayMap2(array, iteratee) {
      var index = -1, length = array == null ? 0 : array.length, result = Array(length);
      while (++index < length) {
        result[index] = iteratee(array[index], index, array);
      }
      return result;
    }
    module2.exports = arrayMap2;
  }
});

// node_modules/lodash/_listCacheClear.js
var require_listCacheClear = __commonJS({
  "node_modules/lodash/_listCacheClear.js"(exports2, module2) {
    function listCacheClear2() {
      this.__data__ = [];
      this.size = 0;
    }
    module2.exports = listCacheClear2;
  }
});

// node_modules/lodash/eq.js
var require_eq = __commonJS({
  "node_modules/lodash/eq.js"(exports2, module2) {
    function eq2(value, other) {
      return value === other || value !== value && other !== other;
    }
    module2.exports = eq2;
  }
});

// node_modules/lodash/_assocIndexOf.js
var require_assocIndexOf = __commonJS({
  "node_modules/lodash/_assocIndexOf.js"(exports2, module2) {
    var eq2 = require_eq();
    function assocIndexOf2(array, key) {
      var length = array.length;
      while (length--) {
        if (eq2(array[length][0], key)) {
          return length;
        }
      }
      return -1;
    }
    module2.exports = assocIndexOf2;
  }
});

// node_modules/lodash/_listCacheDelete.js
var require_listCacheDelete = __commonJS({
  "node_modules/lodash/_listCacheDelete.js"(exports2, module2) {
    var assocIndexOf2 = require_assocIndexOf();
    var arrayProto2 = Array.prototype;
    var splice2 = arrayProto2.splice;
    function listCacheDelete2(key) {
      var data = this.__data__, index = assocIndexOf2(data, key);
      if (index < 0) {
        return false;
      }
      var lastIndex = data.length - 1;
      if (index == lastIndex) {
        data.pop();
      } else {
        splice2.call(data, index, 1);
      }
      --this.size;
      return true;
    }
    module2.exports = listCacheDelete2;
  }
});

// node_modules/lodash/_listCacheGet.js
var require_listCacheGet = __commonJS({
  "node_modules/lodash/_listCacheGet.js"(exports2, module2) {
    var assocIndexOf2 = require_assocIndexOf();
    function listCacheGet2(key) {
      var data = this.__data__, index = assocIndexOf2(data, key);
      return index < 0 ? void 0 : data[index][1];
    }
    module2.exports = listCacheGet2;
  }
});

// node_modules/lodash/_listCacheHas.js
var require_listCacheHas = __commonJS({
  "node_modules/lodash/_listCacheHas.js"(exports2, module2) {
    var assocIndexOf2 = require_assocIndexOf();
    function listCacheHas2(key) {
      return assocIndexOf2(this.__data__, key) > -1;
    }
    module2.exports = listCacheHas2;
  }
});

// node_modules/lodash/_listCacheSet.js
var require_listCacheSet = __commonJS({
  "node_modules/lodash/_listCacheSet.js"(exports2, module2) {
    var assocIndexOf2 = require_assocIndexOf();
    function listCacheSet2(key, value) {
      var data = this.__data__, index = assocIndexOf2(data, key);
      if (index < 0) {
        ++this.size;
        data.push([key, value]);
      } else {
        data[index][1] = value;
      }
      return this;
    }
    module2.exports = listCacheSet2;
  }
});

// node_modules/lodash/_ListCache.js
var require_ListCache = __commonJS({
  "node_modules/lodash/_ListCache.js"(exports2, module2) {
    var listCacheClear2 = require_listCacheClear();
    var listCacheDelete2 = require_listCacheDelete();
    var listCacheGet2 = require_listCacheGet();
    var listCacheHas2 = require_listCacheHas();
    var listCacheSet2 = require_listCacheSet();
    function ListCache2(entries) {
      var index = -1, length = entries == null ? 0 : entries.length;
      this.clear();
      while (++index < length) {
        var entry = entries[index];
        this.set(entry[0], entry[1]);
      }
    }
    ListCache2.prototype.clear = listCacheClear2;
    ListCache2.prototype["delete"] = listCacheDelete2;
    ListCache2.prototype.get = listCacheGet2;
    ListCache2.prototype.has = listCacheHas2;
    ListCache2.prototype.set = listCacheSet2;
    module2.exports = ListCache2;
  }
});

// node_modules/lodash/_stackClear.js
var require_stackClear = __commonJS({
  "node_modules/lodash/_stackClear.js"(exports2, module2) {
    var ListCache2 = require_ListCache();
    function stackClear2() {
      this.__data__ = new ListCache2();
      this.size = 0;
    }
    module2.exports = stackClear2;
  }
});

// node_modules/lodash/_stackDelete.js
var require_stackDelete = __commonJS({
  "node_modules/lodash/_stackDelete.js"(exports2, module2) {
    function stackDelete2(key) {
      var data = this.__data__, result = data["delete"](key);
      this.size = data.size;
      return result;
    }
    module2.exports = stackDelete2;
  }
});

// node_modules/lodash/_stackGet.js
var require_stackGet = __commonJS({
  "node_modules/lodash/_stackGet.js"(exports2, module2) {
    function stackGet2(key) {
      return this.__data__.get(key);
    }
    module2.exports = stackGet2;
  }
});

// node_modules/lodash/_stackHas.js
var require_stackHas = __commonJS({
  "node_modules/lodash/_stackHas.js"(exports2, module2) {
    function stackHas2(key) {
      return this.__data__.has(key);
    }
    module2.exports = stackHas2;
  }
});

// node_modules/lodash/_coreJsData.js
var require_coreJsData = __commonJS({
  "node_modules/lodash/_coreJsData.js"(exports2, module2) {
    var root2 = require_root();
    var coreJsData2 = root2["__core-js_shared__"];
    module2.exports = coreJsData2;
  }
});

// node_modules/lodash/_isMasked.js
var require_isMasked = __commonJS({
  "node_modules/lodash/_isMasked.js"(exports2, module2) {
    var coreJsData2 = require_coreJsData();
    var maskSrcKey2 = function() {
      var uid = /[^.]+$/.exec(coreJsData2 && coreJsData2.keys && coreJsData2.keys.IE_PROTO || "");
      return uid ? "Symbol(src)_1." + uid : "";
    }();
    function isMasked2(func) {
      return !!maskSrcKey2 && maskSrcKey2 in func;
    }
    module2.exports = isMasked2;
  }
});

// node_modules/lodash/_toSource.js
var require_toSource = __commonJS({
  "node_modules/lodash/_toSource.js"(exports2, module2) {
    var funcProto4 = Function.prototype;
    var funcToString4 = funcProto4.toString;
    function toSource2(func) {
      if (func != null) {
        try {
          return funcToString4.call(func);
        } catch (e9) {
        }
        try {
          return func + "";
        } catch (e9) {
        }
      }
      return "";
    }
    module2.exports = toSource2;
  }
});

// node_modules/lodash/_baseIsNative.js
var require_baseIsNative = __commonJS({
  "node_modules/lodash/_baseIsNative.js"(exports2, module2) {
    var isFunction2 = require_isFunction();
    var isMasked2 = require_isMasked();
    var isObject2 = require_isObject();
    var toSource2 = require_toSource();
    var reRegExpChar2 = /[\\^$.*+?()[\]{}|]/g;
    var reIsHostCtor2 = /^\[object .+?Constructor\]$/;
    var funcProto4 = Function.prototype;
    var objectProto16 = Object.prototype;
    var funcToString4 = funcProto4.toString;
    var hasOwnProperty13 = objectProto16.hasOwnProperty;
    var reIsNative2 = RegExp(
      "^" + funcToString4.call(hasOwnProperty13).replace(reRegExpChar2, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$"
    );
    function baseIsNative2(value) {
      if (!isObject2(value) || isMasked2(value)) {
        return false;
      }
      var pattern = isFunction2(value) ? reIsNative2 : reIsHostCtor2;
      return pattern.test(toSource2(value));
    }
    module2.exports = baseIsNative2;
  }
});

// node_modules/lodash/_getValue.js
var require_getValue = __commonJS({
  "node_modules/lodash/_getValue.js"(exports2, module2) {
    function getValue2(object, key) {
      return object == null ? void 0 : object[key];
    }
    module2.exports = getValue2;
  }
});

// node_modules/lodash/_getNative.js
var require_getNative = __commonJS({
  "node_modules/lodash/_getNative.js"(exports2, module2) {
    var baseIsNative2 = require_baseIsNative();
    var getValue2 = require_getValue();
    function getNative2(object, key) {
      var value = getValue2(object, key);
      return baseIsNative2(value) ? value : void 0;
    }
    module2.exports = getNative2;
  }
});

// node_modules/lodash/_Map.js
var require_Map = __commonJS({
  "node_modules/lodash/_Map.js"(exports2, module2) {
    var getNative2 = require_getNative();
    var root2 = require_root();
    var Map3 = getNative2(root2, "Map");
    module2.exports = Map3;
  }
});

// node_modules/lodash/_nativeCreate.js
var require_nativeCreate = __commonJS({
  "node_modules/lodash/_nativeCreate.js"(exports2, module2) {
    var getNative2 = require_getNative();
    var nativeCreate2 = getNative2(Object, "create");
    module2.exports = nativeCreate2;
  }
});

// node_modules/lodash/_hashClear.js
var require_hashClear = __commonJS({
  "node_modules/lodash/_hashClear.js"(exports2, module2) {
    var nativeCreate2 = require_nativeCreate();
    function hashClear2() {
      this.__data__ = nativeCreate2 ? nativeCreate2(null) : {};
      this.size = 0;
    }
    module2.exports = hashClear2;
  }
});

// node_modules/lodash/_hashDelete.js
var require_hashDelete = __commonJS({
  "node_modules/lodash/_hashDelete.js"(exports2, module2) {
    function hashDelete2(key) {
      var result = this.has(key) && delete this.__data__[key];
      this.size -= result ? 1 : 0;
      return result;
    }
    module2.exports = hashDelete2;
  }
});

// node_modules/lodash/_hashGet.js
var require_hashGet = __commonJS({
  "node_modules/lodash/_hashGet.js"(exports2, module2) {
    var nativeCreate2 = require_nativeCreate();
    var HASH_UNDEFINED4 = "__lodash_hash_undefined__";
    var objectProto16 = Object.prototype;
    var hasOwnProperty13 = objectProto16.hasOwnProperty;
    function hashGet2(key) {
      var data = this.__data__;
      if (nativeCreate2) {
        var result = data[key];
        return result === HASH_UNDEFINED4 ? void 0 : result;
      }
      return hasOwnProperty13.call(data, key) ? data[key] : void 0;
    }
    module2.exports = hashGet2;
  }
});

// node_modules/lodash/_hashHas.js
var require_hashHas = __commonJS({
  "node_modules/lodash/_hashHas.js"(exports2, module2) {
    var nativeCreate2 = require_nativeCreate();
    var objectProto16 = Object.prototype;
    var hasOwnProperty13 = objectProto16.hasOwnProperty;
    function hashHas2(key) {
      var data = this.__data__;
      return nativeCreate2 ? data[key] !== void 0 : hasOwnProperty13.call(data, key);
    }
    module2.exports = hashHas2;
  }
});

// node_modules/lodash/_hashSet.js
var require_hashSet = __commonJS({
  "node_modules/lodash/_hashSet.js"(exports2, module2) {
    var nativeCreate2 = require_nativeCreate();
    var HASH_UNDEFINED4 = "__lodash_hash_undefined__";
    function hashSet2(key, value) {
      var data = this.__data__;
      this.size += this.has(key) ? 0 : 1;
      data[key] = nativeCreate2 && value === void 0 ? HASH_UNDEFINED4 : value;
      return this;
    }
    module2.exports = hashSet2;
  }
});

// node_modules/lodash/_Hash.js
var require_Hash = __commonJS({
  "node_modules/lodash/_Hash.js"(exports2, module2) {
    var hashClear2 = require_hashClear();
    var hashDelete2 = require_hashDelete();
    var hashGet2 = require_hashGet();
    var hashHas2 = require_hashHas();
    var hashSet2 = require_hashSet();
    function Hash2(entries) {
      var index = -1, length = entries == null ? 0 : entries.length;
      this.clear();
      while (++index < length) {
        var entry = entries[index];
        this.set(entry[0], entry[1]);
      }
    }
    Hash2.prototype.clear = hashClear2;
    Hash2.prototype["delete"] = hashDelete2;
    Hash2.prototype.get = hashGet2;
    Hash2.prototype.has = hashHas2;
    Hash2.prototype.set = hashSet2;
    module2.exports = Hash2;
  }
});

// node_modules/lodash/_mapCacheClear.js
var require_mapCacheClear = __commonJS({
  "node_modules/lodash/_mapCacheClear.js"(exports2, module2) {
    var Hash2 = require_Hash();
    var ListCache2 = require_ListCache();
    var Map3 = require_Map();
    function mapCacheClear2() {
      this.size = 0;
      this.__data__ = {
        "hash": new Hash2(),
        "map": new (Map3 || ListCache2)(),
        "string": new Hash2()
      };
    }
    module2.exports = mapCacheClear2;
  }
});

// node_modules/lodash/_isKeyable.js
var require_isKeyable = __commonJS({
  "node_modules/lodash/_isKeyable.js"(exports2, module2) {
    function isKeyable2(value) {
      var type = typeof value;
      return type == "string" || type == "number" || type == "symbol" || type == "boolean" ? value !== "__proto__" : value === null;
    }
    module2.exports = isKeyable2;
  }
});

// node_modules/lodash/_getMapData.js
var require_getMapData = __commonJS({
  "node_modules/lodash/_getMapData.js"(exports2, module2) {
    var isKeyable2 = require_isKeyable();
    function getMapData2(map2, key) {
      var data = map2.__data__;
      return isKeyable2(key) ? data[typeof key == "string" ? "string" : "hash"] : data.map;
    }
    module2.exports = getMapData2;
  }
});

// node_modules/lodash/_mapCacheDelete.js
var require_mapCacheDelete = __commonJS({
  "node_modules/lodash/_mapCacheDelete.js"(exports2, module2) {
    var getMapData2 = require_getMapData();
    function mapCacheDelete2(key) {
      var result = getMapData2(this, key)["delete"](key);
      this.size -= result ? 1 : 0;
      return result;
    }
    module2.exports = mapCacheDelete2;
  }
});

// node_modules/lodash/_mapCacheGet.js
var require_mapCacheGet = __commonJS({
  "node_modules/lodash/_mapCacheGet.js"(exports2, module2) {
    var getMapData2 = require_getMapData();
    function mapCacheGet2(key) {
      return getMapData2(this, key).get(key);
    }
    module2.exports = mapCacheGet2;
  }
});

// node_modules/lodash/_mapCacheHas.js
var require_mapCacheHas = __commonJS({
  "node_modules/lodash/_mapCacheHas.js"(exports2, module2) {
    var getMapData2 = require_getMapData();
    function mapCacheHas2(key) {
      return getMapData2(this, key).has(key);
    }
    module2.exports = mapCacheHas2;
  }
});

// node_modules/lodash/_mapCacheSet.js
var require_mapCacheSet = __commonJS({
  "node_modules/lodash/_mapCacheSet.js"(exports2, module2) {
    var getMapData2 = require_getMapData();
    function mapCacheSet2(key, value) {
      var data = getMapData2(this, key), size = data.size;
      data.set(key, value);
      this.size += data.size == size ? 0 : 1;
      return this;
    }
    module2.exports = mapCacheSet2;
  }
});

// node_modules/lodash/_MapCache.js
var require_MapCache = __commonJS({
  "node_modules/lodash/_MapCache.js"(exports2, module2) {
    var mapCacheClear2 = require_mapCacheClear();
    var mapCacheDelete2 = require_mapCacheDelete();
    var mapCacheGet2 = require_mapCacheGet();
    var mapCacheHas2 = require_mapCacheHas();
    var mapCacheSet2 = require_mapCacheSet();
    function MapCache2(entries) {
      var index = -1, length = entries == null ? 0 : entries.length;
      this.clear();
      while (++index < length) {
        var entry = entries[index];
        this.set(entry[0], entry[1]);
      }
    }
    MapCache2.prototype.clear = mapCacheClear2;
    MapCache2.prototype["delete"] = mapCacheDelete2;
    MapCache2.prototype.get = mapCacheGet2;
    MapCache2.prototype.has = mapCacheHas2;
    MapCache2.prototype.set = mapCacheSet2;
    module2.exports = MapCache2;
  }
});

// node_modules/lodash/_stackSet.js
var require_stackSet = __commonJS({
  "node_modules/lodash/_stackSet.js"(exports2, module2) {
    var ListCache2 = require_ListCache();
    var Map3 = require_Map();
    var MapCache2 = require_MapCache();
    var LARGE_ARRAY_SIZE2 = 200;
    function stackSet2(key, value) {
      var data = this.__data__;
      if (data instanceof ListCache2) {
        var pairs = data.__data__;
        if (!Map3 || pairs.length < LARGE_ARRAY_SIZE2 - 1) {
          pairs.push([key, value]);
          this.size = ++data.size;
          return this;
        }
        data = this.__data__ = new MapCache2(pairs);
      }
      data.set(key, value);
      this.size = data.size;
      return this;
    }
    module2.exports = stackSet2;
  }
});

// node_modules/lodash/_Stack.js
var require_Stack = __commonJS({
  "node_modules/lodash/_Stack.js"(exports2, module2) {
    var ListCache2 = require_ListCache();
    var stackClear2 = require_stackClear();
    var stackDelete2 = require_stackDelete();
    var stackGet2 = require_stackGet();
    var stackHas2 = require_stackHas();
    var stackSet2 = require_stackSet();
    function Stack2(entries) {
      var data = this.__data__ = new ListCache2(entries);
      this.size = data.size;
    }
    Stack2.prototype.clear = stackClear2;
    Stack2.prototype["delete"] = stackDelete2;
    Stack2.prototype.get = stackGet2;
    Stack2.prototype.has = stackHas2;
    Stack2.prototype.set = stackSet2;
    module2.exports = Stack2;
  }
});

// node_modules/lodash/_setCacheAdd.js
var require_setCacheAdd = __commonJS({
  "node_modules/lodash/_setCacheAdd.js"(exports2, module2) {
    var HASH_UNDEFINED4 = "__lodash_hash_undefined__";
    function setCacheAdd2(value) {
      this.__data__.set(value, HASH_UNDEFINED4);
      return this;
    }
    module2.exports = setCacheAdd2;
  }
});

// node_modules/lodash/_setCacheHas.js
var require_setCacheHas = __commonJS({
  "node_modules/lodash/_setCacheHas.js"(exports2, module2) {
    function setCacheHas2(value) {
      return this.__data__.has(value);
    }
    module2.exports = setCacheHas2;
  }
});

// node_modules/lodash/_SetCache.js
var require_SetCache = __commonJS({
  "node_modules/lodash/_SetCache.js"(exports2, module2) {
    var MapCache2 = require_MapCache();
    var setCacheAdd2 = require_setCacheAdd();
    var setCacheHas2 = require_setCacheHas();
    function SetCache2(values) {
      var index = -1, length = values == null ? 0 : values.length;
      this.__data__ = new MapCache2();
      while (++index < length) {
        this.add(values[index]);
      }
    }
    SetCache2.prototype.add = SetCache2.prototype.push = setCacheAdd2;
    SetCache2.prototype.has = setCacheHas2;
    module2.exports = SetCache2;
  }
});

// node_modules/lodash/_arraySome.js
var require_arraySome = __commonJS({
  "node_modules/lodash/_arraySome.js"(exports2, module2) {
    function arraySome2(array, predicate) {
      var index = -1, length = array == null ? 0 : array.length;
      while (++index < length) {
        if (predicate(array[index], index, array)) {
          return true;
        }
      }
      return false;
    }
    module2.exports = arraySome2;
  }
});

// node_modules/lodash/_cacheHas.js
var require_cacheHas = __commonJS({
  "node_modules/lodash/_cacheHas.js"(exports2, module2) {
    function cacheHas2(cache, key) {
      return cache.has(key);
    }
    module2.exports = cacheHas2;
  }
});

// node_modules/lodash/_equalArrays.js
var require_equalArrays = __commonJS({
  "node_modules/lodash/_equalArrays.js"(exports2, module2) {
    var SetCache2 = require_SetCache();
    var arraySome2 = require_arraySome();
    var cacheHas2 = require_cacheHas();
    var COMPARE_PARTIAL_FLAG7 = 1;
    var COMPARE_UNORDERED_FLAG5 = 2;
    function equalArrays2(array, other, bitmask, customizer, equalFunc, stack) {
      var isPartial = bitmask & COMPARE_PARTIAL_FLAG7, arrLength = array.length, othLength = other.length;
      if (arrLength != othLength && !(isPartial && othLength > arrLength)) {
        return false;
      }
      var arrStacked = stack.get(array);
      var othStacked = stack.get(other);
      if (arrStacked && othStacked) {
        return arrStacked == other && othStacked == array;
      }
      var index = -1, result = true, seen = bitmask & COMPARE_UNORDERED_FLAG5 ? new SetCache2() : void 0;
      stack.set(array, other);
      stack.set(other, array);
      while (++index < arrLength) {
        var arrValue = array[index], othValue = other[index];
        if (customizer) {
          var compared = isPartial ? customizer(othValue, arrValue, index, other, array, stack) : customizer(arrValue, othValue, index, array, other, stack);
        }
        if (compared !== void 0) {
          if (compared) {
            continue;
          }
          result = false;
          break;
        }
        if (seen) {
          if (!arraySome2(other, function(othValue2, othIndex) {
            if (!cacheHas2(seen, othIndex) && (arrValue === othValue2 || equalFunc(arrValue, othValue2, bitmask, customizer, stack))) {
              return seen.push(othIndex);
            }
          })) {
            result = false;
            break;
          }
        } else if (!(arrValue === othValue || equalFunc(arrValue, othValue, bitmask, customizer, stack))) {
          result = false;
          break;
        }
      }
      stack["delete"](array);
      stack["delete"](other);
      return result;
    }
    module2.exports = equalArrays2;
  }
});

// node_modules/lodash/_Uint8Array.js
var require_Uint8Array = __commonJS({
  "node_modules/lodash/_Uint8Array.js"(exports2, module2) {
    var root2 = require_root();
    var Uint8Array3 = root2.Uint8Array;
    module2.exports = Uint8Array3;
  }
});

// node_modules/lodash/_mapToArray.js
var require_mapToArray = __commonJS({
  "node_modules/lodash/_mapToArray.js"(exports2, module2) {
    function mapToArray2(map2) {
      var index = -1, result = Array(map2.size);
      map2.forEach(function(value, key) {
        result[++index] = [key, value];
      });
      return result;
    }
    module2.exports = mapToArray2;
  }
});

// node_modules/lodash/_setToArray.js
var require_setToArray = __commonJS({
  "node_modules/lodash/_setToArray.js"(exports2, module2) {
    function setToArray2(set) {
      var index = -1, result = Array(set.size);
      set.forEach(function(value) {
        result[++index] = value;
      });
      return result;
    }
    module2.exports = setToArray2;
  }
});

// node_modules/lodash/_equalByTag.js
var require_equalByTag = __commonJS({
  "node_modules/lodash/_equalByTag.js"(exports2, module2) {
    var Symbol3 = require_Symbol();
    var Uint8Array3 = require_Uint8Array();
    var eq2 = require_eq();
    var equalArrays2 = require_equalArrays();
    var mapToArray2 = require_mapToArray();
    var setToArray2 = require_setToArray();
    var COMPARE_PARTIAL_FLAG7 = 1;
    var COMPARE_UNORDERED_FLAG5 = 2;
    var boolTag3 = "[object Boolean]";
    var dateTag3 = "[object Date]";
    var errorTag3 = "[object Error]";
    var mapTag4 = "[object Map]";
    var numberTag3 = "[object Number]";
    var regexpTag3 = "[object RegExp]";
    var setTag4 = "[object Set]";
    var stringTag3 = "[object String]";
    var symbolTag3 = "[object Symbol]";
    var arrayBufferTag3 = "[object ArrayBuffer]";
    var dataViewTag4 = "[object DataView]";
    var symbolProto3 = Symbol3 ? Symbol3.prototype : void 0;
    var symbolValueOf2 = symbolProto3 ? symbolProto3.valueOf : void 0;
    function equalByTag2(object, other, tag, bitmask, customizer, equalFunc, stack) {
      switch (tag) {
        case dataViewTag4:
          if (object.byteLength != other.byteLength || object.byteOffset != other.byteOffset) {
            return false;
          }
          object = object.buffer;
          other = other.buffer;
        case arrayBufferTag3:
          if (object.byteLength != other.byteLength || !equalFunc(new Uint8Array3(object), new Uint8Array3(other))) {
            return false;
          }
          return true;
        case boolTag3:
        case dateTag3:
        case numberTag3:
          return eq2(+object, +other);
        case errorTag3:
          return object.name == other.name && object.message == other.message;
        case regexpTag3:
        case stringTag3:
          return object == other + "";
        case mapTag4:
          var convert = mapToArray2;
        case setTag4:
          var isPartial = bitmask & COMPARE_PARTIAL_FLAG7;
          convert || (convert = setToArray2);
          if (object.size != other.size && !isPartial) {
            return false;
          }
          var stacked = stack.get(object);
          if (stacked) {
            return stacked == other;
          }
          bitmask |= COMPARE_UNORDERED_FLAG5;
          stack.set(object, other);
          var result = equalArrays2(convert(object), convert(other), bitmask, customizer, equalFunc, stack);
          stack["delete"](object);
          return result;
        case symbolTag3:
          if (symbolValueOf2) {
            return symbolValueOf2.call(object) == symbolValueOf2.call(other);
          }
      }
      return false;
    }
    module2.exports = equalByTag2;
  }
});

// node_modules/lodash/_arrayPush.js
var require_arrayPush = __commonJS({
  "node_modules/lodash/_arrayPush.js"(exports2, module2) {
    function arrayPush2(array, values) {
      var index = -1, length = values.length, offset = array.length;
      while (++index < length) {
        array[offset + index] = values[index];
      }
      return array;
    }
    module2.exports = arrayPush2;
  }
});

// node_modules/lodash/_baseGetAllKeys.js
var require_baseGetAllKeys = __commonJS({
  "node_modules/lodash/_baseGetAllKeys.js"(exports2, module2) {
    var arrayPush2 = require_arrayPush();
    var isArray2 = require_isArray();
    function baseGetAllKeys2(object, keysFunc, symbolsFunc) {
      var result = keysFunc(object);
      return isArray2(object) ? result : arrayPush2(result, symbolsFunc(object));
    }
    module2.exports = baseGetAllKeys2;
  }
});

// node_modules/lodash/_arrayFilter.js
var require_arrayFilter = __commonJS({
  "node_modules/lodash/_arrayFilter.js"(exports2, module2) {
    function arrayFilter2(array, predicate) {
      var index = -1, length = array == null ? 0 : array.length, resIndex = 0, result = [];
      while (++index < length) {
        var value = array[index];
        if (predicate(value, index, array)) {
          result[resIndex++] = value;
        }
      }
      return result;
    }
    module2.exports = arrayFilter2;
  }
});

// node_modules/lodash/stubArray.js
var require_stubArray = __commonJS({
  "node_modules/lodash/stubArray.js"(exports2, module2) {
    function stubArray2() {
      return [];
    }
    module2.exports = stubArray2;
  }
});

// node_modules/lodash/_getSymbols.js
var require_getSymbols = __commonJS({
  "node_modules/lodash/_getSymbols.js"(exports2, module2) {
    var arrayFilter2 = require_arrayFilter();
    var stubArray2 = require_stubArray();
    var objectProto16 = Object.prototype;
    var propertyIsEnumerable3 = objectProto16.propertyIsEnumerable;
    var nativeGetSymbols2 = Object.getOwnPropertySymbols;
    var getSymbols2 = !nativeGetSymbols2 ? stubArray2 : function(object) {
      if (object == null) {
        return [];
      }
      object = Object(object);
      return arrayFilter2(nativeGetSymbols2(object), function(symbol) {
        return propertyIsEnumerable3.call(object, symbol);
      });
    };
    module2.exports = getSymbols2;
  }
});

// node_modules/lodash/_getAllKeys.js
var require_getAllKeys = __commonJS({
  "node_modules/lodash/_getAllKeys.js"(exports2, module2) {
    var baseGetAllKeys2 = require_baseGetAllKeys();
    var getSymbols2 = require_getSymbols();
    var keys2 = require_keys();
    function getAllKeys2(object) {
      return baseGetAllKeys2(object, keys2, getSymbols2);
    }
    module2.exports = getAllKeys2;
  }
});

// node_modules/lodash/_equalObjects.js
var require_equalObjects = __commonJS({
  "node_modules/lodash/_equalObjects.js"(exports2, module2) {
    var getAllKeys2 = require_getAllKeys();
    var COMPARE_PARTIAL_FLAG7 = 1;
    var objectProto16 = Object.prototype;
    var hasOwnProperty13 = objectProto16.hasOwnProperty;
    function equalObjects2(object, other, bitmask, customizer, equalFunc, stack) {
      var isPartial = bitmask & COMPARE_PARTIAL_FLAG7, objProps = getAllKeys2(object), objLength = objProps.length, othProps = getAllKeys2(other), othLength = othProps.length;
      if (objLength != othLength && !isPartial) {
        return false;
      }
      var index = objLength;
      while (index--) {
        var key = objProps[index];
        if (!(isPartial ? key in other : hasOwnProperty13.call(other, key))) {
          return false;
        }
      }
      var objStacked = stack.get(object);
      var othStacked = stack.get(other);
      if (objStacked && othStacked) {
        return objStacked == other && othStacked == object;
      }
      var result = true;
      stack.set(object, other);
      stack.set(other, object);
      var skipCtor = isPartial;
      while (++index < objLength) {
        key = objProps[index];
        var objValue = object[key], othValue = other[key];
        if (customizer) {
          var compared = isPartial ? customizer(othValue, objValue, key, other, object, stack) : customizer(objValue, othValue, key, object, other, stack);
        }
        if (!(compared === void 0 ? objValue === othValue || equalFunc(objValue, othValue, bitmask, customizer, stack) : compared)) {
          result = false;
          break;
        }
        skipCtor || (skipCtor = key == "constructor");
      }
      if (result && !skipCtor) {
        var objCtor = object.constructor, othCtor = other.constructor;
        if (objCtor != othCtor && ("constructor" in object && "constructor" in other) && !(typeof objCtor == "function" && objCtor instanceof objCtor && typeof othCtor == "function" && othCtor instanceof othCtor)) {
          result = false;
        }
      }
      stack["delete"](object);
      stack["delete"](other);
      return result;
    }
    module2.exports = equalObjects2;
  }
});

// node_modules/lodash/_DataView.js
var require_DataView = __commonJS({
  "node_modules/lodash/_DataView.js"(exports2, module2) {
    var getNative2 = require_getNative();
    var root2 = require_root();
    var DataView2 = getNative2(root2, "DataView");
    module2.exports = DataView2;
  }
});

// node_modules/lodash/_Promise.js
var require_Promise = __commonJS({
  "node_modules/lodash/_Promise.js"(exports2, module2) {
    var getNative2 = require_getNative();
    var root2 = require_root();
    var Promise3 = getNative2(root2, "Promise");
    module2.exports = Promise3;
  }
});

// node_modules/lodash/_Set.js
var require_Set = __commonJS({
  "node_modules/lodash/_Set.js"(exports2, module2) {
    var getNative2 = require_getNative();
    var root2 = require_root();
    var Set3 = getNative2(root2, "Set");
    module2.exports = Set3;
  }
});

// node_modules/lodash/_WeakMap.js
var require_WeakMap = __commonJS({
  "node_modules/lodash/_WeakMap.js"(exports2, module2) {
    var getNative2 = require_getNative();
    var root2 = require_root();
    var WeakMap3 = getNative2(root2, "WeakMap");
    module2.exports = WeakMap3;
  }
});

// node_modules/lodash/_getTag.js
var require_getTag = __commonJS({
  "node_modules/lodash/_getTag.js"(exports2, module2) {
    var DataView2 = require_DataView();
    var Map3 = require_Map();
    var Promise3 = require_Promise();
    var Set3 = require_Set();
    var WeakMap3 = require_WeakMap();
    var baseGetTag2 = require_baseGetTag();
    var toSource2 = require_toSource();
    var mapTag4 = "[object Map]";
    var objectTag5 = "[object Object]";
    var promiseTag2 = "[object Promise]";
    var setTag4 = "[object Set]";
    var weakMapTag3 = "[object WeakMap]";
    var dataViewTag4 = "[object DataView]";
    var dataViewCtorString2 = toSource2(DataView2);
    var mapCtorString2 = toSource2(Map3);
    var promiseCtorString2 = toSource2(Promise3);
    var setCtorString2 = toSource2(Set3);
    var weakMapCtorString2 = toSource2(WeakMap3);
    var getTag2 = baseGetTag2;
    if (DataView2 && getTag2(new DataView2(new ArrayBuffer(1))) != dataViewTag4 || Map3 && getTag2(new Map3()) != mapTag4 || Promise3 && getTag2(Promise3.resolve()) != promiseTag2 || Set3 && getTag2(new Set3()) != setTag4 || WeakMap3 && getTag2(new WeakMap3()) != weakMapTag3) {
      getTag2 = function(value) {
        var result = baseGetTag2(value), Ctor = result == objectTag5 ? value.constructor : void 0, ctorString = Ctor ? toSource2(Ctor) : "";
        if (ctorString) {
          switch (ctorString) {
            case dataViewCtorString2:
              return dataViewTag4;
            case mapCtorString2:
              return mapTag4;
            case promiseCtorString2:
              return promiseTag2;
            case setCtorString2:
              return setTag4;
            case weakMapCtorString2:
              return weakMapTag3;
          }
        }
        return result;
      };
    }
    module2.exports = getTag2;
  }
});

// node_modules/lodash/_baseIsEqualDeep.js
var require_baseIsEqualDeep = __commonJS({
  "node_modules/lodash/_baseIsEqualDeep.js"(exports2, module2) {
    var Stack2 = require_Stack();
    var equalArrays2 = require_equalArrays();
    var equalByTag2 = require_equalByTag();
    var equalObjects2 = require_equalObjects();
    var getTag2 = require_getTag();
    var isArray2 = require_isArray();
    var isBuffer2 = require_isBuffer();
    var isTypedArray2 = require_isTypedArray();
    var COMPARE_PARTIAL_FLAG7 = 1;
    var argsTag4 = "[object Arguments]";
    var arrayTag3 = "[object Array]";
    var objectTag5 = "[object Object]";
    var objectProto16 = Object.prototype;
    var hasOwnProperty13 = objectProto16.hasOwnProperty;
    function baseIsEqualDeep2(object, other, bitmask, customizer, equalFunc, stack) {
      var objIsArr = isArray2(object), othIsArr = isArray2(other), objTag = objIsArr ? arrayTag3 : getTag2(object), othTag = othIsArr ? arrayTag3 : getTag2(other);
      objTag = objTag == argsTag4 ? objectTag5 : objTag;
      othTag = othTag == argsTag4 ? objectTag5 : othTag;
      var objIsObj = objTag == objectTag5, othIsObj = othTag == objectTag5, isSameTag = objTag == othTag;
      if (isSameTag && isBuffer2(object)) {
        if (!isBuffer2(other)) {
          return false;
        }
        objIsArr = true;
        objIsObj = false;
      }
      if (isSameTag && !objIsObj) {
        stack || (stack = new Stack2());
        return objIsArr || isTypedArray2(object) ? equalArrays2(object, other, bitmask, customizer, equalFunc, stack) : equalByTag2(object, other, objTag, bitmask, customizer, equalFunc, stack);
      }
      if (!(bitmask & COMPARE_PARTIAL_FLAG7)) {
        var objIsWrapped = objIsObj && hasOwnProperty13.call(object, "__wrapped__"), othIsWrapped = othIsObj && hasOwnProperty13.call(other, "__wrapped__");
        if (objIsWrapped || othIsWrapped) {
          var objUnwrapped = objIsWrapped ? object.value() : object, othUnwrapped = othIsWrapped ? other.value() : other;
          stack || (stack = new Stack2());
          return equalFunc(objUnwrapped, othUnwrapped, bitmask, customizer, stack);
        }
      }
      if (!isSameTag) {
        return false;
      }
      stack || (stack = new Stack2());
      return equalObjects2(object, other, bitmask, customizer, equalFunc, stack);
    }
    module2.exports = baseIsEqualDeep2;
  }
});

// node_modules/lodash/_baseIsEqual.js
var require_baseIsEqual = __commonJS({
  "node_modules/lodash/_baseIsEqual.js"(exports2, module2) {
    var baseIsEqualDeep2 = require_baseIsEqualDeep();
    var isObjectLike2 = require_isObjectLike();
    function baseIsEqual2(value, other, bitmask, customizer, stack) {
      if (value === other) {
        return true;
      }
      if (value == null || other == null || !isObjectLike2(value) && !isObjectLike2(other)) {
        return value !== value && other !== other;
      }
      return baseIsEqualDeep2(value, other, bitmask, customizer, baseIsEqual2, stack);
    }
    module2.exports = baseIsEqual2;
  }
});

// node_modules/lodash/_baseIsMatch.js
var require_baseIsMatch = __commonJS({
  "node_modules/lodash/_baseIsMatch.js"(exports2, module2) {
    var Stack2 = require_Stack();
    var baseIsEqual2 = require_baseIsEqual();
    var COMPARE_PARTIAL_FLAG7 = 1;
    var COMPARE_UNORDERED_FLAG5 = 2;
    function baseIsMatch2(object, source, matchData, customizer) {
      var index = matchData.length, length = index, noCustomizer = !customizer;
      if (object == null) {
        return !length;
      }
      object = Object(object);
      while (index--) {
        var data = matchData[index];
        if (noCustomizer && data[2] ? data[1] !== object[data[0]] : !(data[0] in object)) {
          return false;
        }
      }
      while (++index < length) {
        data = matchData[index];
        var key = data[0], objValue = object[key], srcValue = data[1];
        if (noCustomizer && data[2]) {
          if (objValue === void 0 && !(key in object)) {
            return false;
          }
        } else {
          var stack = new Stack2();
          if (customizer) {
            var result = customizer(objValue, srcValue, key, object, source, stack);
          }
          if (!(result === void 0 ? baseIsEqual2(srcValue, objValue, COMPARE_PARTIAL_FLAG7 | COMPARE_UNORDERED_FLAG5, customizer, stack) : result)) {
            return false;
          }
        }
      }
      return true;
    }
    module2.exports = baseIsMatch2;
  }
});

// node_modules/lodash/_isStrictComparable.js
var require_isStrictComparable = __commonJS({
  "node_modules/lodash/_isStrictComparable.js"(exports2, module2) {
    var isObject2 = require_isObject();
    function isStrictComparable2(value) {
      return value === value && !isObject2(value);
    }
    module2.exports = isStrictComparable2;
  }
});

// node_modules/lodash/_getMatchData.js
var require_getMatchData = __commonJS({
  "node_modules/lodash/_getMatchData.js"(exports2, module2) {
    var isStrictComparable2 = require_isStrictComparable();
    var keys2 = require_keys();
    function getMatchData2(object) {
      var result = keys2(object), length = result.length;
      while (length--) {
        var key = result[length], value = object[key];
        result[length] = [key, value, isStrictComparable2(value)];
      }
      return result;
    }
    module2.exports = getMatchData2;
  }
});

// node_modules/lodash/_matchesStrictComparable.js
var require_matchesStrictComparable = __commonJS({
  "node_modules/lodash/_matchesStrictComparable.js"(exports2, module2) {
    function matchesStrictComparable2(key, srcValue) {
      return function(object) {
        if (object == null) {
          return false;
        }
        return object[key] === srcValue && (srcValue !== void 0 || key in Object(object));
      };
    }
    module2.exports = matchesStrictComparable2;
  }
});

// node_modules/lodash/_baseMatches.js
var require_baseMatches = __commonJS({
  "node_modules/lodash/_baseMatches.js"(exports2, module2) {
    var baseIsMatch2 = require_baseIsMatch();
    var getMatchData2 = require_getMatchData();
    var matchesStrictComparable2 = require_matchesStrictComparable();
    function baseMatches2(source) {
      var matchData = getMatchData2(source);
      if (matchData.length == 1 && matchData[0][2]) {
        return matchesStrictComparable2(matchData[0][0], matchData[0][1]);
      }
      return function(object) {
        return object === source || baseIsMatch2(object, source, matchData);
      };
    }
    module2.exports = baseMatches2;
  }
});

// node_modules/lodash/isSymbol.js
var require_isSymbol = __commonJS({
  "node_modules/lodash/isSymbol.js"(exports2, module2) {
    var baseGetTag2 = require_baseGetTag();
    var isObjectLike2 = require_isObjectLike();
    var symbolTag3 = "[object Symbol]";
    function isSymbol2(value) {
      return typeof value == "symbol" || isObjectLike2(value) && baseGetTag2(value) == symbolTag3;
    }
    module2.exports = isSymbol2;
  }
});

// node_modules/lodash/_isKey.js
var require_isKey = __commonJS({
  "node_modules/lodash/_isKey.js"(exports2, module2) {
    var isArray2 = require_isArray();
    var isSymbol2 = require_isSymbol();
    var reIsDeepProp2 = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/;
    var reIsPlainProp2 = /^\w*$/;
    function isKey2(value, object) {
      if (isArray2(value)) {
        return false;
      }
      var type = typeof value;
      if (type == "number" || type == "symbol" || type == "boolean" || value == null || isSymbol2(value)) {
        return true;
      }
      return reIsPlainProp2.test(value) || !reIsDeepProp2.test(value) || object != null && value in Object(object);
    }
    module2.exports = isKey2;
  }
});

// node_modules/lodash/memoize.js
var require_memoize = __commonJS({
  "node_modules/lodash/memoize.js"(exports2, module2) {
    var MapCache2 = require_MapCache();
    var FUNC_ERROR_TEXT4 = "Expected a function";
    function memoize2(func, resolver) {
      if (typeof func != "function" || resolver != null && typeof resolver != "function") {
        throw new TypeError(FUNC_ERROR_TEXT4);
      }
      var memoized = function() {
        var args = arguments, key = resolver ? resolver.apply(this, args) : args[0], cache = memoized.cache;
        if (cache.has(key)) {
          return cache.get(key);
        }
        var result = func.apply(this, args);
        memoized.cache = cache.set(key, result) || cache;
        return result;
      };
      memoized.cache = new (memoize2.Cache || MapCache2)();
      return memoized;
    }
    memoize2.Cache = MapCache2;
    module2.exports = memoize2;
  }
});

// node_modules/lodash/_memoizeCapped.js
var require_memoizeCapped = __commonJS({
  "node_modules/lodash/_memoizeCapped.js"(exports2, module2) {
    var memoize2 = require_memoize();
    var MAX_MEMOIZE_SIZE2 = 500;
    function memoizeCapped2(func) {
      var result = memoize2(func, function(key) {
        if (cache.size === MAX_MEMOIZE_SIZE2) {
          cache.clear();
        }
        return key;
      });
      var cache = result.cache;
      return result;
    }
    module2.exports = memoizeCapped2;
  }
});

// node_modules/lodash/_stringToPath.js
var require_stringToPath = __commonJS({
  "node_modules/lodash/_stringToPath.js"(exports2, module2) {
    var memoizeCapped2 = require_memoizeCapped();
    var rePropName2 = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g;
    var reEscapeChar2 = /\\(\\)?/g;
    var stringToPath2 = memoizeCapped2(function(string) {
      var result = [];
      if (string.charCodeAt(0) === 46) {
        result.push("");
      }
      string.replace(rePropName2, function(match, number, quote, subString) {
        result.push(quote ? subString.replace(reEscapeChar2, "$1") : number || match);
      });
      return result;
    });
    module2.exports = stringToPath2;
  }
});

// node_modules/lodash/_baseToString.js
var require_baseToString = __commonJS({
  "node_modules/lodash/_baseToString.js"(exports2, module2) {
    var Symbol3 = require_Symbol();
    var arrayMap2 = require_arrayMap();
    var isArray2 = require_isArray();
    var isSymbol2 = require_isSymbol();
    var INFINITY3 = 1 / 0;
    var symbolProto3 = Symbol3 ? Symbol3.prototype : void 0;
    var symbolToString2 = symbolProto3 ? symbolProto3.toString : void 0;
    function baseToString2(value) {
      if (typeof value == "string") {
        return value;
      }
      if (isArray2(value)) {
        return arrayMap2(value, baseToString2) + "";
      }
      if (isSymbol2(value)) {
        return symbolToString2 ? symbolToString2.call(value) : "";
      }
      var result = value + "";
      return result == "0" && 1 / value == -INFINITY3 ? "-0" : result;
    }
    module2.exports = baseToString2;
  }
});

// node_modules/lodash/toString.js
var require_toString = __commonJS({
  "node_modules/lodash/toString.js"(exports2, module2) {
    var baseToString2 = require_baseToString();
    function toString3(value) {
      return value == null ? "" : baseToString2(value);
    }
    module2.exports = toString3;
  }
});

// node_modules/lodash/_castPath.js
var require_castPath = __commonJS({
  "node_modules/lodash/_castPath.js"(exports2, module2) {
    var isArray2 = require_isArray();
    var isKey2 = require_isKey();
    var stringToPath2 = require_stringToPath();
    var toString3 = require_toString();
    function castPath2(value, object) {
      if (isArray2(value)) {
        return value;
      }
      return isKey2(value, object) ? [value] : stringToPath2(toString3(value));
    }
    module2.exports = castPath2;
  }
});

// node_modules/lodash/_toKey.js
var require_toKey = __commonJS({
  "node_modules/lodash/_toKey.js"(exports2, module2) {
    var isSymbol2 = require_isSymbol();
    var INFINITY3 = 1 / 0;
    function toKey2(value) {
      if (typeof value == "string" || isSymbol2(value)) {
        return value;
      }
      var result = value + "";
      return result == "0" && 1 / value == -INFINITY3 ? "-0" : result;
    }
    module2.exports = toKey2;
  }
});

// node_modules/lodash/_baseGet.js
var require_baseGet = __commonJS({
  "node_modules/lodash/_baseGet.js"(exports2, module2) {
    var castPath2 = require_castPath();
    var toKey2 = require_toKey();
    function baseGet2(object, path) {
      path = castPath2(path, object);
      var index = 0, length = path.length;
      while (object != null && index < length) {
        object = object[toKey2(path[index++])];
      }
      return index && index == length ? object : void 0;
    }
    module2.exports = baseGet2;
  }
});

// node_modules/lodash/get.js
var require_get = __commonJS({
  "node_modules/lodash/get.js"(exports2, module2) {
    var baseGet2 = require_baseGet();
    function get4(object, path, defaultValue) {
      var result = object == null ? void 0 : baseGet2(object, path);
      return result === void 0 ? defaultValue : result;
    }
    module2.exports = get4;
  }
});

// node_modules/lodash/_baseHasIn.js
var require_baseHasIn = __commonJS({
  "node_modules/lodash/_baseHasIn.js"(exports2, module2) {
    function baseHasIn2(object, key) {
      return object != null && key in Object(object);
    }
    module2.exports = baseHasIn2;
  }
});

// node_modules/lodash/_hasPath.js
var require_hasPath = __commonJS({
  "node_modules/lodash/_hasPath.js"(exports2, module2) {
    var castPath2 = require_castPath();
    var isArguments2 = require_isArguments();
    var isArray2 = require_isArray();
    var isIndex2 = require_isIndex();
    var isLength2 = require_isLength();
    var toKey2 = require_toKey();
    function hasPath2(object, path, hasFunc) {
      path = castPath2(path, object);
      var index = -1, length = path.length, result = false;
      while (++index < length) {
        var key = toKey2(path[index]);
        if (!(result = object != null && hasFunc(object, key))) {
          break;
        }
        object = object[key];
      }
      if (result || ++index != length) {
        return result;
      }
      length = object == null ? 0 : object.length;
      return !!length && isLength2(length) && isIndex2(key, length) && (isArray2(object) || isArguments2(object));
    }
    module2.exports = hasPath2;
  }
});

// node_modules/lodash/hasIn.js
var require_hasIn = __commonJS({
  "node_modules/lodash/hasIn.js"(exports2, module2) {
    var baseHasIn2 = require_baseHasIn();
    var hasPath2 = require_hasPath();
    function hasIn2(object, path) {
      return object != null && hasPath2(object, path, baseHasIn2);
    }
    module2.exports = hasIn2;
  }
});

// node_modules/lodash/_baseMatchesProperty.js
var require_baseMatchesProperty = __commonJS({
  "node_modules/lodash/_baseMatchesProperty.js"(exports2, module2) {
    var baseIsEqual2 = require_baseIsEqual();
    var get4 = require_get();
    var hasIn2 = require_hasIn();
    var isKey2 = require_isKey();
    var isStrictComparable2 = require_isStrictComparable();
    var matchesStrictComparable2 = require_matchesStrictComparable();
    var toKey2 = require_toKey();
    var COMPARE_PARTIAL_FLAG7 = 1;
    var COMPARE_UNORDERED_FLAG5 = 2;
    function baseMatchesProperty2(path, srcValue) {
      if (isKey2(path) && isStrictComparable2(srcValue)) {
        return matchesStrictComparable2(toKey2(path), srcValue);
      }
      return function(object) {
        var objValue = get4(object, path);
        return objValue === void 0 && objValue === srcValue ? hasIn2(object, path) : baseIsEqual2(srcValue, objValue, COMPARE_PARTIAL_FLAG7 | COMPARE_UNORDERED_FLAG5);
      };
    }
    module2.exports = baseMatchesProperty2;
  }
});

// node_modules/lodash/_baseProperty.js
var require_baseProperty = __commonJS({
  "node_modules/lodash/_baseProperty.js"(exports2, module2) {
    function baseProperty2(key) {
      return function(object) {
        return object == null ? void 0 : object[key];
      };
    }
    module2.exports = baseProperty2;
  }
});

// node_modules/lodash/_basePropertyDeep.js
var require_basePropertyDeep = __commonJS({
  "node_modules/lodash/_basePropertyDeep.js"(exports2, module2) {
    var baseGet2 = require_baseGet();
    function basePropertyDeep2(path) {
      return function(object) {
        return baseGet2(object, path);
      };
    }
    module2.exports = basePropertyDeep2;
  }
});

// node_modules/lodash/property.js
var require_property = __commonJS({
  "node_modules/lodash/property.js"(exports2, module2) {
    var baseProperty2 = require_baseProperty();
    var basePropertyDeep2 = require_basePropertyDeep();
    var isKey2 = require_isKey();
    var toKey2 = require_toKey();
    function property2(path) {
      return isKey2(path) ? baseProperty2(toKey2(path)) : basePropertyDeep2(path);
    }
    module2.exports = property2;
  }
});

// node_modules/lodash/_baseIteratee.js
var require_baseIteratee = __commonJS({
  "node_modules/lodash/_baseIteratee.js"(exports2, module2) {
    var baseMatches2 = require_baseMatches();
    var baseMatchesProperty2 = require_baseMatchesProperty();
    var identity2 = require_identity();
    var isArray2 = require_isArray();
    var property2 = require_property();
    function baseIteratee2(value) {
      if (typeof value == "function") {
        return value;
      }
      if (value == null) {
        return identity2;
      }
      if (typeof value == "object") {
        return isArray2(value) ? baseMatchesProperty2(value[0], value[1]) : baseMatches2(value);
      }
      return property2(value);
    }
    module2.exports = baseIteratee2;
  }
});

// node_modules/lodash/_createBaseEach.js
var require_createBaseEach = __commonJS({
  "node_modules/lodash/_createBaseEach.js"(exports2, module2) {
    var isArrayLike2 = require_isArrayLike();
    function createBaseEach2(eachFunc, fromRight) {
      return function(collection, iteratee) {
        if (collection == null) {
          return collection;
        }
        if (!isArrayLike2(collection)) {
          return eachFunc(collection, iteratee);
        }
        var length = collection.length, index = fromRight ? length : -1, iterable = Object(collection);
        while (fromRight ? index-- : ++index < length) {
          if (iteratee(iterable[index], index, iterable) === false) {
            break;
          }
        }
        return collection;
      };
    }
    module2.exports = createBaseEach2;
  }
});

// node_modules/lodash/_baseEach.js
var require_baseEach = __commonJS({
  "node_modules/lodash/_baseEach.js"(exports2, module2) {
    var baseForOwn2 = require_baseForOwn();
    var createBaseEach2 = require_createBaseEach();
    var baseEach2 = createBaseEach2(baseForOwn2);
    module2.exports = baseEach2;
  }
});

// node_modules/lodash/_baseMap.js
var require_baseMap = __commonJS({
  "node_modules/lodash/_baseMap.js"(exports2, module2) {
    var baseEach2 = require_baseEach();
    var isArrayLike2 = require_isArrayLike();
    function baseMap2(collection, iteratee) {
      var index = -1, result = isArrayLike2(collection) ? Array(collection.length) : [];
      baseEach2(collection, function(value, key, collection2) {
        result[++index] = iteratee(value, key, collection2);
      });
      return result;
    }
    module2.exports = baseMap2;
  }
});

// node_modules/lodash/map.js
var require_map = __commonJS({
  "node_modules/lodash/map.js"(exports2, module2) {
    var arrayMap2 = require_arrayMap();
    var baseIteratee2 = require_baseIteratee();
    var baseMap2 = require_baseMap();
    var isArray2 = require_isArray();
    function map2(collection, iteratee) {
      var func = isArray2(collection) ? arrayMap2 : baseMap2;
      return func(collection, baseIteratee2(iteratee, 3));
    }
    module2.exports = map2;
  }
});

// node_modules/reactcss/lib/flattenNames.js
var require_flattenNames = __commonJS({
  "node_modules/reactcss/lib/flattenNames.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", {
      value: true
    });
    exports2.flattenNames = void 0;
    var _isString2 = require_isString();
    var _isString3 = _interopRequireDefault(_isString2);
    var _forOwn2 = require_forOwn();
    var _forOwn3 = _interopRequireDefault(_forOwn2);
    var _isPlainObject2 = require_isPlainObject();
    var _isPlainObject3 = _interopRequireDefault(_isPlainObject2);
    var _map2 = require_map();
    var _map3 = _interopRequireDefault(_map2);
    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { default: obj };
    }
    var flattenNames = exports2.flattenNames = function flattenNames2() {
      var things = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : [];
      var names2 = [];
      (0, _map3.default)(things, function(thing) {
        if (Array.isArray(thing)) {
          flattenNames2(thing).map(function(name) {
            return names2.push(name);
          });
        } else if ((0, _isPlainObject3.default)(thing)) {
          (0, _forOwn3.default)(thing, function(value, key) {
            value === true && names2.push(key);
            names2.push(key + "-" + value);
          });
        } else if ((0, _isString3.default)(thing)) {
          names2.push(thing);
        }
      });
      return names2;
    };
    exports2.default = flattenNames;
  }
});

// node_modules/lodash/_arrayEach.js
var require_arrayEach = __commonJS({
  "node_modules/lodash/_arrayEach.js"(exports2, module2) {
    function arrayEach2(array, iteratee) {
      var index = -1, length = array == null ? 0 : array.length;
      while (++index < length) {
        if (iteratee(array[index], index, array) === false) {
          break;
        }
      }
      return array;
    }
    module2.exports = arrayEach2;
  }
});

// node_modules/lodash/_defineProperty.js
var require_defineProperty = __commonJS({
  "node_modules/lodash/_defineProperty.js"(exports2, module2) {
    var getNative2 = require_getNative();
    var defineProperty2 = function() {
      try {
        var func = getNative2(Object, "defineProperty");
        func({}, "", {});
        return func;
      } catch (e9) {
      }
    }();
    module2.exports = defineProperty2;
  }
});

// node_modules/lodash/_baseAssignValue.js
var require_baseAssignValue = __commonJS({
  "node_modules/lodash/_baseAssignValue.js"(exports2, module2) {
    var defineProperty2 = require_defineProperty();
    function baseAssignValue2(object, key, value) {
      if (key == "__proto__" && defineProperty2) {
        defineProperty2(object, key, {
          "configurable": true,
          "enumerable": true,
          "value": value,
          "writable": true
        });
      } else {
        object[key] = value;
      }
    }
    module2.exports = baseAssignValue2;
  }
});

// node_modules/lodash/_assignValue.js
var require_assignValue = __commonJS({
  "node_modules/lodash/_assignValue.js"(exports2, module2) {
    var baseAssignValue2 = require_baseAssignValue();
    var eq2 = require_eq();
    var objectProto16 = Object.prototype;
    var hasOwnProperty13 = objectProto16.hasOwnProperty;
    function assignValue2(object, key, value) {
      var objValue = object[key];
      if (!(hasOwnProperty13.call(object, key) && eq2(objValue, value)) || value === void 0 && !(key in object)) {
        baseAssignValue2(object, key, value);
      }
    }
    module2.exports = assignValue2;
  }
});

// node_modules/lodash/_copyObject.js
var require_copyObject = __commonJS({
  "node_modules/lodash/_copyObject.js"(exports2, module2) {
    var assignValue2 = require_assignValue();
    var baseAssignValue2 = require_baseAssignValue();
    function copyObject2(source, props, object, customizer) {
      var isNew = !object;
      object || (object = {});
      var index = -1, length = props.length;
      while (++index < length) {
        var key = props[index];
        var newValue = customizer ? customizer(object[key], source[key], key, object, source) : void 0;
        if (newValue === void 0) {
          newValue = source[key];
        }
        if (isNew) {
          baseAssignValue2(object, key, newValue);
        } else {
          assignValue2(object, key, newValue);
        }
      }
      return object;
    }
    module2.exports = copyObject2;
  }
});

// node_modules/lodash/_baseAssign.js
var require_baseAssign = __commonJS({
  "node_modules/lodash/_baseAssign.js"(exports2, module2) {
    var copyObject2 = require_copyObject();
    var keys2 = require_keys();
    function baseAssign(object, source) {
      return object && copyObject2(source, keys2(source), object);
    }
    module2.exports = baseAssign;
  }
});

// node_modules/lodash/_nativeKeysIn.js
var require_nativeKeysIn = __commonJS({
  "node_modules/lodash/_nativeKeysIn.js"(exports2, module2) {
    function nativeKeysIn2(object) {
      var result = [];
      if (object != null) {
        for (var key in Object(object)) {
          result.push(key);
        }
      }
      return result;
    }
    module2.exports = nativeKeysIn2;
  }
});

// node_modules/lodash/_baseKeysIn.js
var require_baseKeysIn = __commonJS({
  "node_modules/lodash/_baseKeysIn.js"(exports2, module2) {
    var isObject2 = require_isObject();
    var isPrototype2 = require_isPrototype();
    var nativeKeysIn2 = require_nativeKeysIn();
    var objectProto16 = Object.prototype;
    var hasOwnProperty13 = objectProto16.hasOwnProperty;
    function baseKeysIn2(object) {
      if (!isObject2(object)) {
        return nativeKeysIn2(object);
      }
      var isProto = isPrototype2(object), result = [];
      for (var key in object) {
        if (!(key == "constructor" && (isProto || !hasOwnProperty13.call(object, key)))) {
          result.push(key);
        }
      }
      return result;
    }
    module2.exports = baseKeysIn2;
  }
});

// node_modules/lodash/keysIn.js
var require_keysIn = __commonJS({
  "node_modules/lodash/keysIn.js"(exports2, module2) {
    var arrayLikeKeys2 = require_arrayLikeKeys();
    var baseKeysIn2 = require_baseKeysIn();
    var isArrayLike2 = require_isArrayLike();
    function keysIn2(object) {
      return isArrayLike2(object) ? arrayLikeKeys2(object, true) : baseKeysIn2(object);
    }
    module2.exports = keysIn2;
  }
});

// node_modules/lodash/_baseAssignIn.js
var require_baseAssignIn = __commonJS({
  "node_modules/lodash/_baseAssignIn.js"(exports2, module2) {
    var copyObject2 = require_copyObject();
    var keysIn2 = require_keysIn();
    function baseAssignIn(object, source) {
      return object && copyObject2(source, keysIn2(source), object);
    }
    module2.exports = baseAssignIn;
  }
});

// node_modules/lodash/_cloneBuffer.js
var require_cloneBuffer = __commonJS({
  "node_modules/lodash/_cloneBuffer.js"(exports2, module2) {
    var root2 = require_root();
    var freeExports4 = typeof exports2 == "object" && exports2 && !exports2.nodeType && exports2;
    var freeModule4 = freeExports4 && typeof module2 == "object" && module2 && !module2.nodeType && module2;
    var moduleExports4 = freeModule4 && freeModule4.exports === freeExports4;
    var Buffer4 = moduleExports4 ? root2.Buffer : void 0;
    var allocUnsafe2 = Buffer4 ? Buffer4.allocUnsafe : void 0;
    function cloneBuffer2(buffer, isDeep) {
      if (isDeep) {
        return buffer.slice();
      }
      var length = buffer.length, result = allocUnsafe2 ? allocUnsafe2(length) : new buffer.constructor(length);
      buffer.copy(result);
      return result;
    }
    module2.exports = cloneBuffer2;
  }
});

// node_modules/lodash/_copyArray.js
var require_copyArray = __commonJS({
  "node_modules/lodash/_copyArray.js"(exports2, module2) {
    function copyArray2(source, array) {
      var index = -1, length = source.length;
      array || (array = Array(length));
      while (++index < length) {
        array[index] = source[index];
      }
      return array;
    }
    module2.exports = copyArray2;
  }
});

// node_modules/lodash/_copySymbols.js
var require_copySymbols = __commonJS({
  "node_modules/lodash/_copySymbols.js"(exports2, module2) {
    var copyObject2 = require_copyObject();
    var getSymbols2 = require_getSymbols();
    function copySymbols(source, object) {
      return copyObject2(source, getSymbols2(source), object);
    }
    module2.exports = copySymbols;
  }
});

// node_modules/lodash/_getSymbolsIn.js
var require_getSymbolsIn = __commonJS({
  "node_modules/lodash/_getSymbolsIn.js"(exports2, module2) {
    var arrayPush2 = require_arrayPush();
    var getPrototype2 = require_getPrototype();
    var getSymbols2 = require_getSymbols();
    var stubArray2 = require_stubArray();
    var nativeGetSymbols2 = Object.getOwnPropertySymbols;
    var getSymbolsIn = !nativeGetSymbols2 ? stubArray2 : function(object) {
      var result = [];
      while (object) {
        arrayPush2(result, getSymbols2(object));
        object = getPrototype2(object);
      }
      return result;
    };
    module2.exports = getSymbolsIn;
  }
});

// node_modules/lodash/_copySymbolsIn.js
var require_copySymbolsIn = __commonJS({
  "node_modules/lodash/_copySymbolsIn.js"(exports2, module2) {
    var copyObject2 = require_copyObject();
    var getSymbolsIn = require_getSymbolsIn();
    function copySymbolsIn(source, object) {
      return copyObject2(source, getSymbolsIn(source), object);
    }
    module2.exports = copySymbolsIn;
  }
});

// node_modules/lodash/_getAllKeysIn.js
var require_getAllKeysIn = __commonJS({
  "node_modules/lodash/_getAllKeysIn.js"(exports2, module2) {
    var baseGetAllKeys2 = require_baseGetAllKeys();
    var getSymbolsIn = require_getSymbolsIn();
    var keysIn2 = require_keysIn();
    function getAllKeysIn(object) {
      return baseGetAllKeys2(object, keysIn2, getSymbolsIn);
    }
    module2.exports = getAllKeysIn;
  }
});

// node_modules/lodash/_initCloneArray.js
var require_initCloneArray = __commonJS({
  "node_modules/lodash/_initCloneArray.js"(exports2, module2) {
    var objectProto16 = Object.prototype;
    var hasOwnProperty13 = objectProto16.hasOwnProperty;
    function initCloneArray(array) {
      var length = array.length, result = new array.constructor(length);
      if (length && typeof array[0] == "string" && hasOwnProperty13.call(array, "index")) {
        result.index = array.index;
        result.input = array.input;
      }
      return result;
    }
    module2.exports = initCloneArray;
  }
});

// node_modules/lodash/_cloneArrayBuffer.js
var require_cloneArrayBuffer = __commonJS({
  "node_modules/lodash/_cloneArrayBuffer.js"(exports2, module2) {
    var Uint8Array3 = require_Uint8Array();
    function cloneArrayBuffer2(arrayBuffer) {
      var result = new arrayBuffer.constructor(arrayBuffer.byteLength);
      new Uint8Array3(result).set(new Uint8Array3(arrayBuffer));
      return result;
    }
    module2.exports = cloneArrayBuffer2;
  }
});

// node_modules/lodash/_cloneDataView.js
var require_cloneDataView = __commonJS({
  "node_modules/lodash/_cloneDataView.js"(exports2, module2) {
    var cloneArrayBuffer2 = require_cloneArrayBuffer();
    function cloneDataView(dataView, isDeep) {
      var buffer = isDeep ? cloneArrayBuffer2(dataView.buffer) : dataView.buffer;
      return new dataView.constructor(buffer, dataView.byteOffset, dataView.byteLength);
    }
    module2.exports = cloneDataView;
  }
});

// node_modules/lodash/_cloneRegExp.js
var require_cloneRegExp = __commonJS({
  "node_modules/lodash/_cloneRegExp.js"(exports2, module2) {
    var reFlags = /\w*$/;
    function cloneRegExp(regexp) {
      var result = new regexp.constructor(regexp.source, reFlags.exec(regexp));
      result.lastIndex = regexp.lastIndex;
      return result;
    }
    module2.exports = cloneRegExp;
  }
});

// node_modules/lodash/_cloneSymbol.js
var require_cloneSymbol = __commonJS({
  "node_modules/lodash/_cloneSymbol.js"(exports2, module2) {
    var Symbol3 = require_Symbol();
    var symbolProto3 = Symbol3 ? Symbol3.prototype : void 0;
    var symbolValueOf2 = symbolProto3 ? symbolProto3.valueOf : void 0;
    function cloneSymbol(symbol) {
      return symbolValueOf2 ? Object(symbolValueOf2.call(symbol)) : {};
    }
    module2.exports = cloneSymbol;
  }
});

// node_modules/lodash/_cloneTypedArray.js
var require_cloneTypedArray = __commonJS({
  "node_modules/lodash/_cloneTypedArray.js"(exports2, module2) {
    var cloneArrayBuffer2 = require_cloneArrayBuffer();
    function cloneTypedArray2(typedArray, isDeep) {
      var buffer = isDeep ? cloneArrayBuffer2(typedArray.buffer) : typedArray.buffer;
      return new typedArray.constructor(buffer, typedArray.byteOffset, typedArray.length);
    }
    module2.exports = cloneTypedArray2;
  }
});

// node_modules/lodash/_initCloneByTag.js
var require_initCloneByTag = __commonJS({
  "node_modules/lodash/_initCloneByTag.js"(exports2, module2) {
    var cloneArrayBuffer2 = require_cloneArrayBuffer();
    var cloneDataView = require_cloneDataView();
    var cloneRegExp = require_cloneRegExp();
    var cloneSymbol = require_cloneSymbol();
    var cloneTypedArray2 = require_cloneTypedArray();
    var boolTag3 = "[object Boolean]";
    var dateTag3 = "[object Date]";
    var mapTag4 = "[object Map]";
    var numberTag3 = "[object Number]";
    var regexpTag3 = "[object RegExp]";
    var setTag4 = "[object Set]";
    var stringTag3 = "[object String]";
    var symbolTag3 = "[object Symbol]";
    var arrayBufferTag3 = "[object ArrayBuffer]";
    var dataViewTag4 = "[object DataView]";
    var float32Tag2 = "[object Float32Array]";
    var float64Tag2 = "[object Float64Array]";
    var int8Tag2 = "[object Int8Array]";
    var int16Tag2 = "[object Int16Array]";
    var int32Tag2 = "[object Int32Array]";
    var uint8Tag2 = "[object Uint8Array]";
    var uint8ClampedTag2 = "[object Uint8ClampedArray]";
    var uint16Tag2 = "[object Uint16Array]";
    var uint32Tag2 = "[object Uint32Array]";
    function initCloneByTag(object, tag, isDeep) {
      var Ctor = object.constructor;
      switch (tag) {
        case arrayBufferTag3:
          return cloneArrayBuffer2(object);
        case boolTag3:
        case dateTag3:
          return new Ctor(+object);
        case dataViewTag4:
          return cloneDataView(object, isDeep);
        case float32Tag2:
        case float64Tag2:
        case int8Tag2:
        case int16Tag2:
        case int32Tag2:
        case uint8Tag2:
        case uint8ClampedTag2:
        case uint16Tag2:
        case uint32Tag2:
          return cloneTypedArray2(object, isDeep);
        case mapTag4:
          return new Ctor();
        case numberTag3:
        case stringTag3:
          return new Ctor(object);
        case regexpTag3:
          return cloneRegExp(object);
        case setTag4:
          return new Ctor();
        case symbolTag3:
          return cloneSymbol(object);
      }
    }
    module2.exports = initCloneByTag;
  }
});

// node_modules/lodash/_baseCreate.js
var require_baseCreate = __commonJS({
  "node_modules/lodash/_baseCreate.js"(exports2, module2) {
    var isObject2 = require_isObject();
    var objectCreate2 = Object.create;
    var baseCreate2 = function() {
      function object() {
      }
      return function(proto) {
        if (!isObject2(proto)) {
          return {};
        }
        if (objectCreate2) {
          return objectCreate2(proto);
        }
        object.prototype = proto;
        var result = new object();
        object.prototype = void 0;
        return result;
      };
    }();
    module2.exports = baseCreate2;
  }
});

// node_modules/lodash/_initCloneObject.js
var require_initCloneObject = __commonJS({
  "node_modules/lodash/_initCloneObject.js"(exports2, module2) {
    var baseCreate2 = require_baseCreate();
    var getPrototype2 = require_getPrototype();
    var isPrototype2 = require_isPrototype();
    function initCloneObject2(object) {
      return typeof object.constructor == "function" && !isPrototype2(object) ? baseCreate2(getPrototype2(object)) : {};
    }
    module2.exports = initCloneObject2;
  }
});

// node_modules/lodash/_baseIsMap.js
var require_baseIsMap = __commonJS({
  "node_modules/lodash/_baseIsMap.js"(exports2, module2) {
    var getTag2 = require_getTag();
    var isObjectLike2 = require_isObjectLike();
    var mapTag4 = "[object Map]";
    function baseIsMap(value) {
      return isObjectLike2(value) && getTag2(value) == mapTag4;
    }
    module2.exports = baseIsMap;
  }
});

// node_modules/lodash/isMap.js
var require_isMap = __commonJS({
  "node_modules/lodash/isMap.js"(exports2, module2) {
    var baseIsMap = require_baseIsMap();
    var baseUnary2 = require_baseUnary();
    var nodeUtil2 = require_nodeUtil();
    var nodeIsMap = nodeUtil2 && nodeUtil2.isMap;
    var isMap = nodeIsMap ? baseUnary2(nodeIsMap) : baseIsMap;
    module2.exports = isMap;
  }
});

// node_modules/lodash/_baseIsSet.js
var require_baseIsSet = __commonJS({
  "node_modules/lodash/_baseIsSet.js"(exports2, module2) {
    var getTag2 = require_getTag();
    var isObjectLike2 = require_isObjectLike();
    var setTag4 = "[object Set]";
    function baseIsSet(value) {
      return isObjectLike2(value) && getTag2(value) == setTag4;
    }
    module2.exports = baseIsSet;
  }
});

// node_modules/lodash/isSet.js
var require_isSet = __commonJS({
  "node_modules/lodash/isSet.js"(exports2, module2) {
    var baseIsSet = require_baseIsSet();
    var baseUnary2 = require_baseUnary();
    var nodeUtil2 = require_nodeUtil();
    var nodeIsSet = nodeUtil2 && nodeUtil2.isSet;
    var isSet = nodeIsSet ? baseUnary2(nodeIsSet) : baseIsSet;
    module2.exports = isSet;
  }
});

// node_modules/lodash/_baseClone.js
var require_baseClone = __commonJS({
  "node_modules/lodash/_baseClone.js"(exports2, module2) {
    var Stack2 = require_Stack();
    var arrayEach2 = require_arrayEach();
    var assignValue2 = require_assignValue();
    var baseAssign = require_baseAssign();
    var baseAssignIn = require_baseAssignIn();
    var cloneBuffer2 = require_cloneBuffer();
    var copyArray2 = require_copyArray();
    var copySymbols = require_copySymbols();
    var copySymbolsIn = require_copySymbolsIn();
    var getAllKeys2 = require_getAllKeys();
    var getAllKeysIn = require_getAllKeysIn();
    var getTag2 = require_getTag();
    var initCloneArray = require_initCloneArray();
    var initCloneByTag = require_initCloneByTag();
    var initCloneObject2 = require_initCloneObject();
    var isArray2 = require_isArray();
    var isBuffer2 = require_isBuffer();
    var isMap = require_isMap();
    var isObject2 = require_isObject();
    var isSet = require_isSet();
    var keys2 = require_keys();
    var keysIn2 = require_keysIn();
    var CLONE_DEEP_FLAG = 1;
    var CLONE_FLAT_FLAG = 2;
    var CLONE_SYMBOLS_FLAG = 4;
    var argsTag4 = "[object Arguments]";
    var arrayTag3 = "[object Array]";
    var boolTag3 = "[object Boolean]";
    var dateTag3 = "[object Date]";
    var errorTag3 = "[object Error]";
    var funcTag3 = "[object Function]";
    var genTag2 = "[object GeneratorFunction]";
    var mapTag4 = "[object Map]";
    var numberTag3 = "[object Number]";
    var objectTag5 = "[object Object]";
    var regexpTag3 = "[object RegExp]";
    var setTag4 = "[object Set]";
    var stringTag3 = "[object String]";
    var symbolTag3 = "[object Symbol]";
    var weakMapTag3 = "[object WeakMap]";
    var arrayBufferTag3 = "[object ArrayBuffer]";
    var dataViewTag4 = "[object DataView]";
    var float32Tag2 = "[object Float32Array]";
    var float64Tag2 = "[object Float64Array]";
    var int8Tag2 = "[object Int8Array]";
    var int16Tag2 = "[object Int16Array]";
    var int32Tag2 = "[object Int32Array]";
    var uint8Tag2 = "[object Uint8Array]";
    var uint8ClampedTag2 = "[object Uint8ClampedArray]";
    var uint16Tag2 = "[object Uint16Array]";
    var uint32Tag2 = "[object Uint32Array]";
    var cloneableTags = {};
    cloneableTags[argsTag4] = cloneableTags[arrayTag3] = cloneableTags[arrayBufferTag3] = cloneableTags[dataViewTag4] = cloneableTags[boolTag3] = cloneableTags[dateTag3] = cloneableTags[float32Tag2] = cloneableTags[float64Tag2] = cloneableTags[int8Tag2] = cloneableTags[int16Tag2] = cloneableTags[int32Tag2] = cloneableTags[mapTag4] = cloneableTags[numberTag3] = cloneableTags[objectTag5] = cloneableTags[regexpTag3] = cloneableTags[setTag4] = cloneableTags[stringTag3] = cloneableTags[symbolTag3] = cloneableTags[uint8Tag2] = cloneableTags[uint8ClampedTag2] = cloneableTags[uint16Tag2] = cloneableTags[uint32Tag2] = true;
    cloneableTags[errorTag3] = cloneableTags[funcTag3] = cloneableTags[weakMapTag3] = false;
    function baseClone(value, bitmask, customizer, key, object, stack) {
      var result, isDeep = bitmask & CLONE_DEEP_FLAG, isFlat = bitmask & CLONE_FLAT_FLAG, isFull = bitmask & CLONE_SYMBOLS_FLAG;
      if (customizer) {
        result = object ? customizer(value, key, object, stack) : customizer(value);
      }
      if (result !== void 0) {
        return result;
      }
      if (!isObject2(value)) {
        return value;
      }
      var isArr = isArray2(value);
      if (isArr) {
        result = initCloneArray(value);
        if (!isDeep) {
          return copyArray2(value, result);
        }
      } else {
        var tag = getTag2(value), isFunc = tag == funcTag3 || tag == genTag2;
        if (isBuffer2(value)) {
          return cloneBuffer2(value, isDeep);
        }
        if (tag == objectTag5 || tag == argsTag4 || isFunc && !object) {
          result = isFlat || isFunc ? {} : initCloneObject2(value);
          if (!isDeep) {
            return isFlat ? copySymbolsIn(value, baseAssignIn(result, value)) : copySymbols(value, baseAssign(result, value));
          }
        } else {
          if (!cloneableTags[tag]) {
            return object ? value : {};
          }
          result = initCloneByTag(value, tag, isDeep);
        }
      }
      stack || (stack = new Stack2());
      var stacked = stack.get(value);
      if (stacked) {
        return stacked;
      }
      stack.set(value, result);
      if (isSet(value)) {
        value.forEach(function(subValue) {
          result.add(baseClone(subValue, bitmask, customizer, subValue, value, stack));
        });
      } else if (isMap(value)) {
        value.forEach(function(subValue, key2) {
          result.set(key2, baseClone(subValue, bitmask, customizer, key2, value, stack));
        });
      }
      var keysFunc = isFull ? isFlat ? getAllKeysIn : getAllKeys2 : isFlat ? keysIn2 : keys2;
      var props = isArr ? void 0 : keysFunc(value);
      arrayEach2(props || value, function(subValue, key2) {
        if (props) {
          key2 = subValue;
          subValue = value[key2];
        }
        assignValue2(result, key2, baseClone(subValue, bitmask, customizer, key2, value, stack));
      });
      return result;
    }
    module2.exports = baseClone;
  }
});

// node_modules/lodash/cloneDeep.js
var require_cloneDeep = __commonJS({
  "node_modules/lodash/cloneDeep.js"(exports2, module2) {
    var baseClone = require_baseClone();
    var CLONE_DEEP_FLAG = 1;
    var CLONE_SYMBOLS_FLAG = 4;
    function cloneDeep(value) {
      return baseClone(value, CLONE_DEEP_FLAG | CLONE_SYMBOLS_FLAG);
    }
    module2.exports = cloneDeep;
  }
});

// node_modules/reactcss/lib/mergeClasses.js
var require_mergeClasses = __commonJS({
  "node_modules/reactcss/lib/mergeClasses.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", {
      value: true
    });
    exports2.mergeClasses = void 0;
    var _forOwn2 = require_forOwn();
    var _forOwn3 = _interopRequireDefault(_forOwn2);
    var _cloneDeep2 = require_cloneDeep();
    var _cloneDeep3 = _interopRequireDefault(_cloneDeep2);
    var _extends10 = Object.assign || function(target) {
      for (var i6 = 1; i6 < arguments.length; i6++) {
        var source = arguments[i6];
        for (var key in source) {
          if (Object.prototype.hasOwnProperty.call(source, key)) {
            target[key] = source[key];
          }
        }
      }
      return target;
    };
    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { default: obj };
    }
    var mergeClasses = exports2.mergeClasses = function mergeClasses2(classes) {
      var activeNames = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : [];
      var styles = classes.default && (0, _cloneDeep3.default)(classes.default) || {};
      activeNames.map(function(name) {
        var toMerge = classes[name];
        if (toMerge) {
          (0, _forOwn3.default)(toMerge, function(value, key) {
            if (!styles[key]) {
              styles[key] = {};
            }
            styles[key] = _extends10({}, styles[key], toMerge[key]);
          });
        }
        return name;
      });
      return styles;
    };
    exports2.default = mergeClasses;
  }
});

// node_modules/reactcss/lib/autoprefix.js
var require_autoprefix = __commonJS({
  "node_modules/reactcss/lib/autoprefix.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", {
      value: true
    });
    exports2.autoprefix = void 0;
    var _forOwn2 = require_forOwn();
    var _forOwn3 = _interopRequireDefault(_forOwn2);
    var _extends10 = Object.assign || function(target) {
      for (var i6 = 1; i6 < arguments.length; i6++) {
        var source = arguments[i6];
        for (var key in source) {
          if (Object.prototype.hasOwnProperty.call(source, key)) {
            target[key] = source[key];
          }
        }
      }
      return target;
    };
    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { default: obj };
    }
    var transforms = {
      borderRadius: function borderRadius(value) {
        return {
          msBorderRadius: value,
          MozBorderRadius: value,
          OBorderRadius: value,
          WebkitBorderRadius: value,
          borderRadius: value
        };
      },
      boxShadow: function boxShadow(value) {
        return {
          msBoxShadow: value,
          MozBoxShadow: value,
          OBoxShadow: value,
          WebkitBoxShadow: value,
          boxShadow: value
        };
      },
      userSelect: function userSelect(value) {
        return {
          WebkitTouchCallout: value,
          KhtmlUserSelect: value,
          MozUserSelect: value,
          msUserSelect: value,
          WebkitUserSelect: value,
          userSelect: value
        };
      },
      flex: function flex(value) {
        return {
          WebkitBoxFlex: value,
          MozBoxFlex: value,
          WebkitFlex: value,
          msFlex: value,
          flex: value
        };
      },
      flexBasis: function flexBasis(value) {
        return {
          WebkitFlexBasis: value,
          flexBasis: value
        };
      },
      justifyContent: function justifyContent(value) {
        return {
          WebkitJustifyContent: value,
          justifyContent: value
        };
      },
      transition: function transition(value) {
        return {
          msTransition: value,
          MozTransition: value,
          OTransition: value,
          WebkitTransition: value,
          transition: value
        };
      },
      transform: function transform(value) {
        return {
          msTransform: value,
          MozTransform: value,
          OTransform: value,
          WebkitTransform: value,
          transform: value
        };
      },
      absolute: function absolute(value) {
        var direction = value && value.split(" ");
        return {
          position: "absolute",
          top: direction && direction[0],
          right: direction && direction[1],
          bottom: direction && direction[2],
          left: direction && direction[3]
        };
      },
      extend: function extend(name, otherElementStyles) {
        var otherStyle = otherElementStyles[name];
        if (otherStyle) {
          return otherStyle;
        }
        return {
          "extend": name
        };
      }
    };
    var autoprefix = exports2.autoprefix = function autoprefix2(elements) {
      var prefixed = {};
      (0, _forOwn3.default)(elements, function(styles, element) {
        var expanded = {};
        (0, _forOwn3.default)(styles, function(value, key) {
          var transform = transforms[key];
          if (transform) {
            expanded = _extends10({}, expanded, transform(value));
          } else {
            expanded[key] = value;
          }
        });
        prefixed[element] = expanded;
      });
      return prefixed;
    };
    exports2.default = autoprefix;
  }
});

// node_modules/reactcss/lib/components/hover.js
var require_hover = __commonJS({
  "node_modules/reactcss/lib/components/hover.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", {
      value: true
    });
    exports2.hover = void 0;
    var _extends10 = Object.assign || function(target) {
      for (var i6 = 1; i6 < arguments.length; i6++) {
        var source = arguments[i6];
        for (var key in source) {
          if (Object.prototype.hasOwnProperty.call(source, key)) {
            target[key] = source[key];
          }
        }
      }
      return target;
    };
    var _react = (init_react(), __toCommonJS(react_exports));
    var _react2 = _interopRequireDefault(_react);
    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { default: obj };
    }
    function _classCallCheck9(instance, Constructor) {
      if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
      }
    }
    function _possibleConstructorReturn9(self2, call) {
      if (!self2) {
        throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
      }
      return call && (typeof call === "object" || typeof call === "function") ? call : self2;
    }
    function _inherits9(subClass, superClass) {
      if (typeof superClass !== "function" && superClass !== null) {
        throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
      }
      subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
      if (superClass)
        Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
    }
    var hover = exports2.hover = function hover2(Component) {
      var Span = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "span";
      return function(_React$Component) {
        _inherits9(Hover, _React$Component);
        function Hover() {
          var _ref;
          var _temp, _this, _ret;
          _classCallCheck9(this, Hover);
          for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          return _ret = (_temp = (_this = _possibleConstructorReturn9(this, (_ref = Hover.__proto__ || Object.getPrototypeOf(Hover)).call.apply(_ref, [this].concat(args))), _this), _this.state = { hover: false }, _this.handleMouseOver = function() {
            return _this.setState({ hover: true });
          }, _this.handleMouseOut = function() {
            return _this.setState({ hover: false });
          }, _this.render = function() {
            return _react2.default.createElement(
              Span,
              { onMouseOver: _this.handleMouseOver, onMouseOut: _this.handleMouseOut },
              _react2.default.createElement(Component, _extends10({}, _this.props, _this.state))
            );
          }, _temp), _possibleConstructorReturn9(_this, _ret);
        }
        return Hover;
      }(_react2.default.Component);
    };
    exports2.default = hover;
  }
});

// node_modules/reactcss/lib/components/active.js
var require_active = __commonJS({
  "node_modules/reactcss/lib/components/active.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", {
      value: true
    });
    exports2.active = void 0;
    var _extends10 = Object.assign || function(target) {
      for (var i6 = 1; i6 < arguments.length; i6++) {
        var source = arguments[i6];
        for (var key in source) {
          if (Object.prototype.hasOwnProperty.call(source, key)) {
            target[key] = source[key];
          }
        }
      }
      return target;
    };
    var _react = (init_react(), __toCommonJS(react_exports));
    var _react2 = _interopRequireDefault(_react);
    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { default: obj };
    }
    function _classCallCheck9(instance, Constructor) {
      if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
      }
    }
    function _possibleConstructorReturn9(self2, call) {
      if (!self2) {
        throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
      }
      return call && (typeof call === "object" || typeof call === "function") ? call : self2;
    }
    function _inherits9(subClass, superClass) {
      if (typeof superClass !== "function" && superClass !== null) {
        throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
      }
      subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
      if (superClass)
        Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
    }
    var active = exports2.active = function active2(Component) {
      var Span = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "span";
      return function(_React$Component) {
        _inherits9(Active, _React$Component);
        function Active() {
          var _ref;
          var _temp, _this, _ret;
          _classCallCheck9(this, Active);
          for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          return _ret = (_temp = (_this = _possibleConstructorReturn9(this, (_ref = Active.__proto__ || Object.getPrototypeOf(Active)).call.apply(_ref, [this].concat(args))), _this), _this.state = { active: false }, _this.handleMouseDown = function() {
            return _this.setState({ active: true });
          }, _this.handleMouseUp = function() {
            return _this.setState({ active: false });
          }, _this.render = function() {
            return _react2.default.createElement(
              Span,
              { onMouseDown: _this.handleMouseDown, onMouseUp: _this.handleMouseUp },
              _react2.default.createElement(Component, _extends10({}, _this.props, _this.state))
            );
          }, _temp), _possibleConstructorReturn9(_this, _ret);
        }
        return Active;
      }(_react2.default.Component);
    };
    exports2.default = active;
  }
});

// node_modules/reactcss/lib/loop.js
var require_loop = __commonJS({
  "node_modules/reactcss/lib/loop.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", {
      value: true
    });
    var loopable = function loopable2(i6, length) {
      var props = {};
      var setProp = function setProp2(name) {
        var value = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : true;
        props[name] = value;
      };
      i6 === 0 && setProp("first-child");
      i6 === length - 1 && setProp("last-child");
      (i6 === 0 || i6 % 2 === 0) && setProp("even");
      Math.abs(i6 % 2) === 1 && setProp("odd");
      setProp("nth-child", i6);
      return props;
    };
    exports2.default = loopable;
  }
});

// node_modules/reactcss/lib/index.js
var require_lib = __commonJS({
  "node_modules/reactcss/lib/index.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", {
      value: true
    });
    exports2.ReactCSS = exports2.loop = exports2.handleActive = exports2.handleHover = exports2.hover = void 0;
    var _flattenNames = require_flattenNames();
    var _flattenNames2 = _interopRequireDefault(_flattenNames);
    var _mergeClasses = require_mergeClasses();
    var _mergeClasses2 = _interopRequireDefault(_mergeClasses);
    var _autoprefix = require_autoprefix();
    var _autoprefix2 = _interopRequireDefault(_autoprefix);
    var _hover2 = require_hover();
    var _hover3 = _interopRequireDefault(_hover2);
    var _active = require_active();
    var _active2 = _interopRequireDefault(_active);
    var _loop2 = require_loop();
    var _loop3 = _interopRequireDefault(_loop2);
    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { default: obj };
    }
    exports2.hover = _hover3.default;
    exports2.handleHover = _hover3.default;
    exports2.handleActive = _active2.default;
    exports2.loop = _loop3.default;
    var ReactCSS = exports2.ReactCSS = function ReactCSS2(classes) {
      for (var _len = arguments.length, activations = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
        activations[_key - 1] = arguments[_key];
      }
      var activeNames = (0, _flattenNames2.default)(activations);
      var merged = (0, _mergeClasses2.default)(classes, activeNames);
      return (0, _autoprefix2.default)(merged);
    };
    exports2.default = ReactCSS;
  }
});

// node_modules/react-is/cjs/react-is.development.js
var require_react_is_development = __commonJS({
  "node_modules/react-is/cjs/react-is.development.js"(exports2) {
    "use strict";
    if (true) {
      (function() {
        "use strict";
        var hasSymbol = typeof Symbol === "function" && Symbol.for;
        var REACT_ELEMENT_TYPE = hasSymbol ? Symbol.for("react.element") : 60103;
        var REACT_PORTAL_TYPE = hasSymbol ? Symbol.for("react.portal") : 60106;
        var REACT_FRAGMENT_TYPE = hasSymbol ? Symbol.for("react.fragment") : 60107;
        var REACT_STRICT_MODE_TYPE = hasSymbol ? Symbol.for("react.strict_mode") : 60108;
        var REACT_PROFILER_TYPE = hasSymbol ? Symbol.for("react.profiler") : 60114;
        var REACT_PROVIDER_TYPE = hasSymbol ? Symbol.for("react.provider") : 60109;
        var REACT_CONTEXT_TYPE = hasSymbol ? Symbol.for("react.context") : 60110;
        var REACT_ASYNC_MODE_TYPE = hasSymbol ? Symbol.for("react.async_mode") : 60111;
        var REACT_CONCURRENT_MODE_TYPE = hasSymbol ? Symbol.for("react.concurrent_mode") : 60111;
        var REACT_FORWARD_REF_TYPE = hasSymbol ? Symbol.for("react.forward_ref") : 60112;
        var REACT_SUSPENSE_TYPE = hasSymbol ? Symbol.for("react.suspense") : 60113;
        var REACT_SUSPENSE_LIST_TYPE = hasSymbol ? Symbol.for("react.suspense_list") : 60120;
        var REACT_MEMO_TYPE = hasSymbol ? Symbol.for("react.memo") : 60115;
        var REACT_LAZY_TYPE = hasSymbol ? Symbol.for("react.lazy") : 60116;
        var REACT_BLOCK_TYPE = hasSymbol ? Symbol.for("react.block") : 60121;
        var REACT_FUNDAMENTAL_TYPE = hasSymbol ? Symbol.for("react.fundamental") : 60117;
        var REACT_RESPONDER_TYPE = hasSymbol ? Symbol.for("react.responder") : 60118;
        var REACT_SCOPE_TYPE = hasSymbol ? Symbol.for("react.scope") : 60119;
        function isValidElementType(type) {
          return typeof type === "string" || typeof type === "function" || // Note: its typeof might be other than 'symbol' or 'number' if it's a polyfill.
          type === REACT_FRAGMENT_TYPE || type === REACT_CONCURRENT_MODE_TYPE || type === REACT_PROFILER_TYPE || type === REACT_STRICT_MODE_TYPE || type === REACT_SUSPENSE_TYPE || type === REACT_SUSPENSE_LIST_TYPE || typeof type === "object" && type !== null && (type.$$typeof === REACT_LAZY_TYPE || type.$$typeof === REACT_MEMO_TYPE || type.$$typeof === REACT_PROVIDER_TYPE || type.$$typeof === REACT_CONTEXT_TYPE || type.$$typeof === REACT_FORWARD_REF_TYPE || type.$$typeof === REACT_FUNDAMENTAL_TYPE || type.$$typeof === REACT_RESPONDER_TYPE || type.$$typeof === REACT_SCOPE_TYPE || type.$$typeof === REACT_BLOCK_TYPE);
        }
        function typeOf(object) {
          if (typeof object === "object" && object !== null) {
            var $$typeof = object.$$typeof;
            switch ($$typeof) {
              case REACT_ELEMENT_TYPE:
                var type = object.type;
                switch (type) {
                  case REACT_ASYNC_MODE_TYPE:
                  case REACT_CONCURRENT_MODE_TYPE:
                  case REACT_FRAGMENT_TYPE:
                  case REACT_PROFILER_TYPE:
                  case REACT_STRICT_MODE_TYPE:
                  case REACT_SUSPENSE_TYPE:
                    return type;
                  default:
                    var $$typeofType = type && type.$$typeof;
                    switch ($$typeofType) {
                      case REACT_CONTEXT_TYPE:
                      case REACT_FORWARD_REF_TYPE:
                      case REACT_LAZY_TYPE:
                      case REACT_MEMO_TYPE:
                      case REACT_PROVIDER_TYPE:
                        return $$typeofType;
                      default:
                        return $$typeof;
                    }
                }
              case REACT_PORTAL_TYPE:
                return $$typeof;
            }
          }
          return void 0;
        }
        var AsyncMode = REACT_ASYNC_MODE_TYPE;
        var ConcurrentMode = REACT_CONCURRENT_MODE_TYPE;
        var ContextConsumer = REACT_CONTEXT_TYPE;
        var ContextProvider = REACT_PROVIDER_TYPE;
        var Element = REACT_ELEMENT_TYPE;
        var ForwardRef = REACT_FORWARD_REF_TYPE;
        var Fragment = REACT_FRAGMENT_TYPE;
        var Lazy = REACT_LAZY_TYPE;
        var Memo = REACT_MEMO_TYPE;
        var Portal = REACT_PORTAL_TYPE;
        var Profiler = REACT_PROFILER_TYPE;
        var StrictMode = REACT_STRICT_MODE_TYPE;
        var Suspense = REACT_SUSPENSE_TYPE;
        var hasWarnedAboutDeprecatedIsAsyncMode = false;
        function isAsyncMode(object) {
          {
            if (!hasWarnedAboutDeprecatedIsAsyncMode) {
              hasWarnedAboutDeprecatedIsAsyncMode = true;
              console["warn"]("The ReactIs.isAsyncMode() alias has been deprecated, and will be removed in React 17+. Update your code to use ReactIs.isConcurrentMode() instead. It has the exact same API.");
            }
          }
          return isConcurrentMode(object) || typeOf(object) === REACT_ASYNC_MODE_TYPE;
        }
        function isConcurrentMode(object) {
          return typeOf(object) === REACT_CONCURRENT_MODE_TYPE;
        }
        function isContextConsumer(object) {
          return typeOf(object) === REACT_CONTEXT_TYPE;
        }
        function isContextProvider(object) {
          return typeOf(object) === REACT_PROVIDER_TYPE;
        }
        function isElement(object) {
          return typeof object === "object" && object !== null && object.$$typeof === REACT_ELEMENT_TYPE;
        }
        function isForwardRef(object) {
          return typeOf(object) === REACT_FORWARD_REF_TYPE;
        }
        function isFragment(object) {
          return typeOf(object) === REACT_FRAGMENT_TYPE;
        }
        function isLazy(object) {
          return typeOf(object) === REACT_LAZY_TYPE;
        }
        function isMemo(object) {
          return typeOf(object) === REACT_MEMO_TYPE;
        }
        function isPortal(object) {
          return typeOf(object) === REACT_PORTAL_TYPE;
        }
        function isProfiler(object) {
          return typeOf(object) === REACT_PROFILER_TYPE;
        }
        function isStrictMode(object) {
          return typeOf(object) === REACT_STRICT_MODE_TYPE;
        }
        function isSuspense(object) {
          return typeOf(object) === REACT_SUSPENSE_TYPE;
        }
        exports2.AsyncMode = AsyncMode;
        exports2.ConcurrentMode = ConcurrentMode;
        exports2.ContextConsumer = ContextConsumer;
        exports2.ContextProvider = ContextProvider;
        exports2.Element = Element;
        exports2.ForwardRef = ForwardRef;
        exports2.Fragment = Fragment;
        exports2.Lazy = Lazy;
        exports2.Memo = Memo;
        exports2.Portal = Portal;
        exports2.Profiler = Profiler;
        exports2.StrictMode = StrictMode;
        exports2.Suspense = Suspense;
        exports2.isAsyncMode = isAsyncMode;
        exports2.isConcurrentMode = isConcurrentMode;
        exports2.isContextConsumer = isContextConsumer;
        exports2.isContextProvider = isContextProvider;
        exports2.isElement = isElement;
        exports2.isForwardRef = isForwardRef;
        exports2.isFragment = isFragment;
        exports2.isLazy = isLazy;
        exports2.isMemo = isMemo;
        exports2.isPortal = isPortal;
        exports2.isProfiler = isProfiler;
        exports2.isStrictMode = isStrictMode;
        exports2.isSuspense = isSuspense;
        exports2.isValidElementType = isValidElementType;
        exports2.typeOf = typeOf;
      })();
    }
  }
});

// node_modules/react-is/index.js
var require_react_is = __commonJS({
  "node_modules/react-is/index.js"(exports2, module2) {
    "use strict";
    if (false) {
      module2.exports = null;
    } else {
      module2.exports = require_react_is_development();
    }
  }
});

// node_modules/object-assign/index.js
var require_object_assign = __commonJS({
  "node_modules/object-assign/index.js"(exports2, module2) {
    "use strict";
    var getOwnPropertySymbols = Object.getOwnPropertySymbols;
    var hasOwnProperty13 = Object.prototype.hasOwnProperty;
    var propIsEnumerable = Object.prototype.propertyIsEnumerable;
    function toObject(val) {
      if (val === null || val === void 0) {
        throw new TypeError("Object.assign cannot be called with null or undefined");
      }
      return Object(val);
    }
    function shouldUseNative() {
      try {
        if (!Object.assign) {
          return false;
        }
        var test1 = new String("abc");
        test1[5] = "de";
        if (Object.getOwnPropertyNames(test1)[0] === "5") {
          return false;
        }
        var test2 = {};
        for (var i6 = 0; i6 < 10; i6++) {
          test2["_" + String.fromCharCode(i6)] = i6;
        }
        var order2 = Object.getOwnPropertyNames(test2).map(function(n8) {
          return test2[n8];
        });
        if (order2.join("") !== "0123456789") {
          return false;
        }
        var test3 = {};
        "abcdefghijklmnopqrst".split("").forEach(function(letter) {
          test3[letter] = letter;
        });
        if (Object.keys(Object.assign({}, test3)).join("") !== "abcdefghijklmnopqrst") {
          return false;
        }
        return true;
      } catch (err) {
        return false;
      }
    }
    module2.exports = shouldUseNative() ? Object.assign : function(target, source) {
      var from;
      var to = toObject(target);
      var symbols;
      for (var s7 = 1; s7 < arguments.length; s7++) {
        from = Object(arguments[s7]);
        for (var key in from) {
          if (hasOwnProperty13.call(from, key)) {
            to[key] = from[key];
          }
        }
        if (getOwnPropertySymbols) {
          symbols = getOwnPropertySymbols(from);
          for (var i6 = 0; i6 < symbols.length; i6++) {
            if (propIsEnumerable.call(from, symbols[i6])) {
              to[symbols[i6]] = from[symbols[i6]];
            }
          }
        }
      }
      return to;
    };
  }
});

// node_modules/prop-types/lib/ReactPropTypesSecret.js
var require_ReactPropTypesSecret = __commonJS({
  "node_modules/prop-types/lib/ReactPropTypesSecret.js"(exports2, module2) {
    "use strict";
    var ReactPropTypesSecret = "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED";
    module2.exports = ReactPropTypesSecret;
  }
});

// node_modules/prop-types/lib/has.js
var require_has = __commonJS({
  "node_modules/prop-types/lib/has.js"(exports2, module2) {
    module2.exports = Function.call.bind(Object.prototype.hasOwnProperty);
  }
});

// node_modules/prop-types/checkPropTypes.js
var require_checkPropTypes = __commonJS({
  "node_modules/prop-types/checkPropTypes.js"(exports2, module2) {
    "use strict";
    var printWarning = function() {
    };
    if (true) {
      ReactPropTypesSecret = require_ReactPropTypesSecret();
      loggedTypeFailures = {};
      has = require_has();
      printWarning = function(text) {
        var message = "Warning: " + text;
        if (typeof console !== "undefined") {
          console.error(message);
        }
        try {
          throw new Error(message);
        } catch (x5) {
        }
      };
    }
    var ReactPropTypesSecret;
    var loggedTypeFailures;
    var has;
    function checkPropTypes(typeSpecs, values, location, componentName, getStack) {
      if (true) {
        for (var typeSpecName in typeSpecs) {
          if (has(typeSpecs, typeSpecName)) {
            var error;
            try {
              if (typeof typeSpecs[typeSpecName] !== "function") {
                var err = Error(
                  (componentName || "React class") + ": " + location + " type `" + typeSpecName + "` is invalid; it must be a function, usually from the `prop-types` package, but received `" + typeof typeSpecs[typeSpecName] + "`.This often happens because of typos such as `PropTypes.function` instead of `PropTypes.func`."
                );
                err.name = "Invariant Violation";
                throw err;
              }
              error = typeSpecs[typeSpecName](values, typeSpecName, componentName, location, null, ReactPropTypesSecret);
            } catch (ex) {
              error = ex;
            }
            if (error && !(error instanceof Error)) {
              printWarning(
                (componentName || "React class") + ": type specification of " + location + " `" + typeSpecName + "` is invalid; the type checker function must return `null` or an `Error` but returned a " + typeof error + ". You may have forgotten to pass an argument to the type checker creator (arrayOf, instanceOf, objectOf, oneOf, oneOfType, and shape all require an argument)."
              );
            }
            if (error instanceof Error && !(error.message in loggedTypeFailures)) {
              loggedTypeFailures[error.message] = true;
              var stack = getStack ? getStack() : "";
              printWarning(
                "Failed " + location + " type: " + error.message + (stack != null ? stack : "")
              );
            }
          }
        }
      }
    }
    checkPropTypes.resetWarningCache = function() {
      if (true) {
        loggedTypeFailures = {};
      }
    };
    module2.exports = checkPropTypes;
  }
});

// node_modules/prop-types/factoryWithTypeCheckers.js
var require_factoryWithTypeCheckers = __commonJS({
  "node_modules/prop-types/factoryWithTypeCheckers.js"(exports2, module2) {
    "use strict";
    var ReactIs = require_react_is();
    var assign = require_object_assign();
    var ReactPropTypesSecret = require_ReactPropTypesSecret();
    var has = require_has();
    var checkPropTypes = require_checkPropTypes();
    var printWarning = function() {
    };
    if (true) {
      printWarning = function(text) {
        var message = "Warning: " + text;
        if (typeof console !== "undefined") {
          console.error(message);
        }
        try {
          throw new Error(message);
        } catch (x5) {
        }
      };
    }
    function emptyFunctionThatReturnsNull() {
      return null;
    }
    module2.exports = function(isValidElement, throwOnDirectAccess) {
      var ITERATOR_SYMBOL = typeof Symbol === "function" && Symbol.iterator;
      var FAUX_ITERATOR_SYMBOL = "@@iterator";
      function getIteratorFn(maybeIterable) {
        var iteratorFn = maybeIterable && (ITERATOR_SYMBOL && maybeIterable[ITERATOR_SYMBOL] || maybeIterable[FAUX_ITERATOR_SYMBOL]);
        if (typeof iteratorFn === "function") {
          return iteratorFn;
        }
      }
      var ANONYMOUS = "<<anonymous>>";
      var ReactPropTypes = {
        array: createPrimitiveTypeChecker("array"),
        bigint: createPrimitiveTypeChecker("bigint"),
        bool: createPrimitiveTypeChecker("boolean"),
        func: createPrimitiveTypeChecker("function"),
        number: createPrimitiveTypeChecker("number"),
        object: createPrimitiveTypeChecker("object"),
        string: createPrimitiveTypeChecker("string"),
        symbol: createPrimitiveTypeChecker("symbol"),
        any: createAnyTypeChecker(),
        arrayOf: createArrayOfTypeChecker,
        element: createElementTypeChecker(),
        elementType: createElementTypeTypeChecker(),
        instanceOf: createInstanceTypeChecker,
        node: createNodeChecker(),
        objectOf: createObjectOfTypeChecker,
        oneOf: createEnumTypeChecker,
        oneOfType: createUnionTypeChecker,
        shape: createShapeTypeChecker,
        exact: createStrictShapeTypeChecker
      };
      function is(x5, y4) {
        if (x5 === y4) {
          return x5 !== 0 || 1 / x5 === 1 / y4;
        } else {
          return x5 !== x5 && y4 !== y4;
        }
      }
      function PropTypeError(message, data) {
        this.message = message;
        this.data = data && typeof data === "object" ? data : {};
        this.stack = "";
      }
      PropTypeError.prototype = Error.prototype;
      function createChainableTypeChecker(validate) {
        if (true) {
          var manualPropTypeCallCache = {};
          var manualPropTypeWarningCount = 0;
        }
        function checkType(isRequired, props, propName, componentName, location, propFullName, secret) {
          componentName = componentName || ANONYMOUS;
          propFullName = propFullName || propName;
          if (secret !== ReactPropTypesSecret) {
            if (throwOnDirectAccess) {
              var err = new Error(
                "Calling PropTypes validators directly is not supported by the `prop-types` package. Use `PropTypes.checkPropTypes()` to call them. Read more at http://fb.me/use-check-prop-types"
              );
              err.name = "Invariant Violation";
              throw err;
            } else if (typeof console !== "undefined") {
              var cacheKey = componentName + ":" + propName;
              if (!manualPropTypeCallCache[cacheKey] && // Avoid spamming the console because they are often not actionable except for lib authors
              manualPropTypeWarningCount < 3) {
                printWarning(
                  "You are manually calling a React.PropTypes validation function for the `" + propFullName + "` prop on `" + componentName + "`. This is deprecated and will throw in the standalone `prop-types` package. You may be seeing this warning due to a third-party PropTypes library. See https://fb.me/react-warning-dont-call-proptypes for details."
                );
                manualPropTypeCallCache[cacheKey] = true;
                manualPropTypeWarningCount++;
              }
            }
          }
          if (props[propName] == null) {
            if (isRequired) {
              if (props[propName] === null) {
                return new PropTypeError("The " + location + " `" + propFullName + "` is marked as required " + ("in `" + componentName + "`, but its value is `null`."));
              }
              return new PropTypeError("The " + location + " `" + propFullName + "` is marked as required in " + ("`" + componentName + "`, but its value is `undefined`."));
            }
            return null;
          } else {
            return validate(props, propName, componentName, location, propFullName);
          }
        }
        var chainedCheckType = checkType.bind(null, false);
        chainedCheckType.isRequired = checkType.bind(null, true);
        return chainedCheckType;
      }
      function createPrimitiveTypeChecker(expectedType) {
        function validate(props, propName, componentName, location, propFullName, secret) {
          var propValue = props[propName];
          var propType = getPropType(propValue);
          if (propType !== expectedType) {
            var preciseType = getPreciseType(propValue);
            return new PropTypeError(
              "Invalid " + location + " `" + propFullName + "` of type " + ("`" + preciseType + "` supplied to `" + componentName + "`, expected ") + ("`" + expectedType + "`."),
              { expectedType }
            );
          }
          return null;
        }
        return createChainableTypeChecker(validate);
      }
      function createAnyTypeChecker() {
        return createChainableTypeChecker(emptyFunctionThatReturnsNull);
      }
      function createArrayOfTypeChecker(typeChecker) {
        function validate(props, propName, componentName, location, propFullName) {
          if (typeof typeChecker !== "function") {
            return new PropTypeError("Property `" + propFullName + "` of component `" + componentName + "` has invalid PropType notation inside arrayOf.");
          }
          var propValue = props[propName];
          if (!Array.isArray(propValue)) {
            var propType = getPropType(propValue);
            return new PropTypeError("Invalid " + location + " `" + propFullName + "` of type " + ("`" + propType + "` supplied to `" + componentName + "`, expected an array."));
          }
          for (var i6 = 0; i6 < propValue.length; i6++) {
            var error = typeChecker(propValue, i6, componentName, location, propFullName + "[" + i6 + "]", ReactPropTypesSecret);
            if (error instanceof Error) {
              return error;
            }
          }
          return null;
        }
        return createChainableTypeChecker(validate);
      }
      function createElementTypeChecker() {
        function validate(props, propName, componentName, location, propFullName) {
          var propValue = props[propName];
          if (!isValidElement(propValue)) {
            var propType = getPropType(propValue);
            return new PropTypeError("Invalid " + location + " `" + propFullName + "` of type " + ("`" + propType + "` supplied to `" + componentName + "`, expected a single ReactElement."));
          }
          return null;
        }
        return createChainableTypeChecker(validate);
      }
      function createElementTypeTypeChecker() {
        function validate(props, propName, componentName, location, propFullName) {
          var propValue = props[propName];
          if (!ReactIs.isValidElementType(propValue)) {
            var propType = getPropType(propValue);
            return new PropTypeError("Invalid " + location + " `" + propFullName + "` of type " + ("`" + propType + "` supplied to `" + componentName + "`, expected a single ReactElement type."));
          }
          return null;
        }
        return createChainableTypeChecker(validate);
      }
      function createInstanceTypeChecker(expectedClass) {
        function validate(props, propName, componentName, location, propFullName) {
          if (!(props[propName] instanceof expectedClass)) {
            var expectedClassName = expectedClass.name || ANONYMOUS;
            var actualClassName = getClassName(props[propName]);
            return new PropTypeError("Invalid " + location + " `" + propFullName + "` of type " + ("`" + actualClassName + "` supplied to `" + componentName + "`, expected ") + ("instance of `" + expectedClassName + "`."));
          }
          return null;
        }
        return createChainableTypeChecker(validate);
      }
      function createEnumTypeChecker(expectedValues) {
        if (!Array.isArray(expectedValues)) {
          if (true) {
            if (arguments.length > 1) {
              printWarning(
                "Invalid arguments supplied to oneOf, expected an array, got " + arguments.length + " arguments. A common mistake is to write oneOf(x, y, z) instead of oneOf([x, y, z])."
              );
            } else {
              printWarning("Invalid argument supplied to oneOf, expected an array.");
            }
          }
          return emptyFunctionThatReturnsNull;
        }
        function validate(props, propName, componentName, location, propFullName) {
          var propValue = props[propName];
          for (var i6 = 0; i6 < expectedValues.length; i6++) {
            if (is(propValue, expectedValues[i6])) {
              return null;
            }
          }
          var valuesString = JSON.stringify(expectedValues, function replacer(key, value) {
            var type = getPreciseType(value);
            if (type === "symbol") {
              return String(value);
            }
            return value;
          });
          return new PropTypeError("Invalid " + location + " `" + propFullName + "` of value `" + String(propValue) + "` " + ("supplied to `" + componentName + "`, expected one of " + valuesString + "."));
        }
        return createChainableTypeChecker(validate);
      }
      function createObjectOfTypeChecker(typeChecker) {
        function validate(props, propName, componentName, location, propFullName) {
          if (typeof typeChecker !== "function") {
            return new PropTypeError("Property `" + propFullName + "` of component `" + componentName + "` has invalid PropType notation inside objectOf.");
          }
          var propValue = props[propName];
          var propType = getPropType(propValue);
          if (propType !== "object") {
            return new PropTypeError("Invalid " + location + " `" + propFullName + "` of type " + ("`" + propType + "` supplied to `" + componentName + "`, expected an object."));
          }
          for (var key in propValue) {
            if (has(propValue, key)) {
              var error = typeChecker(propValue, key, componentName, location, propFullName + "." + key, ReactPropTypesSecret);
              if (error instanceof Error) {
                return error;
              }
            }
          }
          return null;
        }
        return createChainableTypeChecker(validate);
      }
      function createUnionTypeChecker(arrayOfTypeCheckers) {
        if (!Array.isArray(arrayOfTypeCheckers)) {
          true ? printWarning("Invalid argument supplied to oneOfType, expected an instance of array.") : void 0;
          return emptyFunctionThatReturnsNull;
        }
        for (var i6 = 0; i6 < arrayOfTypeCheckers.length; i6++) {
          var checker = arrayOfTypeCheckers[i6];
          if (typeof checker !== "function") {
            printWarning(
              "Invalid argument supplied to oneOfType. Expected an array of check functions, but received " + getPostfixForTypeWarning(checker) + " at index " + i6 + "."
            );
            return emptyFunctionThatReturnsNull;
          }
        }
        function validate(props, propName, componentName, location, propFullName) {
          var expectedTypes = [];
          for (var i7 = 0; i7 < arrayOfTypeCheckers.length; i7++) {
            var checker2 = arrayOfTypeCheckers[i7];
            var checkerResult = checker2(props, propName, componentName, location, propFullName, ReactPropTypesSecret);
            if (checkerResult == null) {
              return null;
            }
            if (checkerResult.data && has(checkerResult.data, "expectedType")) {
              expectedTypes.push(checkerResult.data.expectedType);
            }
          }
          var expectedTypesMessage = expectedTypes.length > 0 ? ", expected one of type [" + expectedTypes.join(", ") + "]" : "";
          return new PropTypeError("Invalid " + location + " `" + propFullName + "` supplied to " + ("`" + componentName + "`" + expectedTypesMessage + "."));
        }
        return createChainableTypeChecker(validate);
      }
      function createNodeChecker() {
        function validate(props, propName, componentName, location, propFullName) {
          if (!isNode(props[propName])) {
            return new PropTypeError("Invalid " + location + " `" + propFullName + "` supplied to " + ("`" + componentName + "`, expected a ReactNode."));
          }
          return null;
        }
        return createChainableTypeChecker(validate);
      }
      function invalidValidatorError(componentName, location, propFullName, key, type) {
        return new PropTypeError(
          (componentName || "React class") + ": " + location + " type `" + propFullName + "." + key + "` is invalid; it must be a function, usually from the `prop-types` package, but received `" + type + "`."
        );
      }
      function createShapeTypeChecker(shapeTypes) {
        function validate(props, propName, componentName, location, propFullName) {
          var propValue = props[propName];
          var propType = getPropType(propValue);
          if (propType !== "object") {
            return new PropTypeError("Invalid " + location + " `" + propFullName + "` of type `" + propType + "` " + ("supplied to `" + componentName + "`, expected `object`."));
          }
          for (var key in shapeTypes) {
            var checker = shapeTypes[key];
            if (typeof checker !== "function") {
              return invalidValidatorError(componentName, location, propFullName, key, getPreciseType(checker));
            }
            var error = checker(propValue, key, componentName, location, propFullName + "." + key, ReactPropTypesSecret);
            if (error) {
              return error;
            }
          }
          return null;
        }
        return createChainableTypeChecker(validate);
      }
      function createStrictShapeTypeChecker(shapeTypes) {
        function validate(props, propName, componentName, location, propFullName) {
          var propValue = props[propName];
          var propType = getPropType(propValue);
          if (propType !== "object") {
            return new PropTypeError("Invalid " + location + " `" + propFullName + "` of type `" + propType + "` " + ("supplied to `" + componentName + "`, expected `object`."));
          }
          var allKeys = assign({}, props[propName], shapeTypes);
          for (var key in allKeys) {
            var checker = shapeTypes[key];
            if (has(shapeTypes, key) && typeof checker !== "function") {
              return invalidValidatorError(componentName, location, propFullName, key, getPreciseType(checker));
            }
            if (!checker) {
              return new PropTypeError(
                "Invalid " + location + " `" + propFullName + "` key `" + key + "` supplied to `" + componentName + "`.\nBad object: " + JSON.stringify(props[propName], null, "  ") + "\nValid keys: " + JSON.stringify(Object.keys(shapeTypes), null, "  ")
              );
            }
            var error = checker(propValue, key, componentName, location, propFullName + "." + key, ReactPropTypesSecret);
            if (error) {
              return error;
            }
          }
          return null;
        }
        return createChainableTypeChecker(validate);
      }
      function isNode(propValue) {
        switch (typeof propValue) {
          case "number":
          case "string":
          case "undefined":
            return true;
          case "boolean":
            return !propValue;
          case "object":
            if (Array.isArray(propValue)) {
              return propValue.every(isNode);
            }
            if (propValue === null || isValidElement(propValue)) {
              return true;
            }
            var iteratorFn = getIteratorFn(propValue);
            if (iteratorFn) {
              var iterator = iteratorFn.call(propValue);
              var step;
              if (iteratorFn !== propValue.entries) {
                while (!(step = iterator.next()).done) {
                  if (!isNode(step.value)) {
                    return false;
                  }
                }
              } else {
                while (!(step = iterator.next()).done) {
                  var entry = step.value;
                  if (entry) {
                    if (!isNode(entry[1])) {
                      return false;
                    }
                  }
                }
              }
            } else {
              return false;
            }
            return true;
          default:
            return false;
        }
      }
      function isSymbol2(propType, propValue) {
        if (propType === "symbol") {
          return true;
        }
        if (!propValue) {
          return false;
        }
        if (propValue["@@toStringTag"] === "Symbol") {
          return true;
        }
        if (typeof Symbol === "function" && propValue instanceof Symbol) {
          return true;
        }
        return false;
      }
      function getPropType(propValue) {
        var propType = typeof propValue;
        if (Array.isArray(propValue)) {
          return "array";
        }
        if (propValue instanceof RegExp) {
          return "object";
        }
        if (isSymbol2(propType, propValue)) {
          return "symbol";
        }
        return propType;
      }
      function getPreciseType(propValue) {
        if (typeof propValue === "undefined" || propValue === null) {
          return "" + propValue;
        }
        var propType = getPropType(propValue);
        if (propType === "object") {
          if (propValue instanceof Date) {
            return "date";
          } else if (propValue instanceof RegExp) {
            return "regexp";
          }
        }
        return propType;
      }
      function getPostfixForTypeWarning(value) {
        var type = getPreciseType(value);
        switch (type) {
          case "array":
          case "object":
            return "an " + type;
          case "boolean":
          case "date":
          case "regexp":
            return "a " + type;
          default:
            return type;
        }
      }
      function getClassName(propValue) {
        if (!propValue.constructor || !propValue.constructor.name) {
          return ANONYMOUS;
        }
        return propValue.constructor.name;
      }
      ReactPropTypes.checkPropTypes = checkPropTypes;
      ReactPropTypes.resetWarningCache = checkPropTypes.resetWarningCache;
      ReactPropTypes.PropTypes = ReactPropTypes;
      return ReactPropTypes;
    };
  }
});

// node_modules/prop-types/index.js
var require_prop_types = __commonJS({
  "node_modules/prop-types/index.js"(exports2, module2) {
    if (true) {
      ReactIs = require_react_is();
      throwOnDirectAccess = true;
      module2.exports = require_factoryWithTypeCheckers()(ReactIs.isElement, throwOnDirectAccess);
    } else {
      module2.exports = null();
    }
    var ReactIs;
    var throwOnDirectAccess;
  }
});

// node_modules/@icons/material/UnfoldMoreHorizontalIcon.js
var require_UnfoldMoreHorizontalIcon = __commonJS({
  "node_modules/@icons/material/UnfoldMoreHorizontalIcon.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", {
      value: true
    });
    var _extends10 = Object.assign || function(target) {
      for (var i6 = 1; i6 < arguments.length; i6++) {
        var source = arguments[i6];
        for (var key in source) {
          if (Object.prototype.hasOwnProperty.call(source, key)) {
            target[key] = source[key];
          }
        }
      }
      return target;
    };
    var _react = (init_react(), __toCommonJS(react_exports));
    var _react2 = _interopRequireDefault(_react);
    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { default: obj };
    }
    function _objectWithoutProperties(obj, keys2) {
      var target = {};
      for (var i6 in obj) {
        if (keys2.indexOf(i6) >= 0)
          continue;
        if (!Object.prototype.hasOwnProperty.call(obj, i6))
          continue;
        target[i6] = obj[i6];
      }
      return target;
    }
    var DEFAULT_SIZE = 24;
    exports2.default = function(_ref) {
      var _ref$fill = _ref.fill, fill = _ref$fill === void 0 ? "currentColor" : _ref$fill, _ref$width = _ref.width, width = _ref$width === void 0 ? DEFAULT_SIZE : _ref$width, _ref$height = _ref.height, height = _ref$height === void 0 ? DEFAULT_SIZE : _ref$height, _ref$style = _ref.style, style = _ref$style === void 0 ? {} : _ref$style, props = _objectWithoutProperties(_ref, ["fill", "width", "height", "style"]);
      return _react2.default.createElement(
        "svg",
        _extends10({
          viewBox: "0 0 " + DEFAULT_SIZE + " " + DEFAULT_SIZE,
          style: _extends10({ fill, width, height }, style)
        }, props),
        _react2.default.createElement("path", { d: "M12,18.17L8.83,15L7.42,16.41L12,21L16.59,16.41L15.17,15M12,5.83L15.17,9L16.58,7.59L12,3L7.41,7.59L8.83,9L12,5.83Z" })
      );
    };
  }
});

// node_modules/@icons/material/CheckIcon.js
var require_CheckIcon = __commonJS({
  "node_modules/@icons/material/CheckIcon.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", {
      value: true
    });
    var _extends10 = Object.assign || function(target) {
      for (var i6 = 1; i6 < arguments.length; i6++) {
        var source = arguments[i6];
        for (var key in source) {
          if (Object.prototype.hasOwnProperty.call(source, key)) {
            target[key] = source[key];
          }
        }
      }
      return target;
    };
    var _react = (init_react(), __toCommonJS(react_exports));
    var _react2 = _interopRequireDefault(_react);
    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { default: obj };
    }
    function _objectWithoutProperties(obj, keys2) {
      var target = {};
      for (var i6 in obj) {
        if (keys2.indexOf(i6) >= 0)
          continue;
        if (!Object.prototype.hasOwnProperty.call(obj, i6))
          continue;
        target[i6] = obj[i6];
      }
      return target;
    }
    var DEFAULT_SIZE = 24;
    exports2.default = function(_ref) {
      var _ref$fill = _ref.fill, fill = _ref$fill === void 0 ? "currentColor" : _ref$fill, _ref$width = _ref.width, width = _ref$width === void 0 ? DEFAULT_SIZE : _ref$width, _ref$height = _ref.height, height = _ref$height === void 0 ? DEFAULT_SIZE : _ref$height, _ref$style = _ref.style, style = _ref$style === void 0 ? {} : _ref$style, props = _objectWithoutProperties(_ref, ["fill", "width", "height", "style"]);
      return _react2.default.createElement(
        "svg",
        _extends10({
          viewBox: "0 0 " + DEFAULT_SIZE + " " + DEFAULT_SIZE,
          style: _extends10({ fill, width, height }, style)
        }, props),
        _react2.default.createElement("path", { d: "M21,7L9,19L3.5,13.5L4.91,12.09L9,16.17L19.59,5.59L21,7Z" })
      );
    };
  }
});

// node_modules/@lit/reactive-element/css-tag.js
var t = window;
var e = t.ShadowRoot && (void 0 === t.ShadyCSS || t.ShadyCSS.nativeShadow) && "adoptedStyleSheets" in Document.prototype && "replace" in CSSStyleSheet.prototype;
var s = Symbol();
var n = /* @__PURE__ */ new WeakMap();
var o = class {
  constructor(t6, e9, n8) {
    if (this._$cssResult$ = true, n8 !== s)
      throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");
    this.cssText = t6, this.t = e9;
  }
  get styleSheet() {
    let t6 = this.o;
    const s7 = this.t;
    if (e && void 0 === t6) {
      const e9 = void 0 !== s7 && 1 === s7.length;
      e9 && (t6 = n.get(s7)), void 0 === t6 && ((this.o = t6 = new CSSStyleSheet()).replaceSync(this.cssText), e9 && n.set(s7, t6));
    }
    return t6;
  }
  toString() {
    return this.cssText;
  }
};
var r = (t6) => new o("string" == typeof t6 ? t6 : t6 + "", void 0, s);
var i = (t6, ...e9) => {
  const n8 = 1 === t6.length ? t6[0] : e9.reduce((e10, s7, n9) => e10 + ((t7) => {
    if (true === t7._$cssResult$)
      return t7.cssText;
    if ("number" == typeof t7)
      return t7;
    throw Error("Value passed to 'css' function must be a 'css' function result: " + t7 + ". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.");
  })(s7) + t6[n9 + 1], t6[0]);
  return new o(n8, t6, s);
};
var S = (s7, n8) => {
  e ? s7.adoptedStyleSheets = n8.map((t6) => t6 instanceof CSSStyleSheet ? t6 : t6.styleSheet) : n8.forEach((e9) => {
    const n9 = document.createElement("style"), o8 = t.litNonce;
    void 0 !== o8 && n9.setAttribute("nonce", o8), n9.textContent = e9.cssText, s7.appendChild(n9);
  });
};
var c = e ? (t6) => t6 : (t6) => t6 instanceof CSSStyleSheet ? ((t7) => {
  let e9 = "";
  for (const s7 of t7.cssRules)
    e9 += s7.cssText;
  return r(e9);
})(t6) : t6;

// node_modules/@lit/reactive-element/reactive-element.js
var s2;
var e2 = window;
var r2 = e2.trustedTypes;
var h = r2 ? r2.emptyScript : "";
var o2 = e2.reactiveElementPolyfillSupport;
var n2 = { toAttribute(t6, i6) {
  switch (i6) {
    case Boolean:
      t6 = t6 ? h : null;
      break;
    case Object:
    case Array:
      t6 = null == t6 ? t6 : JSON.stringify(t6);
  }
  return t6;
}, fromAttribute(t6, i6) {
  let s7 = t6;
  switch (i6) {
    case Boolean:
      s7 = null !== t6;
      break;
    case Number:
      s7 = null === t6 ? null : Number(t6);
      break;
    case Object:
    case Array:
      try {
        s7 = JSON.parse(t6);
      } catch (t7) {
        s7 = null;
      }
  }
  return s7;
} };
var a = (t6, i6) => i6 !== t6 && (i6 == i6 || t6 == t6);
var l = { attribute: true, type: String, converter: n2, reflect: false, hasChanged: a };
var d = "finalized";
var u = class extends HTMLElement {
  constructor() {
    super(), this._$Ei = /* @__PURE__ */ new Map(), this.isUpdatePending = false, this.hasUpdated = false, this._$El = null, this.u();
  }
  static addInitializer(t6) {
    var i6;
    this.finalize(), (null !== (i6 = this.h) && void 0 !== i6 ? i6 : this.h = []).push(t6);
  }
  static get observedAttributes() {
    this.finalize();
    const t6 = [];
    return this.elementProperties.forEach((i6, s7) => {
      const e9 = this._$Ep(s7, i6);
      void 0 !== e9 && (this._$Ev.set(e9, s7), t6.push(e9));
    }), t6;
  }
  static createProperty(t6, i6 = l) {
    if (i6.state && (i6.attribute = false), this.finalize(), this.elementProperties.set(t6, i6), !i6.noAccessor && !this.prototype.hasOwnProperty(t6)) {
      const s7 = "symbol" == typeof t6 ? Symbol() : "__" + t6, e9 = this.getPropertyDescriptor(t6, s7, i6);
      void 0 !== e9 && Object.defineProperty(this.prototype, t6, e9);
    }
  }
  static getPropertyDescriptor(t6, i6, s7) {
    return { get() {
      return this[i6];
    }, set(e9) {
      const r6 = this[t6];
      this[i6] = e9, this.requestUpdate(t6, r6, s7);
    }, configurable: true, enumerable: true };
  }
  static getPropertyOptions(t6) {
    return this.elementProperties.get(t6) || l;
  }
  static finalize() {
    if (this.hasOwnProperty(d))
      return false;
    this[d] = true;
    const t6 = Object.getPrototypeOf(this);
    if (t6.finalize(), void 0 !== t6.h && (this.h = [...t6.h]), this.elementProperties = new Map(t6.elementProperties), this._$Ev = /* @__PURE__ */ new Map(), this.hasOwnProperty("properties")) {
      const t7 = this.properties, i6 = [...Object.getOwnPropertyNames(t7), ...Object.getOwnPropertySymbols(t7)];
      for (const s7 of i6)
        this.createProperty(s7, t7[s7]);
    }
    return this.elementStyles = this.finalizeStyles(this.styles), true;
  }
  static finalizeStyles(i6) {
    const s7 = [];
    if (Array.isArray(i6)) {
      const e9 = new Set(i6.flat(1 / 0).reverse());
      for (const i7 of e9)
        s7.unshift(c(i7));
    } else
      void 0 !== i6 && s7.push(c(i6));
    return s7;
  }
  static _$Ep(t6, i6) {
    const s7 = i6.attribute;
    return false === s7 ? void 0 : "string" == typeof s7 ? s7 : "string" == typeof t6 ? t6.toLowerCase() : void 0;
  }
  u() {
    var t6;
    this._$E_ = new Promise((t7) => this.enableUpdating = t7), this._$AL = /* @__PURE__ */ new Map(), this._$Eg(), this.requestUpdate(), null === (t6 = this.constructor.h) || void 0 === t6 || t6.forEach((t7) => t7(this));
  }
  addController(t6) {
    var i6, s7;
    (null !== (i6 = this._$ES) && void 0 !== i6 ? i6 : this._$ES = []).push(t6), void 0 !== this.renderRoot && this.isConnected && (null === (s7 = t6.hostConnected) || void 0 === s7 || s7.call(t6));
  }
  removeController(t6) {
    var i6;
    null === (i6 = this._$ES) || void 0 === i6 || i6.splice(this._$ES.indexOf(t6) >>> 0, 1);
  }
  _$Eg() {
    this.constructor.elementProperties.forEach((t6, i6) => {
      this.hasOwnProperty(i6) && (this._$Ei.set(i6, this[i6]), delete this[i6]);
    });
  }
  createRenderRoot() {
    var t6;
    const s7 = null !== (t6 = this.shadowRoot) && void 0 !== t6 ? t6 : this.attachShadow(this.constructor.shadowRootOptions);
    return S(s7, this.constructor.elementStyles), s7;
  }
  connectedCallback() {
    var t6;
    void 0 === this.renderRoot && (this.renderRoot = this.createRenderRoot()), this.enableUpdating(true), null === (t6 = this._$ES) || void 0 === t6 || t6.forEach((t7) => {
      var i6;
      return null === (i6 = t7.hostConnected) || void 0 === i6 ? void 0 : i6.call(t7);
    });
  }
  enableUpdating(t6) {
  }
  disconnectedCallback() {
    var t6;
    null === (t6 = this._$ES) || void 0 === t6 || t6.forEach((t7) => {
      var i6;
      return null === (i6 = t7.hostDisconnected) || void 0 === i6 ? void 0 : i6.call(t7);
    });
  }
  attributeChangedCallback(t6, i6, s7) {
    this._$AK(t6, s7);
  }
  _$EO(t6, i6, s7 = l) {
    var e9;
    const r6 = this.constructor._$Ep(t6, s7);
    if (void 0 !== r6 && true === s7.reflect) {
      const h5 = (void 0 !== (null === (e9 = s7.converter) || void 0 === e9 ? void 0 : e9.toAttribute) ? s7.converter : n2).toAttribute(i6, s7.type);
      this._$El = t6, null == h5 ? this.removeAttribute(r6) : this.setAttribute(r6, h5), this._$El = null;
    }
  }
  _$AK(t6, i6) {
    var s7;
    const e9 = this.constructor, r6 = e9._$Ev.get(t6);
    if (void 0 !== r6 && this._$El !== r6) {
      const t7 = e9.getPropertyOptions(r6), h5 = "function" == typeof t7.converter ? { fromAttribute: t7.converter } : void 0 !== (null === (s7 = t7.converter) || void 0 === s7 ? void 0 : s7.fromAttribute) ? t7.converter : n2;
      this._$El = r6, this[r6] = h5.fromAttribute(i6, t7.type), this._$El = null;
    }
  }
  requestUpdate(t6, i6, s7) {
    let e9 = true;
    void 0 !== t6 && (((s7 = s7 || this.constructor.getPropertyOptions(t6)).hasChanged || a)(this[t6], i6) ? (this._$AL.has(t6) || this._$AL.set(t6, i6), true === s7.reflect && this._$El !== t6 && (void 0 === this._$EC && (this._$EC = /* @__PURE__ */ new Map()), this._$EC.set(t6, s7))) : e9 = false), !this.isUpdatePending && e9 && (this._$E_ = this._$Ej());
  }
  async _$Ej() {
    this.isUpdatePending = true;
    try {
      await this._$E_;
    } catch (t7) {
      Promise.reject(t7);
    }
    const t6 = this.scheduleUpdate();
    return null != t6 && await t6, !this.isUpdatePending;
  }
  scheduleUpdate() {
    return this.performUpdate();
  }
  performUpdate() {
    var t6;
    if (!this.isUpdatePending)
      return;
    this.hasUpdated, this._$Ei && (this._$Ei.forEach((t7, i7) => this[i7] = t7), this._$Ei = void 0);
    let i6 = false;
    const s7 = this._$AL;
    try {
      i6 = this.shouldUpdate(s7), i6 ? (this.willUpdate(s7), null === (t6 = this._$ES) || void 0 === t6 || t6.forEach((t7) => {
        var i7;
        return null === (i7 = t7.hostUpdate) || void 0 === i7 ? void 0 : i7.call(t7);
      }), this.update(s7)) : this._$Ek();
    } catch (t7) {
      throw i6 = false, this._$Ek(), t7;
    }
    i6 && this._$AE(s7);
  }
  willUpdate(t6) {
  }
  _$AE(t6) {
    var i6;
    null === (i6 = this._$ES) || void 0 === i6 || i6.forEach((t7) => {
      var i7;
      return null === (i7 = t7.hostUpdated) || void 0 === i7 ? void 0 : i7.call(t7);
    }), this.hasUpdated || (this.hasUpdated = true, this.firstUpdated(t6)), this.updated(t6);
  }
  _$Ek() {
    this._$AL = /* @__PURE__ */ new Map(), this.isUpdatePending = false;
  }
  get updateComplete() {
    return this.getUpdateComplete();
  }
  getUpdateComplete() {
    return this._$E_;
  }
  shouldUpdate(t6) {
    return true;
  }
  update(t6) {
    void 0 !== this._$EC && (this._$EC.forEach((t7, i6) => this._$EO(i6, this[i6], t7)), this._$EC = void 0), this._$Ek();
  }
  updated(t6) {
  }
  firstUpdated(t6) {
  }
};
u[d] = true, u.elementProperties = /* @__PURE__ */ new Map(), u.elementStyles = [], u.shadowRootOptions = { mode: "open" }, null == o2 || o2({ ReactiveElement: u }), (null !== (s2 = e2.reactiveElementVersions) && void 0 !== s2 ? s2 : e2.reactiveElementVersions = []).push("1.6.2");

// node_modules/lit-html/lit-html.js
var t2;
var i2 = window;
var s3 = i2.trustedTypes;
var e3 = s3 ? s3.createPolicy("lit-html", { createHTML: (t6) => t6 }) : void 0;
var o3 = "$lit$";
var n3 = `lit$${(Math.random() + "").slice(9)}$`;
var l2 = "?" + n3;
var h2 = `<${l2}>`;
var r3 = document;
var d2 = () => r3.createComment("");
var u2 = (t6) => null === t6 || "object" != typeof t6 && "function" != typeof t6;
var c2 = Array.isArray;
var v = (t6) => c2(t6) || "function" == typeof (null == t6 ? void 0 : t6[Symbol.iterator]);
var a2 = "[ 	\n\f\r]";
var f = /<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g;
var _ = /-->/g;
var m = />/g;
var p = RegExp(`>|${a2}(?:([^\\s"'>=/]+)(${a2}*=${a2}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`, "g");
var g = /'/g;
var $2 = /"/g;
var y = /^(?:script|style|textarea|title)$/i;
var w = (t6) => (i6, ...s7) => ({ _$litType$: t6, strings: i6, values: s7 });
var x = w(1);
var b = w(2);
var T = Symbol.for("lit-noChange");
var A = Symbol.for("lit-nothing");
var E = /* @__PURE__ */ new WeakMap();
var C = r3.createTreeWalker(r3, 129, null, false);
var P = (t6, i6) => {
  const s7 = t6.length - 1, l7 = [];
  let r6, d5 = 2 === i6 ? "<svg>" : "", u5 = f;
  for (let i7 = 0; i7 < s7; i7++) {
    const s8 = t6[i7];
    let e9, c6, v4 = -1, a5 = 0;
    for (; a5 < s8.length && (u5.lastIndex = a5, c6 = u5.exec(s8), null !== c6); )
      a5 = u5.lastIndex, u5 === f ? "!--" === c6[1] ? u5 = _ : void 0 !== c6[1] ? u5 = m : void 0 !== c6[2] ? (y.test(c6[2]) && (r6 = RegExp("</" + c6[2], "g")), u5 = p) : void 0 !== c6[3] && (u5 = p) : u5 === p ? ">" === c6[0] ? (u5 = null != r6 ? r6 : f, v4 = -1) : void 0 === c6[1] ? v4 = -2 : (v4 = u5.lastIndex - c6[2].length, e9 = c6[1], u5 = void 0 === c6[3] ? p : '"' === c6[3] ? $2 : g) : u5 === $2 || u5 === g ? u5 = p : u5 === _ || u5 === m ? u5 = f : (u5 = p, r6 = void 0);
    const w5 = u5 === p && t6[i7 + 1].startsWith("/>") ? " " : "";
    d5 += u5 === f ? s8 + h2 : v4 >= 0 ? (l7.push(e9), s8.slice(0, v4) + o3 + s8.slice(v4) + n3 + w5) : s8 + n3 + (-2 === v4 ? (l7.push(void 0), i7) : w5);
  }
  const c5 = d5 + (t6[s7] || "<?>") + (2 === i6 ? "</svg>" : "");
  if (!Array.isArray(t6) || !t6.hasOwnProperty("raw"))
    throw Error("invalid template strings array");
  return [void 0 !== e3 ? e3.createHTML(c5) : c5, l7];
};
var V = class _V {
  constructor({ strings: t6, _$litType$: i6 }, e9) {
    let h5;
    this.parts = [];
    let r6 = 0, u5 = 0;
    const c5 = t6.length - 1, v4 = this.parts, [a5, f4] = P(t6, i6);
    if (this.el = _V.createElement(a5, e9), C.currentNode = this.el.content, 2 === i6) {
      const t7 = this.el.content, i7 = t7.firstChild;
      i7.remove(), t7.append(...i7.childNodes);
    }
    for (; null !== (h5 = C.nextNode()) && v4.length < c5; ) {
      if (1 === h5.nodeType) {
        if (h5.hasAttributes()) {
          const t7 = [];
          for (const i7 of h5.getAttributeNames())
            if (i7.endsWith(o3) || i7.startsWith(n3)) {
              const s7 = f4[u5++];
              if (t7.push(i7), void 0 !== s7) {
                const t8 = h5.getAttribute(s7.toLowerCase() + o3).split(n3), i8 = /([.?@])?(.*)/.exec(s7);
                v4.push({ type: 1, index: r6, name: i8[2], strings: t8, ctor: "." === i8[1] ? k : "?" === i8[1] ? I : "@" === i8[1] ? L : R });
              } else
                v4.push({ type: 6, index: r6 });
            }
          for (const i7 of t7)
            h5.removeAttribute(i7);
        }
        if (y.test(h5.tagName)) {
          const t7 = h5.textContent.split(n3), i7 = t7.length - 1;
          if (i7 > 0) {
            h5.textContent = s3 ? s3.emptyScript : "";
            for (let s7 = 0; s7 < i7; s7++)
              h5.append(t7[s7], d2()), C.nextNode(), v4.push({ type: 2, index: ++r6 });
            h5.append(t7[i7], d2());
          }
        }
      } else if (8 === h5.nodeType)
        if (h5.data === l2)
          v4.push({ type: 2, index: r6 });
        else {
          let t7 = -1;
          for (; -1 !== (t7 = h5.data.indexOf(n3, t7 + 1)); )
            v4.push({ type: 7, index: r6 }), t7 += n3.length - 1;
        }
      r6++;
    }
  }
  static createElement(t6, i6) {
    const s7 = r3.createElement("template");
    return s7.innerHTML = t6, s7;
  }
};
function N(t6, i6, s7 = t6, e9) {
  var o8, n8, l7, h5;
  if (i6 === T)
    return i6;
  let r6 = void 0 !== e9 ? null === (o8 = s7._$Co) || void 0 === o8 ? void 0 : o8[e9] : s7._$Cl;
  const d5 = u2(i6) ? void 0 : i6._$litDirective$;
  return (null == r6 ? void 0 : r6.constructor) !== d5 && (null === (n8 = null == r6 ? void 0 : r6._$AO) || void 0 === n8 || n8.call(r6, false), void 0 === d5 ? r6 = void 0 : (r6 = new d5(t6), r6._$AT(t6, s7, e9)), void 0 !== e9 ? (null !== (l7 = (h5 = s7)._$Co) && void 0 !== l7 ? l7 : h5._$Co = [])[e9] = r6 : s7._$Cl = r6), void 0 !== r6 && (i6 = N(t6, r6._$AS(t6, i6.values), r6, e9)), i6;
}
var S2 = class {
  constructor(t6, i6) {
    this._$AV = [], this._$AN = void 0, this._$AD = t6, this._$AM = i6;
  }
  get parentNode() {
    return this._$AM.parentNode;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  u(t6) {
    var i6;
    const { el: { content: s7 }, parts: e9 } = this._$AD, o8 = (null !== (i6 = null == t6 ? void 0 : t6.creationScope) && void 0 !== i6 ? i6 : r3).importNode(s7, true);
    C.currentNode = o8;
    let n8 = C.nextNode(), l7 = 0, h5 = 0, d5 = e9[0];
    for (; void 0 !== d5; ) {
      if (l7 === d5.index) {
        let i7;
        2 === d5.type ? i7 = new M(n8, n8.nextSibling, this, t6) : 1 === d5.type ? i7 = new d5.ctor(n8, d5.name, d5.strings, this, t6) : 6 === d5.type && (i7 = new z(n8, this, t6)), this._$AV.push(i7), d5 = e9[++h5];
      }
      l7 !== (null == d5 ? void 0 : d5.index) && (n8 = C.nextNode(), l7++);
    }
    return C.currentNode = r3, o8;
  }
  v(t6) {
    let i6 = 0;
    for (const s7 of this._$AV)
      void 0 !== s7 && (void 0 !== s7.strings ? (s7._$AI(t6, s7, i6), i6 += s7.strings.length - 2) : s7._$AI(t6[i6])), i6++;
  }
};
var M = class _M {
  constructor(t6, i6, s7, e9) {
    var o8;
    this.type = 2, this._$AH = A, this._$AN = void 0, this._$AA = t6, this._$AB = i6, this._$AM = s7, this.options = e9, this._$Cp = null === (o8 = null == e9 ? void 0 : e9.isConnected) || void 0 === o8 || o8;
  }
  get _$AU() {
    var t6, i6;
    return null !== (i6 = null === (t6 = this._$AM) || void 0 === t6 ? void 0 : t6._$AU) && void 0 !== i6 ? i6 : this._$Cp;
  }
  get parentNode() {
    let t6 = this._$AA.parentNode;
    const i6 = this._$AM;
    return void 0 !== i6 && 11 === (null == t6 ? void 0 : t6.nodeType) && (t6 = i6.parentNode), t6;
  }
  get startNode() {
    return this._$AA;
  }
  get endNode() {
    return this._$AB;
  }
  _$AI(t6, i6 = this) {
    t6 = N(this, t6, i6), u2(t6) ? t6 === A || null == t6 || "" === t6 ? (this._$AH !== A && this._$AR(), this._$AH = A) : t6 !== this._$AH && t6 !== T && this._(t6) : void 0 !== t6._$litType$ ? this.g(t6) : void 0 !== t6.nodeType ? this.$(t6) : v(t6) ? this.T(t6) : this._(t6);
  }
  k(t6) {
    return this._$AA.parentNode.insertBefore(t6, this._$AB);
  }
  $(t6) {
    this._$AH !== t6 && (this._$AR(), this._$AH = this.k(t6));
  }
  _(t6) {
    this._$AH !== A && u2(this._$AH) ? this._$AA.nextSibling.data = t6 : this.$(r3.createTextNode(t6)), this._$AH = t6;
  }
  g(t6) {
    var i6;
    const { values: s7, _$litType$: e9 } = t6, o8 = "number" == typeof e9 ? this._$AC(t6) : (void 0 === e9.el && (e9.el = V.createElement(e9.h, this.options)), e9);
    if ((null === (i6 = this._$AH) || void 0 === i6 ? void 0 : i6._$AD) === o8)
      this._$AH.v(s7);
    else {
      const t7 = new S2(o8, this), i7 = t7.u(this.options);
      t7.v(s7), this.$(i7), this._$AH = t7;
    }
  }
  _$AC(t6) {
    let i6 = E.get(t6.strings);
    return void 0 === i6 && E.set(t6.strings, i6 = new V(t6)), i6;
  }
  T(t6) {
    c2(this._$AH) || (this._$AH = [], this._$AR());
    const i6 = this._$AH;
    let s7, e9 = 0;
    for (const o8 of t6)
      e9 === i6.length ? i6.push(s7 = new _M(this.k(d2()), this.k(d2()), this, this.options)) : s7 = i6[e9], s7._$AI(o8), e9++;
    e9 < i6.length && (this._$AR(s7 && s7._$AB.nextSibling, e9), i6.length = e9);
  }
  _$AR(t6 = this._$AA.nextSibling, i6) {
    var s7;
    for (null === (s7 = this._$AP) || void 0 === s7 || s7.call(this, false, true, i6); t6 && t6 !== this._$AB; ) {
      const i7 = t6.nextSibling;
      t6.remove(), t6 = i7;
    }
  }
  setConnected(t6) {
    var i6;
    void 0 === this._$AM && (this._$Cp = t6, null === (i6 = this._$AP) || void 0 === i6 || i6.call(this, t6));
  }
};
var R = class {
  constructor(t6, i6, s7, e9, o8) {
    this.type = 1, this._$AH = A, this._$AN = void 0, this.element = t6, this.name = i6, this._$AM = e9, this.options = o8, s7.length > 2 || "" !== s7[0] || "" !== s7[1] ? (this._$AH = Array(s7.length - 1).fill(new String()), this.strings = s7) : this._$AH = A;
  }
  get tagName() {
    return this.element.tagName;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  _$AI(t6, i6 = this, s7, e9) {
    const o8 = this.strings;
    let n8 = false;
    if (void 0 === o8)
      t6 = N(this, t6, i6, 0), n8 = !u2(t6) || t6 !== this._$AH && t6 !== T, n8 && (this._$AH = t6);
    else {
      const e10 = t6;
      let l7, h5;
      for (t6 = o8[0], l7 = 0; l7 < o8.length - 1; l7++)
        h5 = N(this, e10[s7 + l7], i6, l7), h5 === T && (h5 = this._$AH[l7]), n8 || (n8 = !u2(h5) || h5 !== this._$AH[l7]), h5 === A ? t6 = A : t6 !== A && (t6 += (null != h5 ? h5 : "") + o8[l7 + 1]), this._$AH[l7] = h5;
    }
    n8 && !e9 && this.j(t6);
  }
  j(t6) {
    t6 === A ? this.element.removeAttribute(this.name) : this.element.setAttribute(this.name, null != t6 ? t6 : "");
  }
};
var k = class extends R {
  constructor() {
    super(...arguments), this.type = 3;
  }
  j(t6) {
    this.element[this.name] = t6 === A ? void 0 : t6;
  }
};
var H = s3 ? s3.emptyScript : "";
var I = class extends R {
  constructor() {
    super(...arguments), this.type = 4;
  }
  j(t6) {
    t6 && t6 !== A ? this.element.setAttribute(this.name, H) : this.element.removeAttribute(this.name);
  }
};
var L = class extends R {
  constructor(t6, i6, s7, e9, o8) {
    super(t6, i6, s7, e9, o8), this.type = 5;
  }
  _$AI(t6, i6 = this) {
    var s7;
    if ((t6 = null !== (s7 = N(this, t6, i6, 0)) && void 0 !== s7 ? s7 : A) === T)
      return;
    const e9 = this._$AH, o8 = t6 === A && e9 !== A || t6.capture !== e9.capture || t6.once !== e9.once || t6.passive !== e9.passive, n8 = t6 !== A && (e9 === A || o8);
    o8 && this.element.removeEventListener(this.name, this, e9), n8 && this.element.addEventListener(this.name, this, t6), this._$AH = t6;
  }
  handleEvent(t6) {
    var i6, s7;
    "function" == typeof this._$AH ? this._$AH.call(null !== (s7 = null === (i6 = this.options) || void 0 === i6 ? void 0 : i6.host) && void 0 !== s7 ? s7 : this.element, t6) : this._$AH.handleEvent(t6);
  }
};
var z = class {
  constructor(t6, i6, s7) {
    this.element = t6, this.type = 6, this._$AN = void 0, this._$AM = i6, this.options = s7;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  _$AI(t6) {
    N(this, t6);
  }
};
var j = i2.litHtmlPolyfillSupport;
null == j || j(V, M), (null !== (t2 = i2.litHtmlVersions) && void 0 !== t2 ? t2 : i2.litHtmlVersions = []).push("2.7.4");
var B = (t6, i6, s7) => {
  var e9, o8;
  const n8 = null !== (e9 = null == s7 ? void 0 : s7.renderBefore) && void 0 !== e9 ? e9 : i6;
  let l7 = n8._$litPart$;
  if (void 0 === l7) {
    const t7 = null !== (o8 = null == s7 ? void 0 : s7.renderBefore) && void 0 !== o8 ? o8 : null;
    n8._$litPart$ = l7 = new M(i6.insertBefore(d2(), t7), t7, void 0, null != s7 ? s7 : {});
  }
  return l7._$AI(t6), l7;
};

// node_modules/lit-element/lit-element.js
var l3;
var o4;
var s4 = class extends u {
  constructor() {
    super(...arguments), this.renderOptions = { host: this }, this._$Do = void 0;
  }
  createRenderRoot() {
    var t6, e9;
    const i6 = super.createRenderRoot();
    return null !== (t6 = (e9 = this.renderOptions).renderBefore) && void 0 !== t6 || (e9.renderBefore = i6.firstChild), i6;
  }
  update(t6) {
    const i6 = this.render();
    this.hasUpdated || (this.renderOptions.isConnected = this.isConnected), super.update(t6), this._$Do = B(i6, this.renderRoot, this.renderOptions);
  }
  connectedCallback() {
    var t6;
    super.connectedCallback(), null === (t6 = this._$Do) || void 0 === t6 || t6.setConnected(true);
  }
  disconnectedCallback() {
    var t6;
    super.disconnectedCallback(), null === (t6 = this._$Do) || void 0 === t6 || t6.setConnected(false);
  }
  render() {
    return T;
  }
};
s4.finalized = true, s4._$litElement$ = true, null === (l3 = globalThis.litElementHydrateSupport) || void 0 === l3 || l3.call(globalThis, { LitElement: s4 });
var n4 = globalThis.litElementPolyfillSupport;
null == n4 || n4({ LitElement: s4 });
(null !== (o4 = globalThis.litElementVersions) && void 0 !== o4 ? o4 : globalThis.litElementVersions = []).push("3.3.2");

// src/collapsible.ts
var dirToIcon = {
  right: "\u25BA",
  left: "\u25C0\uFE0E",
  bottom: "\u25B2",
  top: "\u25B2"
};
var horizontalCollapseStyles = i`
  .horizontal .content {
    max-width: 100vw;
    transition: max-width var(--transition), transform var(--transition),
      padding-inline var(--transition);
  }

  .horizontal .content > * {
    min-width: 0;
  }

  .horizontal .toggle {
    padding-inline: var(--size-xs);
  }

  .horizontal.closed .toggle > .icon {
    transform: scaleX(-1);
  }

  .horizontal.closed .content {
    max-width: 0;
    transform: scaleX(0);
    padding-inline: 0;
  }
`;
var toLeftCollapseStyles = i`
  .left .content {
    transform-origin: left;
  }

  .left .toggle {
    top: var(--size-xs);
    right: var(--space-small);
    width: var(--toggle-size);
    height: auto;
  }
`;
var toRightCollapseStyles = i`
  .right .content {
    transform-origin: left;
  }

  .right .toggle {
    order: -1;
    top: var(--size-xs);
    right: 0;
    width: var(--toggle-size);
    height: auto;
  }
`;
var verticalCollapseStyles = i`
  .vertical {
    flex-direction: column;
  }

  .vertical > .content {
    max-height: 100vh;
    transition: max-height var(--transition), transform var(--transition),
      padding-block var(--transition);
  }

  .vertical > .toggle {
    min-height: var(--size-l);
  }

  .vertical .toggle > .icon {
    position: absolute;
    right: var(--space-x-small);
  }

  .vertical.closed .toggle > .icon {
    transform: rotate(180deg);
  }

  .vertical.content > ::slotted(*) {
    min-height: 0;
  }

  .vertical.closed .content {
    transform: scaleY(0);
    max-height: 0;
    padding-block: 0;
  }
`;
var toBottomCollapseStyles = i`
  .bottom .toggle {
    order: -1;
    right: var(--space-medium);
    bottom: 0;
  }
`;
var toTopCollapseStyles = i`
  .top .toggle {
    right: var(--size-xs);
  }
`;
var Collapsible = class extends s4 {
  constructor() {
    super();
    this.start_state = "open";
    this.opened = null;
    this.dir = "top";
    this.label = null;
  }
  static {
    this.properties = {
      label: {},
      opened: { type: "boolean" },
      start_state: {},
      dir: {}
    };
  }
  static {
    // Styles are scoped to this element: they won't conflict with styles
    // on the main page or in other components. Styling API can be exposed
    // via CSS custom properties.
    this.styles = [
      i`
      :host {
        --transition: 0.4s var(--ease-3);
        --toggle-size: 20px;
        --accent-color: var(--stone-3);

        display: block;
        font-family: var(--font-family, sans-serif);
        position: relative;
        outline: 1px solid var(--accent-color, pink);
        margin: var(--size-s);
        border-radius: var(--radius-s);
      }

      .container {
        display: flex;
      }

      .content {
        overflow: auto;
        transition: transform var(--transition);
        padding: var(--size-fluid-1);
      }

      .toggle {
        background-color: var(--accent-color);
        font-size: var(--font-size-m);
        display: grid;
        place-content: center;
        cursor: pointer;
      }

      .toggle > .icon {
        transition: transform var(--transition);
        user-select: none;
        color: var(--color-action);
      }
    `,
      horizontalCollapseStyles,
      toRightCollapseStyles,
      toLeftCollapseStyles,
      verticalCollapseStyles,
      toBottomCollapseStyles,
      toTopCollapseStyles
    ];
  }
  render() {
    return x`
      <div
        class="container ${this.dir} ${this.dir === "bottom" || this.dir === "top" ? "vertical" : "horizontal"} ${this.isOpen ? "open" : "closed"}"
      >
        <div class="content">
          <slot></slot>
        </div>
        <div
          class="toggle"
          @click=${this.toggleOpen}
          title=${this.isOpen ? "Close collapsible" : "Open collapsible"}
        >
          ${this.label ? x`<span>${this.label}</span>` : ""}
          <span class="icon"> ${dirToIcon[this.dir]} </span>
        </div>
      </div>
    `;
  }
  get isOpen() {
    if (this.opened === null) {
      return this.start_state === "open";
    }
    return this.opened;
  }
  toggleOpen() {
    if (this.opened === null) {
      this.opened = this.start_state !== "open";
      return;
    }
    this.opened = !this.opened;
    window.dispatchEvent(new Event("resize"));
  }
};
customElements.define("shiny-collapsible", Collapsible);

// src/color-picker.tsx
init_react();

// node_modules/react-color/es/components/alpha/Alpha.js
init_react();
var import_reactcss9 = __toESM(require_lib());

// node_modules/react-color/es/components/common/Alpha.js
init_react();
var import_reactcss2 = __toESM(require_lib());

// node_modules/react-color/es/helpers/alpha.js
var calculateChange = function calculateChange2(e9, hsl, direction, initialA, container) {
  var containerWidth = container.clientWidth;
  var containerHeight = container.clientHeight;
  var x5 = typeof e9.pageX === "number" ? e9.pageX : e9.touches[0].pageX;
  var y4 = typeof e9.pageY === "number" ? e9.pageY : e9.touches[0].pageY;
  var left = x5 - (container.getBoundingClientRect().left + window.pageXOffset);
  var top = y4 - (container.getBoundingClientRect().top + window.pageYOffset);
  if (direction === "vertical") {
    var a5 = void 0;
    if (top < 0) {
      a5 = 0;
    } else if (top > containerHeight) {
      a5 = 1;
    } else {
      a5 = Math.round(top * 100 / containerHeight) / 100;
    }
    if (hsl.a !== a5) {
      return {
        h: hsl.h,
        s: hsl.s,
        l: hsl.l,
        a: a5,
        source: "rgb"
      };
    }
  } else {
    var _a = void 0;
    if (left < 0) {
      _a = 0;
    } else if (left > containerWidth) {
      _a = 1;
    } else {
      _a = Math.round(left * 100 / containerWidth) / 100;
    }
    if (initialA !== _a) {
      return {
        h: hsl.h,
        s: hsl.s,
        l: hsl.l,
        a: _a,
        source: "rgb"
      };
    }
  }
  return null;
};

// node_modules/react-color/es/components/common/Checkboard.js
init_react();
var import_reactcss = __toESM(require_lib());

// node_modules/react-color/es/helpers/checkboard.js
var checkboardCache = {};
var render = function render2(c1, c22, size, serverCanvas) {
  if (typeof document === "undefined" && !serverCanvas) {
    return null;
  }
  var canvas = serverCanvas ? new serverCanvas() : document.createElement("canvas");
  canvas.width = size * 2;
  canvas.height = size * 2;
  var ctx = canvas.getContext("2d");
  if (!ctx) {
    return null;
  }
  ctx.fillStyle = c1;
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = c22;
  ctx.fillRect(0, 0, size, size);
  ctx.translate(size, size);
  ctx.fillRect(0, 0, size, size);
  return canvas.toDataURL();
};
var get = function get2(c1, c22, size, serverCanvas) {
  var key = c1 + "-" + c22 + "-" + size + (serverCanvas ? "-server" : "");
  if (checkboardCache[key]) {
    return checkboardCache[key];
  }
  var checkboard = render(c1, c22, size, serverCanvas);
  checkboardCache[key] = checkboard;
  return checkboard;
};

// node_modules/react-color/es/components/common/Checkboard.js
var _extends = Object.assign || function(target) {
  for (var i6 = 1; i6 < arguments.length; i6++) {
    var source = arguments[i6];
    for (var key in source) {
      if (Object.prototype.hasOwnProperty.call(source, key)) {
        target[key] = source[key];
      }
    }
  }
  return target;
};
var Checkboard = function Checkboard2(_ref) {
  var white = _ref.white, grey = _ref.grey, size = _ref.size, renderers = _ref.renderers, borderRadius = _ref.borderRadius, boxShadow = _ref.boxShadow, children = _ref.children;
  var styles = (0, import_reactcss.default)({
    "default": {
      grid: {
        borderRadius,
        boxShadow,
        absolute: "0px 0px 0px 0px",
        background: "url(" + get(white, grey, size, renderers.canvas) + ") center left"
      }
    }
  });
  return an(children) ? Cn.cloneElement(children, _extends({}, children.props, { style: _extends({}, children.props.style, styles.grid) })) : Cn.createElement("div", { style: styles.grid });
};
Checkboard.defaultProps = {
  size: 8,
  white: "transparent",
  grey: "rgba(0,0,0,.08)",
  renderers: {}
};
var Checkboard_default = Checkboard;

// node_modules/react-color/es/components/common/Alpha.js
var _extends2 = Object.assign || function(target) {
  for (var i6 = 1; i6 < arguments.length; i6++) {
    var source = arguments[i6];
    for (var key in source) {
      if (Object.prototype.hasOwnProperty.call(source, key)) {
        target[key] = source[key];
      }
    }
  }
  return target;
};
var _createClass = function() {
  function defineProperties(target, props) {
    for (var i6 = 0; i6 < props.length; i6++) {
      var descriptor = props[i6];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor)
        descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }
  return function(Constructor, protoProps, staticProps) {
    if (protoProps)
      defineProperties(Constructor.prototype, protoProps);
    if (staticProps)
      defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();
function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _possibleConstructorReturn(self2, call) {
  if (!self2) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return call && (typeof call === "object" || typeof call === "function") ? call : self2;
}
function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
  if (superClass)
    Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
}
var Alpha = function(_ref) {
  _inherits(Alpha2, _ref);
  function Alpha2() {
    var _ref2;
    var _temp, _this, _ret;
    _classCallCheck(this, Alpha2);
    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }
    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref2 = Alpha2.__proto__ || Object.getPrototypeOf(Alpha2)).call.apply(_ref2, [this].concat(args))), _this), _this.handleChange = function(e9) {
      var change = calculateChange(e9, _this.props.hsl, _this.props.direction, _this.props.a, _this.container);
      change && typeof _this.props.onChange === "function" && _this.props.onChange(change, e9);
    }, _this.handleMouseDown = function(e9) {
      _this.handleChange(e9);
      window.addEventListener("mousemove", _this.handleChange);
      window.addEventListener("mouseup", _this.handleMouseUp);
    }, _this.handleMouseUp = function() {
      _this.unbindEventListeners();
    }, _this.unbindEventListeners = function() {
      window.removeEventListener("mousemove", _this.handleChange);
      window.removeEventListener("mouseup", _this.handleMouseUp);
    }, _temp), _possibleConstructorReturn(_this, _ret);
  }
  _createClass(Alpha2, [{
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      this.unbindEventListeners();
    }
  }, {
    key: "render",
    value: function render3() {
      var _this2 = this;
      var rgb = this.props.rgb;
      var styles = (0, import_reactcss2.default)({
        "default": {
          alpha: {
            absolute: "0px 0px 0px 0px",
            borderRadius: this.props.radius
          },
          checkboard: {
            absolute: "0px 0px 0px 0px",
            overflow: "hidden",
            borderRadius: this.props.radius
          },
          gradient: {
            absolute: "0px 0px 0px 0px",
            background: "linear-gradient(to right, rgba(" + rgb.r + "," + rgb.g + "," + rgb.b + ", 0) 0%,\n           rgba(" + rgb.r + "," + rgb.g + "," + rgb.b + ", 1) 100%)",
            boxShadow: this.props.shadow,
            borderRadius: this.props.radius
          },
          container: {
            position: "relative",
            height: "100%",
            margin: "0 3px"
          },
          pointer: {
            position: "absolute",
            left: rgb.a * 100 + "%"
          },
          slider: {
            width: "4px",
            borderRadius: "1px",
            height: "8px",
            boxShadow: "0 0 2px rgba(0, 0, 0, .6)",
            background: "#fff",
            marginTop: "1px",
            transform: "translateX(-2px)"
          }
        },
        "vertical": {
          gradient: {
            background: "linear-gradient(to bottom, rgba(" + rgb.r + "," + rgb.g + "," + rgb.b + ", 0) 0%,\n           rgba(" + rgb.r + "," + rgb.g + "," + rgb.b + ", 1) 100%)"
          },
          pointer: {
            left: 0,
            top: rgb.a * 100 + "%"
          }
        },
        "overwrite": _extends2({}, this.props.style)
      }, {
        vertical: this.props.direction === "vertical",
        overwrite: true
      });
      return Cn.createElement(
        "div",
        { style: styles.alpha },
        Cn.createElement(
          "div",
          { style: styles.checkboard },
          Cn.createElement(Checkboard_default, { renderers: this.props.renderers })
        ),
        Cn.createElement("div", { style: styles.gradient }),
        Cn.createElement(
          "div",
          {
            style: styles.container,
            ref: function ref(container) {
              return _this2.container = container;
            },
            onMouseDown: this.handleMouseDown,
            onTouchMove: this.handleChange,
            onTouchStart: this.handleChange
          },
          Cn.createElement(
            "div",
            { style: styles.pointer },
            this.props.pointer ? Cn.createElement(this.props.pointer, this.props) : Cn.createElement("div", { style: styles.slider })
          )
        )
      );
    }
  }]);
  return Alpha2;
}(w4 || b2);
var Alpha_default = Alpha;

// node_modules/react-color/es/components/common/EditableInput.js
init_react();
var import_reactcss3 = __toESM(require_lib());
var _createClass2 = function() {
  function defineProperties(target, props) {
    for (var i6 = 0; i6 < props.length; i6++) {
      var descriptor = props[i6];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor)
        descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }
  return function(Constructor, protoProps, staticProps) {
    if (protoProps)
      defineProperties(Constructor.prototype, protoProps);
    if (staticProps)
      defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();
function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, { value, enumerable: true, configurable: true, writable: true });
  } else {
    obj[key] = value;
  }
  return obj;
}
function _classCallCheck2(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _possibleConstructorReturn2(self2, call) {
  if (!self2) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return call && (typeof call === "object" || typeof call === "function") ? call : self2;
}
function _inherits2(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
  if (superClass)
    Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
}
var DEFAULT_ARROW_OFFSET = 1;
var UP_KEY_CODE = 38;
var DOWN_KEY_CODE = 40;
var VALID_KEY_CODES = [UP_KEY_CODE, DOWN_KEY_CODE];
var isValidKeyCode = function isValidKeyCode2(keyCode) {
  return VALID_KEY_CODES.indexOf(keyCode) > -1;
};
var getNumberValue = function getNumberValue2(value) {
  return Number(String(value).replace(/%/g, ""));
};
var idCounter = 1;
var EditableInput = function(_ref) {
  _inherits2(EditableInput2, _ref);
  function EditableInput2(props) {
    _classCallCheck2(this, EditableInput2);
    var _this = _possibleConstructorReturn2(this, (EditableInput2.__proto__ || Object.getPrototypeOf(EditableInput2)).call(this));
    _this.handleBlur = function() {
      if (_this.state.blurValue) {
        _this.setState({ value: _this.state.blurValue, blurValue: null });
      }
    };
    _this.handleChange = function(e9) {
      _this.setUpdatedValue(e9.target.value, e9);
    };
    _this.handleKeyDown = function(e9) {
      var value = getNumberValue(e9.target.value);
      if (!isNaN(value) && isValidKeyCode(e9.keyCode)) {
        var offset = _this.getArrowOffset();
        var updatedValue = e9.keyCode === UP_KEY_CODE ? value + offset : value - offset;
        _this.setUpdatedValue(updatedValue, e9);
      }
    };
    _this.handleDrag = function(e9) {
      if (_this.props.dragLabel) {
        var newValue = Math.round(_this.props.value + e9.movementX);
        if (newValue >= 0 && newValue <= _this.props.dragMax) {
          _this.props.onChange && _this.props.onChange(_this.getValueObjectWithLabel(newValue), e9);
        }
      }
    };
    _this.handleMouseDown = function(e9) {
      if (_this.props.dragLabel) {
        e9.preventDefault();
        _this.handleDrag(e9);
        window.addEventListener("mousemove", _this.handleDrag);
        window.addEventListener("mouseup", _this.handleMouseUp);
      }
    };
    _this.handleMouseUp = function() {
      _this.unbindEventListeners();
    };
    _this.unbindEventListeners = function() {
      window.removeEventListener("mousemove", _this.handleDrag);
      window.removeEventListener("mouseup", _this.handleMouseUp);
    };
    _this.state = {
      value: String(props.value).toUpperCase(),
      blurValue: String(props.value).toUpperCase()
    };
    _this.inputId = "rc-editable-input-" + idCounter++;
    return _this;
  }
  _createClass2(EditableInput2, [{
    key: "componentDidUpdate",
    value: function componentDidUpdate(prevProps, prevState) {
      if (this.props.value !== this.state.value && (prevProps.value !== this.props.value || prevState.value !== this.state.value)) {
        if (this.input === document.activeElement) {
          this.setState({ blurValue: String(this.props.value).toUpperCase() });
        } else {
          this.setState({ value: String(this.props.value).toUpperCase(), blurValue: !this.state.blurValue && String(this.props.value).toUpperCase() });
        }
      }
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      this.unbindEventListeners();
    }
  }, {
    key: "getValueObjectWithLabel",
    value: function getValueObjectWithLabel(value) {
      return _defineProperty({}, this.props.label, value);
    }
  }, {
    key: "getArrowOffset",
    value: function getArrowOffset() {
      return this.props.arrowOffset || DEFAULT_ARROW_OFFSET;
    }
  }, {
    key: "setUpdatedValue",
    value: function setUpdatedValue(value, e9) {
      var onChangeValue = this.props.label ? this.getValueObjectWithLabel(value) : value;
      this.props.onChange && this.props.onChange(onChangeValue, e9);
      this.setState({ value });
    }
  }, {
    key: "render",
    value: function render3() {
      var _this2 = this;
      var styles = (0, import_reactcss3.default)({
        "default": {
          wrap: {
            position: "relative"
          }
        },
        "user-override": {
          wrap: this.props.style && this.props.style.wrap ? this.props.style.wrap : {},
          input: this.props.style && this.props.style.input ? this.props.style.input : {},
          label: this.props.style && this.props.style.label ? this.props.style.label : {}
        },
        "dragLabel-true": {
          label: {
            cursor: "ew-resize"
          }
        }
      }, {
        "user-override": true
      }, this.props);
      return Cn.createElement(
        "div",
        { style: styles.wrap },
        Cn.createElement("input", {
          id: this.inputId,
          style: styles.input,
          ref: function ref(input) {
            return _this2.input = input;
          },
          value: this.state.value,
          onKeyDown: this.handleKeyDown,
          onChange: this.handleChange,
          onBlur: this.handleBlur,
          placeholder: this.props.placeholder,
          spellCheck: "false"
        }),
        this.props.label && !this.props.hideLabel ? Cn.createElement(
          "label",
          {
            htmlFor: this.inputId,
            style: styles.label,
            onMouseDown: this.handleMouseDown
          },
          this.props.label
        ) : null
      );
    }
  }]);
  return EditableInput2;
}(w4 || b2);
var EditableInput_default = EditableInput;

// node_modules/react-color/es/components/common/Hue.js
init_react();
var import_reactcss4 = __toESM(require_lib());

// node_modules/react-color/es/helpers/hue.js
var calculateChange3 = function calculateChange4(e9, direction, hsl, container) {
  var containerWidth = container.clientWidth;
  var containerHeight = container.clientHeight;
  var x5 = typeof e9.pageX === "number" ? e9.pageX : e9.touches[0].pageX;
  var y4 = typeof e9.pageY === "number" ? e9.pageY : e9.touches[0].pageY;
  var left = x5 - (container.getBoundingClientRect().left + window.pageXOffset);
  var top = y4 - (container.getBoundingClientRect().top + window.pageYOffset);
  if (direction === "vertical") {
    var h5 = void 0;
    if (top < 0) {
      h5 = 359;
    } else if (top > containerHeight) {
      h5 = 0;
    } else {
      var percent = -(top * 100 / containerHeight) + 100;
      h5 = 360 * percent / 100;
    }
    if (hsl.h !== h5) {
      return {
        h: h5,
        s: hsl.s,
        l: hsl.l,
        a: hsl.a,
        source: "hsl"
      };
    }
  } else {
    var _h = void 0;
    if (left < 0) {
      _h = 0;
    } else if (left > containerWidth) {
      _h = 359;
    } else {
      var _percent = left * 100 / containerWidth;
      _h = 360 * _percent / 100;
    }
    if (hsl.h !== _h) {
      return {
        h: _h,
        s: hsl.s,
        l: hsl.l,
        a: hsl.a,
        source: "hsl"
      };
    }
  }
  return null;
};

// node_modules/react-color/es/components/common/Hue.js
var _createClass3 = function() {
  function defineProperties(target, props) {
    for (var i6 = 0; i6 < props.length; i6++) {
      var descriptor = props[i6];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor)
        descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }
  return function(Constructor, protoProps, staticProps) {
    if (protoProps)
      defineProperties(Constructor.prototype, protoProps);
    if (staticProps)
      defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();
function _classCallCheck3(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _possibleConstructorReturn3(self2, call) {
  if (!self2) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return call && (typeof call === "object" || typeof call === "function") ? call : self2;
}
function _inherits3(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
  if (superClass)
    Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
}
var Hue = function(_ref) {
  _inherits3(Hue2, _ref);
  function Hue2() {
    var _ref2;
    var _temp, _this, _ret;
    _classCallCheck3(this, Hue2);
    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }
    return _ret = (_temp = (_this = _possibleConstructorReturn3(this, (_ref2 = Hue2.__proto__ || Object.getPrototypeOf(Hue2)).call.apply(_ref2, [this].concat(args))), _this), _this.handleChange = function(e9) {
      var change = calculateChange3(e9, _this.props.direction, _this.props.hsl, _this.container);
      change && typeof _this.props.onChange === "function" && _this.props.onChange(change, e9);
    }, _this.handleMouseDown = function(e9) {
      _this.handleChange(e9);
      window.addEventListener("mousemove", _this.handleChange);
      window.addEventListener("mouseup", _this.handleMouseUp);
    }, _this.handleMouseUp = function() {
      _this.unbindEventListeners();
    }, _temp), _possibleConstructorReturn3(_this, _ret);
  }
  _createClass3(Hue2, [{
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      this.unbindEventListeners();
    }
  }, {
    key: "unbindEventListeners",
    value: function unbindEventListeners() {
      window.removeEventListener("mousemove", this.handleChange);
      window.removeEventListener("mouseup", this.handleMouseUp);
    }
  }, {
    key: "render",
    value: function render3() {
      var _this2 = this;
      var _props$direction = this.props.direction, direction = _props$direction === void 0 ? "horizontal" : _props$direction;
      var styles = (0, import_reactcss4.default)({
        "default": {
          hue: {
            absolute: "0px 0px 0px 0px",
            borderRadius: this.props.radius,
            boxShadow: this.props.shadow
          },
          container: {
            padding: "0 2px",
            position: "relative",
            height: "100%",
            borderRadius: this.props.radius
          },
          pointer: {
            position: "absolute",
            left: this.props.hsl.h * 100 / 360 + "%"
          },
          slider: {
            marginTop: "1px",
            width: "4px",
            borderRadius: "1px",
            height: "8px",
            boxShadow: "0 0 2px rgba(0, 0, 0, .6)",
            background: "#fff",
            transform: "translateX(-2px)"
          }
        },
        "vertical": {
          pointer: {
            left: "0px",
            top: -(this.props.hsl.h * 100 / 360) + 100 + "%"
          }
        }
      }, { vertical: direction === "vertical" });
      return Cn.createElement(
        "div",
        { style: styles.hue },
        Cn.createElement(
          "div",
          {
            className: "hue-" + direction,
            style: styles.container,
            ref: function ref(container) {
              return _this2.container = container;
            },
            onMouseDown: this.handleMouseDown,
            onTouchMove: this.handleChange,
            onTouchStart: this.handleChange
          },
          Cn.createElement(
            "style",
            null,
            "\n            .hue-horizontal {\n              background: linear-gradient(to right, #f00 0%, #ff0 17%, #0f0\n                33%, #0ff 50%, #00f 67%, #f0f 83%, #f00 100%);\n              background: -webkit-linear-gradient(to right, #f00 0%, #ff0\n                17%, #0f0 33%, #0ff 50%, #00f 67%, #f0f 83%, #f00 100%);\n            }\n\n            .hue-vertical {\n              background: linear-gradient(to top, #f00 0%, #ff0 17%, #0f0 33%,\n                #0ff 50%, #00f 67%, #f0f 83%, #f00 100%);\n              background: -webkit-linear-gradient(to top, #f00 0%, #ff0 17%,\n                #0f0 33%, #0ff 50%, #00f 67%, #f0f 83%, #f00 100%);\n            }\n          "
          ),
          Cn.createElement(
            "div",
            { style: styles.pointer },
            this.props.pointer ? Cn.createElement(this.props.pointer, this.props) : Cn.createElement("div", { style: styles.slider })
          )
        )
      );
    }
  }]);
  return Hue2;
}(w4 || b2);
var Hue_default = Hue;

// node_modules/react-color/es/components/common/Raised.js
init_react();
var import_prop_types = __toESM(require_prop_types());
var import_reactcss5 = __toESM(require_lib());

// node_modules/lodash-es/_listCacheClear.js
function listCacheClear() {
  this.__data__ = [];
  this.size = 0;
}
var listCacheClear_default = listCacheClear;

// node_modules/lodash-es/eq.js
function eq(value, other) {
  return value === other || value !== value && other !== other;
}
var eq_default = eq;

// node_modules/lodash-es/_assocIndexOf.js
function assocIndexOf(array, key) {
  var length = array.length;
  while (length--) {
    if (eq_default(array[length][0], key)) {
      return length;
    }
  }
  return -1;
}
var assocIndexOf_default = assocIndexOf;

// node_modules/lodash-es/_listCacheDelete.js
var arrayProto = Array.prototype;
var splice = arrayProto.splice;
function listCacheDelete(key) {
  var data = this.__data__, index = assocIndexOf_default(data, key);
  if (index < 0) {
    return false;
  }
  var lastIndex = data.length - 1;
  if (index == lastIndex) {
    data.pop();
  } else {
    splice.call(data, index, 1);
  }
  --this.size;
  return true;
}
var listCacheDelete_default = listCacheDelete;

// node_modules/lodash-es/_listCacheGet.js
function listCacheGet(key) {
  var data = this.__data__, index = assocIndexOf_default(data, key);
  return index < 0 ? void 0 : data[index][1];
}
var listCacheGet_default = listCacheGet;

// node_modules/lodash-es/_listCacheHas.js
function listCacheHas(key) {
  return assocIndexOf_default(this.__data__, key) > -1;
}
var listCacheHas_default = listCacheHas;

// node_modules/lodash-es/_listCacheSet.js
function listCacheSet(key, value) {
  var data = this.__data__, index = assocIndexOf_default(data, key);
  if (index < 0) {
    ++this.size;
    data.push([key, value]);
  } else {
    data[index][1] = value;
  }
  return this;
}
var listCacheSet_default = listCacheSet;

// node_modules/lodash-es/_ListCache.js
function ListCache(entries) {
  var index = -1, length = entries == null ? 0 : entries.length;
  this.clear();
  while (++index < length) {
    var entry = entries[index];
    this.set(entry[0], entry[1]);
  }
}
ListCache.prototype.clear = listCacheClear_default;
ListCache.prototype["delete"] = listCacheDelete_default;
ListCache.prototype.get = listCacheGet_default;
ListCache.prototype.has = listCacheHas_default;
ListCache.prototype.set = listCacheSet_default;
var ListCache_default = ListCache;

// node_modules/lodash-es/_stackClear.js
function stackClear() {
  this.__data__ = new ListCache_default();
  this.size = 0;
}
var stackClear_default = stackClear;

// node_modules/lodash-es/_stackDelete.js
function stackDelete(key) {
  var data = this.__data__, result = data["delete"](key);
  this.size = data.size;
  return result;
}
var stackDelete_default = stackDelete;

// node_modules/lodash-es/_stackGet.js
function stackGet(key) {
  return this.__data__.get(key);
}
var stackGet_default = stackGet;

// node_modules/lodash-es/_stackHas.js
function stackHas(key) {
  return this.__data__.has(key);
}
var stackHas_default = stackHas;

// node_modules/lodash-es/_freeGlobal.js
var freeGlobal = typeof global == "object" && global && global.Object === Object && global;
var freeGlobal_default = freeGlobal;

// node_modules/lodash-es/_root.js
var freeSelf = typeof self == "object" && self && self.Object === Object && self;
var root = freeGlobal_default || freeSelf || Function("return this")();
var root_default = root;

// node_modules/lodash-es/_Symbol.js
var Symbol2 = root_default.Symbol;
var Symbol_default = Symbol2;

// node_modules/lodash-es/_getRawTag.js
var objectProto = Object.prototype;
var hasOwnProperty = objectProto.hasOwnProperty;
var nativeObjectToString = objectProto.toString;
var symToStringTag = Symbol_default ? Symbol_default.toStringTag : void 0;
function getRawTag(value) {
  var isOwn = hasOwnProperty.call(value, symToStringTag), tag = value[symToStringTag];
  try {
    value[symToStringTag] = void 0;
    var unmasked = true;
  } catch (e9) {
  }
  var result = nativeObjectToString.call(value);
  if (unmasked) {
    if (isOwn) {
      value[symToStringTag] = tag;
    } else {
      delete value[symToStringTag];
    }
  }
  return result;
}
var getRawTag_default = getRawTag;

// node_modules/lodash-es/_objectToString.js
var objectProto2 = Object.prototype;
var nativeObjectToString2 = objectProto2.toString;
function objectToString(value) {
  return nativeObjectToString2.call(value);
}
var objectToString_default = objectToString;

// node_modules/lodash-es/_baseGetTag.js
var nullTag = "[object Null]";
var undefinedTag = "[object Undefined]";
var symToStringTag2 = Symbol_default ? Symbol_default.toStringTag : void 0;
function baseGetTag(value) {
  if (value == null) {
    return value === void 0 ? undefinedTag : nullTag;
  }
  return symToStringTag2 && symToStringTag2 in Object(value) ? getRawTag_default(value) : objectToString_default(value);
}
var baseGetTag_default = baseGetTag;

// node_modules/lodash-es/isObject.js
function isObject(value) {
  var type = typeof value;
  return value != null && (type == "object" || type == "function");
}
var isObject_default = isObject;

// node_modules/lodash-es/isFunction.js
var asyncTag = "[object AsyncFunction]";
var funcTag = "[object Function]";
var genTag = "[object GeneratorFunction]";
var proxyTag = "[object Proxy]";
function isFunction(value) {
  if (!isObject_default(value)) {
    return false;
  }
  var tag = baseGetTag_default(value);
  return tag == funcTag || tag == genTag || tag == asyncTag || tag == proxyTag;
}
var isFunction_default = isFunction;

// node_modules/lodash-es/_coreJsData.js
var coreJsData = root_default["__core-js_shared__"];
var coreJsData_default = coreJsData;

// node_modules/lodash-es/_isMasked.js
var maskSrcKey = function() {
  var uid = /[^.]+$/.exec(coreJsData_default && coreJsData_default.keys && coreJsData_default.keys.IE_PROTO || "");
  return uid ? "Symbol(src)_1." + uid : "";
}();
function isMasked(func) {
  return !!maskSrcKey && maskSrcKey in func;
}
var isMasked_default = isMasked;

// node_modules/lodash-es/_toSource.js
var funcProto = Function.prototype;
var funcToString = funcProto.toString;
function toSource(func) {
  if (func != null) {
    try {
      return funcToString.call(func);
    } catch (e9) {
    }
    try {
      return func + "";
    } catch (e9) {
    }
  }
  return "";
}
var toSource_default = toSource;

// node_modules/lodash-es/_baseIsNative.js
var reRegExpChar = /[\\^$.*+?()[\]{}|]/g;
var reIsHostCtor = /^\[object .+?Constructor\]$/;
var funcProto2 = Function.prototype;
var objectProto3 = Object.prototype;
var funcToString2 = funcProto2.toString;
var hasOwnProperty2 = objectProto3.hasOwnProperty;
var reIsNative = RegExp(
  "^" + funcToString2.call(hasOwnProperty2).replace(reRegExpChar, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$"
);
function baseIsNative(value) {
  if (!isObject_default(value) || isMasked_default(value)) {
    return false;
  }
  var pattern = isFunction_default(value) ? reIsNative : reIsHostCtor;
  return pattern.test(toSource_default(value));
}
var baseIsNative_default = baseIsNative;

// node_modules/lodash-es/_getValue.js
function getValue(object, key) {
  return object == null ? void 0 : object[key];
}
var getValue_default = getValue;

// node_modules/lodash-es/_getNative.js
function getNative(object, key) {
  var value = getValue_default(object, key);
  return baseIsNative_default(value) ? value : void 0;
}
var getNative_default = getNative;

// node_modules/lodash-es/_Map.js
var Map2 = getNative_default(root_default, "Map");
var Map_default = Map2;

// node_modules/lodash-es/_nativeCreate.js
var nativeCreate = getNative_default(Object, "create");
var nativeCreate_default = nativeCreate;

// node_modules/lodash-es/_hashClear.js
function hashClear() {
  this.__data__ = nativeCreate_default ? nativeCreate_default(null) : {};
  this.size = 0;
}
var hashClear_default = hashClear;

// node_modules/lodash-es/_hashDelete.js
function hashDelete(key) {
  var result = this.has(key) && delete this.__data__[key];
  this.size -= result ? 1 : 0;
  return result;
}
var hashDelete_default = hashDelete;

// node_modules/lodash-es/_hashGet.js
var HASH_UNDEFINED = "__lodash_hash_undefined__";
var objectProto4 = Object.prototype;
var hasOwnProperty3 = objectProto4.hasOwnProperty;
function hashGet(key) {
  var data = this.__data__;
  if (nativeCreate_default) {
    var result = data[key];
    return result === HASH_UNDEFINED ? void 0 : result;
  }
  return hasOwnProperty3.call(data, key) ? data[key] : void 0;
}
var hashGet_default = hashGet;

// node_modules/lodash-es/_hashHas.js
var objectProto5 = Object.prototype;
var hasOwnProperty4 = objectProto5.hasOwnProperty;
function hashHas(key) {
  var data = this.__data__;
  return nativeCreate_default ? data[key] !== void 0 : hasOwnProperty4.call(data, key);
}
var hashHas_default = hashHas;

// node_modules/lodash-es/_hashSet.js
var HASH_UNDEFINED2 = "__lodash_hash_undefined__";
function hashSet(key, value) {
  var data = this.__data__;
  this.size += this.has(key) ? 0 : 1;
  data[key] = nativeCreate_default && value === void 0 ? HASH_UNDEFINED2 : value;
  return this;
}
var hashSet_default = hashSet;

// node_modules/lodash-es/_Hash.js
function Hash(entries) {
  var index = -1, length = entries == null ? 0 : entries.length;
  this.clear();
  while (++index < length) {
    var entry = entries[index];
    this.set(entry[0], entry[1]);
  }
}
Hash.prototype.clear = hashClear_default;
Hash.prototype["delete"] = hashDelete_default;
Hash.prototype.get = hashGet_default;
Hash.prototype.has = hashHas_default;
Hash.prototype.set = hashSet_default;
var Hash_default = Hash;

// node_modules/lodash-es/_mapCacheClear.js
function mapCacheClear() {
  this.size = 0;
  this.__data__ = {
    "hash": new Hash_default(),
    "map": new (Map_default || ListCache_default)(),
    "string": new Hash_default()
  };
}
var mapCacheClear_default = mapCacheClear;

// node_modules/lodash-es/_isKeyable.js
function isKeyable(value) {
  var type = typeof value;
  return type == "string" || type == "number" || type == "symbol" || type == "boolean" ? value !== "__proto__" : value === null;
}
var isKeyable_default = isKeyable;

// node_modules/lodash-es/_getMapData.js
function getMapData(map2, key) {
  var data = map2.__data__;
  return isKeyable_default(key) ? data[typeof key == "string" ? "string" : "hash"] : data.map;
}
var getMapData_default = getMapData;

// node_modules/lodash-es/_mapCacheDelete.js
function mapCacheDelete(key) {
  var result = getMapData_default(this, key)["delete"](key);
  this.size -= result ? 1 : 0;
  return result;
}
var mapCacheDelete_default = mapCacheDelete;

// node_modules/lodash-es/_mapCacheGet.js
function mapCacheGet(key) {
  return getMapData_default(this, key).get(key);
}
var mapCacheGet_default = mapCacheGet;

// node_modules/lodash-es/_mapCacheHas.js
function mapCacheHas(key) {
  return getMapData_default(this, key).has(key);
}
var mapCacheHas_default = mapCacheHas;

// node_modules/lodash-es/_mapCacheSet.js
function mapCacheSet(key, value) {
  var data = getMapData_default(this, key), size = data.size;
  data.set(key, value);
  this.size += data.size == size ? 0 : 1;
  return this;
}
var mapCacheSet_default = mapCacheSet;

// node_modules/lodash-es/_MapCache.js
function MapCache(entries) {
  var index = -1, length = entries == null ? 0 : entries.length;
  this.clear();
  while (++index < length) {
    var entry = entries[index];
    this.set(entry[0], entry[1]);
  }
}
MapCache.prototype.clear = mapCacheClear_default;
MapCache.prototype["delete"] = mapCacheDelete_default;
MapCache.prototype.get = mapCacheGet_default;
MapCache.prototype.has = mapCacheHas_default;
MapCache.prototype.set = mapCacheSet_default;
var MapCache_default = MapCache;

// node_modules/lodash-es/_stackSet.js
var LARGE_ARRAY_SIZE = 200;
function stackSet(key, value) {
  var data = this.__data__;
  if (data instanceof ListCache_default) {
    var pairs = data.__data__;
    if (!Map_default || pairs.length < LARGE_ARRAY_SIZE - 1) {
      pairs.push([key, value]);
      this.size = ++data.size;
      return this;
    }
    data = this.__data__ = new MapCache_default(pairs);
  }
  data.set(key, value);
  this.size = data.size;
  return this;
}
var stackSet_default = stackSet;

// node_modules/lodash-es/_Stack.js
function Stack(entries) {
  var data = this.__data__ = new ListCache_default(entries);
  this.size = data.size;
}
Stack.prototype.clear = stackClear_default;
Stack.prototype["delete"] = stackDelete_default;
Stack.prototype.get = stackGet_default;
Stack.prototype.has = stackHas_default;
Stack.prototype.set = stackSet_default;
var Stack_default = Stack;

// node_modules/lodash-es/_defineProperty.js
var defineProperty = function() {
  try {
    var func = getNative_default(Object, "defineProperty");
    func({}, "", {});
    return func;
  } catch (e9) {
  }
}();
var defineProperty_default = defineProperty;

// node_modules/lodash-es/_baseAssignValue.js
function baseAssignValue(object, key, value) {
  if (key == "__proto__" && defineProperty_default) {
    defineProperty_default(object, key, {
      "configurable": true,
      "enumerable": true,
      "value": value,
      "writable": true
    });
  } else {
    object[key] = value;
  }
}
var baseAssignValue_default = baseAssignValue;

// node_modules/lodash-es/_assignMergeValue.js
function assignMergeValue(object, key, value) {
  if (value !== void 0 && !eq_default(object[key], value) || value === void 0 && !(key in object)) {
    baseAssignValue_default(object, key, value);
  }
}
var assignMergeValue_default = assignMergeValue;

// node_modules/lodash-es/_createBaseFor.js
function createBaseFor(fromRight) {
  return function(object, iteratee, keysFunc) {
    var index = -1, iterable = Object(object), props = keysFunc(object), length = props.length;
    while (length--) {
      var key = props[fromRight ? length : ++index];
      if (iteratee(iterable[key], key, iterable) === false) {
        break;
      }
    }
    return object;
  };
}
var createBaseFor_default = createBaseFor;

// node_modules/lodash-es/_baseFor.js
var baseFor = createBaseFor_default();
var baseFor_default = baseFor;

// node_modules/lodash-es/_cloneBuffer.js
var freeExports = typeof exports == "object" && exports && !exports.nodeType && exports;
var freeModule = freeExports && typeof module == "object" && module && !module.nodeType && module;
var moduleExports = freeModule && freeModule.exports === freeExports;
var Buffer2 = moduleExports ? root_default.Buffer : void 0;
var allocUnsafe = Buffer2 ? Buffer2.allocUnsafe : void 0;
function cloneBuffer(buffer, isDeep) {
  if (isDeep) {
    return buffer.slice();
  }
  var length = buffer.length, result = allocUnsafe ? allocUnsafe(length) : new buffer.constructor(length);
  buffer.copy(result);
  return result;
}
var cloneBuffer_default = cloneBuffer;

// node_modules/lodash-es/_Uint8Array.js
var Uint8Array2 = root_default.Uint8Array;
var Uint8Array_default = Uint8Array2;

// node_modules/lodash-es/_cloneArrayBuffer.js
function cloneArrayBuffer(arrayBuffer) {
  var result = new arrayBuffer.constructor(arrayBuffer.byteLength);
  new Uint8Array_default(result).set(new Uint8Array_default(arrayBuffer));
  return result;
}
var cloneArrayBuffer_default = cloneArrayBuffer;

// node_modules/lodash-es/_cloneTypedArray.js
function cloneTypedArray(typedArray, isDeep) {
  var buffer = isDeep ? cloneArrayBuffer_default(typedArray.buffer) : typedArray.buffer;
  return new typedArray.constructor(buffer, typedArray.byteOffset, typedArray.length);
}
var cloneTypedArray_default = cloneTypedArray;

// node_modules/lodash-es/_copyArray.js
function copyArray(source, array) {
  var index = -1, length = source.length;
  array || (array = Array(length));
  while (++index < length) {
    array[index] = source[index];
  }
  return array;
}
var copyArray_default = copyArray;

// node_modules/lodash-es/_baseCreate.js
var objectCreate = Object.create;
var baseCreate = function() {
  function object() {
  }
  return function(proto) {
    if (!isObject_default(proto)) {
      return {};
    }
    if (objectCreate) {
      return objectCreate(proto);
    }
    object.prototype = proto;
    var result = new object();
    object.prototype = void 0;
    return result;
  };
}();
var baseCreate_default = baseCreate;

// node_modules/lodash-es/_overArg.js
function overArg(func, transform) {
  return function(arg) {
    return func(transform(arg));
  };
}
var overArg_default = overArg;

// node_modules/lodash-es/_getPrototype.js
var getPrototype = overArg_default(Object.getPrototypeOf, Object);
var getPrototype_default = getPrototype;

// node_modules/lodash-es/_isPrototype.js
var objectProto6 = Object.prototype;
function isPrototype(value) {
  var Ctor = value && value.constructor, proto = typeof Ctor == "function" && Ctor.prototype || objectProto6;
  return value === proto;
}
var isPrototype_default = isPrototype;

// node_modules/lodash-es/_initCloneObject.js
function initCloneObject(object) {
  return typeof object.constructor == "function" && !isPrototype_default(object) ? baseCreate_default(getPrototype_default(object)) : {};
}
var initCloneObject_default = initCloneObject;

// node_modules/lodash-es/isObjectLike.js
function isObjectLike(value) {
  return value != null && typeof value == "object";
}
var isObjectLike_default = isObjectLike;

// node_modules/lodash-es/_baseIsArguments.js
var argsTag = "[object Arguments]";
function baseIsArguments(value) {
  return isObjectLike_default(value) && baseGetTag_default(value) == argsTag;
}
var baseIsArguments_default = baseIsArguments;

// node_modules/lodash-es/isArguments.js
var objectProto7 = Object.prototype;
var hasOwnProperty5 = objectProto7.hasOwnProperty;
var propertyIsEnumerable = objectProto7.propertyIsEnumerable;
var isArguments = baseIsArguments_default(function() {
  return arguments;
}()) ? baseIsArguments_default : function(value) {
  return isObjectLike_default(value) && hasOwnProperty5.call(value, "callee") && !propertyIsEnumerable.call(value, "callee");
};
var isArguments_default = isArguments;

// node_modules/lodash-es/isArray.js
var isArray = Array.isArray;
var isArray_default = isArray;

// node_modules/lodash-es/isLength.js
var MAX_SAFE_INTEGER = 9007199254740991;
function isLength(value) {
  return typeof value == "number" && value > -1 && value % 1 == 0 && value <= MAX_SAFE_INTEGER;
}
var isLength_default = isLength;

// node_modules/lodash-es/isArrayLike.js
function isArrayLike(value) {
  return value != null && isLength_default(value.length) && !isFunction_default(value);
}
var isArrayLike_default = isArrayLike;

// node_modules/lodash-es/isArrayLikeObject.js
function isArrayLikeObject(value) {
  return isObjectLike_default(value) && isArrayLike_default(value);
}
var isArrayLikeObject_default = isArrayLikeObject;

// node_modules/lodash-es/stubFalse.js
function stubFalse() {
  return false;
}
var stubFalse_default = stubFalse;

// node_modules/lodash-es/isBuffer.js
var freeExports2 = typeof exports == "object" && exports && !exports.nodeType && exports;
var freeModule2 = freeExports2 && typeof module == "object" && module && !module.nodeType && module;
var moduleExports2 = freeModule2 && freeModule2.exports === freeExports2;
var Buffer3 = moduleExports2 ? root_default.Buffer : void 0;
var nativeIsBuffer = Buffer3 ? Buffer3.isBuffer : void 0;
var isBuffer = nativeIsBuffer || stubFalse_default;
var isBuffer_default = isBuffer;

// node_modules/lodash-es/isPlainObject.js
var objectTag = "[object Object]";
var funcProto3 = Function.prototype;
var objectProto8 = Object.prototype;
var funcToString3 = funcProto3.toString;
var hasOwnProperty6 = objectProto8.hasOwnProperty;
var objectCtorString = funcToString3.call(Object);
function isPlainObject(value) {
  if (!isObjectLike_default(value) || baseGetTag_default(value) != objectTag) {
    return false;
  }
  var proto = getPrototype_default(value);
  if (proto === null) {
    return true;
  }
  var Ctor = hasOwnProperty6.call(proto, "constructor") && proto.constructor;
  return typeof Ctor == "function" && Ctor instanceof Ctor && funcToString3.call(Ctor) == objectCtorString;
}
var isPlainObject_default = isPlainObject;

// node_modules/lodash-es/_baseIsTypedArray.js
var argsTag2 = "[object Arguments]";
var arrayTag = "[object Array]";
var boolTag = "[object Boolean]";
var dateTag = "[object Date]";
var errorTag = "[object Error]";
var funcTag2 = "[object Function]";
var mapTag = "[object Map]";
var numberTag = "[object Number]";
var objectTag2 = "[object Object]";
var regexpTag = "[object RegExp]";
var setTag = "[object Set]";
var stringTag = "[object String]";
var weakMapTag = "[object WeakMap]";
var arrayBufferTag = "[object ArrayBuffer]";
var dataViewTag = "[object DataView]";
var float32Tag = "[object Float32Array]";
var float64Tag = "[object Float64Array]";
var int8Tag = "[object Int8Array]";
var int16Tag = "[object Int16Array]";
var int32Tag = "[object Int32Array]";
var uint8Tag = "[object Uint8Array]";
var uint8ClampedTag = "[object Uint8ClampedArray]";
var uint16Tag = "[object Uint16Array]";
var uint32Tag = "[object Uint32Array]";
var typedArrayTags = {};
typedArrayTags[float32Tag] = typedArrayTags[float64Tag] = typedArrayTags[int8Tag] = typedArrayTags[int16Tag] = typedArrayTags[int32Tag] = typedArrayTags[uint8Tag] = typedArrayTags[uint8ClampedTag] = typedArrayTags[uint16Tag] = typedArrayTags[uint32Tag] = true;
typedArrayTags[argsTag2] = typedArrayTags[arrayTag] = typedArrayTags[arrayBufferTag] = typedArrayTags[boolTag] = typedArrayTags[dataViewTag] = typedArrayTags[dateTag] = typedArrayTags[errorTag] = typedArrayTags[funcTag2] = typedArrayTags[mapTag] = typedArrayTags[numberTag] = typedArrayTags[objectTag2] = typedArrayTags[regexpTag] = typedArrayTags[setTag] = typedArrayTags[stringTag] = typedArrayTags[weakMapTag] = false;
function baseIsTypedArray(value) {
  return isObjectLike_default(value) && isLength_default(value.length) && !!typedArrayTags[baseGetTag_default(value)];
}
var baseIsTypedArray_default = baseIsTypedArray;

// node_modules/lodash-es/_baseUnary.js
function baseUnary(func) {
  return function(value) {
    return func(value);
  };
}
var baseUnary_default = baseUnary;

// node_modules/lodash-es/_nodeUtil.js
var freeExports3 = typeof exports == "object" && exports && !exports.nodeType && exports;
var freeModule3 = freeExports3 && typeof module == "object" && module && !module.nodeType && module;
var moduleExports3 = freeModule3 && freeModule3.exports === freeExports3;
var freeProcess = moduleExports3 && freeGlobal_default.process;
var nodeUtil = function() {
  try {
    var types = freeModule3 && freeModule3.require && freeModule3.require("util").types;
    if (types) {
      return types;
    }
    return freeProcess && freeProcess.binding && freeProcess.binding("util");
  } catch (e9) {
  }
}();
var nodeUtil_default = nodeUtil;

// node_modules/lodash-es/isTypedArray.js
var nodeIsTypedArray = nodeUtil_default && nodeUtil_default.isTypedArray;
var isTypedArray = nodeIsTypedArray ? baseUnary_default(nodeIsTypedArray) : baseIsTypedArray_default;
var isTypedArray_default = isTypedArray;

// node_modules/lodash-es/_safeGet.js
function safeGet(object, key) {
  if (key === "constructor" && typeof object[key] === "function") {
    return;
  }
  if (key == "__proto__") {
    return;
  }
  return object[key];
}
var safeGet_default = safeGet;

// node_modules/lodash-es/_assignValue.js
var objectProto9 = Object.prototype;
var hasOwnProperty7 = objectProto9.hasOwnProperty;
function assignValue(object, key, value) {
  var objValue = object[key];
  if (!(hasOwnProperty7.call(object, key) && eq_default(objValue, value)) || value === void 0 && !(key in object)) {
    baseAssignValue_default(object, key, value);
  }
}
var assignValue_default = assignValue;

// node_modules/lodash-es/_copyObject.js
function copyObject(source, props, object, customizer) {
  var isNew = !object;
  object || (object = {});
  var index = -1, length = props.length;
  while (++index < length) {
    var key = props[index];
    var newValue = customizer ? customizer(object[key], source[key], key, object, source) : void 0;
    if (newValue === void 0) {
      newValue = source[key];
    }
    if (isNew) {
      baseAssignValue_default(object, key, newValue);
    } else {
      assignValue_default(object, key, newValue);
    }
  }
  return object;
}
var copyObject_default = copyObject;

// node_modules/lodash-es/_baseTimes.js
function baseTimes(n8, iteratee) {
  var index = -1, result = Array(n8);
  while (++index < n8) {
    result[index] = iteratee(index);
  }
  return result;
}
var baseTimes_default = baseTimes;

// node_modules/lodash-es/_isIndex.js
var MAX_SAFE_INTEGER2 = 9007199254740991;
var reIsUint = /^(?:0|[1-9]\d*)$/;
function isIndex(value, length) {
  var type = typeof value;
  length = length == null ? MAX_SAFE_INTEGER2 : length;
  return !!length && (type == "number" || type != "symbol" && reIsUint.test(value)) && (value > -1 && value % 1 == 0 && value < length);
}
var isIndex_default = isIndex;

// node_modules/lodash-es/_arrayLikeKeys.js
var objectProto10 = Object.prototype;
var hasOwnProperty8 = objectProto10.hasOwnProperty;
function arrayLikeKeys(value, inherited) {
  var isArr = isArray_default(value), isArg = !isArr && isArguments_default(value), isBuff = !isArr && !isArg && isBuffer_default(value), isType = !isArr && !isArg && !isBuff && isTypedArray_default(value), skipIndexes = isArr || isArg || isBuff || isType, result = skipIndexes ? baseTimes_default(value.length, String) : [], length = result.length;
  for (var key in value) {
    if ((inherited || hasOwnProperty8.call(value, key)) && !(skipIndexes && // Safari 9 has enumerable `arguments.length` in strict mode.
    (key == "length" || // Node.js 0.10 has enumerable non-index properties on buffers.
    isBuff && (key == "offset" || key == "parent") || // PhantomJS 2 has enumerable non-index properties on typed arrays.
    isType && (key == "buffer" || key == "byteLength" || key == "byteOffset") || // Skip index properties.
    isIndex_default(key, length)))) {
      result.push(key);
    }
  }
  return result;
}
var arrayLikeKeys_default = arrayLikeKeys;

// node_modules/lodash-es/_nativeKeysIn.js
function nativeKeysIn(object) {
  var result = [];
  if (object != null) {
    for (var key in Object(object)) {
      result.push(key);
    }
  }
  return result;
}
var nativeKeysIn_default = nativeKeysIn;

// node_modules/lodash-es/_baseKeysIn.js
var objectProto11 = Object.prototype;
var hasOwnProperty9 = objectProto11.hasOwnProperty;
function baseKeysIn(object) {
  if (!isObject_default(object)) {
    return nativeKeysIn_default(object);
  }
  var isProto = isPrototype_default(object), result = [];
  for (var key in object) {
    if (!(key == "constructor" && (isProto || !hasOwnProperty9.call(object, key)))) {
      result.push(key);
    }
  }
  return result;
}
var baseKeysIn_default = baseKeysIn;

// node_modules/lodash-es/keysIn.js
function keysIn(object) {
  return isArrayLike_default(object) ? arrayLikeKeys_default(object, true) : baseKeysIn_default(object);
}
var keysIn_default = keysIn;

// node_modules/lodash-es/toPlainObject.js
function toPlainObject(value) {
  return copyObject_default(value, keysIn_default(value));
}
var toPlainObject_default = toPlainObject;

// node_modules/lodash-es/_baseMergeDeep.js
function baseMergeDeep(object, source, key, srcIndex, mergeFunc, customizer, stack) {
  var objValue = safeGet_default(object, key), srcValue = safeGet_default(source, key), stacked = stack.get(srcValue);
  if (stacked) {
    assignMergeValue_default(object, key, stacked);
    return;
  }
  var newValue = customizer ? customizer(objValue, srcValue, key + "", object, source, stack) : void 0;
  var isCommon = newValue === void 0;
  if (isCommon) {
    var isArr = isArray_default(srcValue), isBuff = !isArr && isBuffer_default(srcValue), isTyped = !isArr && !isBuff && isTypedArray_default(srcValue);
    newValue = srcValue;
    if (isArr || isBuff || isTyped) {
      if (isArray_default(objValue)) {
        newValue = objValue;
      } else if (isArrayLikeObject_default(objValue)) {
        newValue = copyArray_default(objValue);
      } else if (isBuff) {
        isCommon = false;
        newValue = cloneBuffer_default(srcValue, true);
      } else if (isTyped) {
        isCommon = false;
        newValue = cloneTypedArray_default(srcValue, true);
      } else {
        newValue = [];
      }
    } else if (isPlainObject_default(srcValue) || isArguments_default(srcValue)) {
      newValue = objValue;
      if (isArguments_default(objValue)) {
        newValue = toPlainObject_default(objValue);
      } else if (!isObject_default(objValue) || isFunction_default(objValue)) {
        newValue = initCloneObject_default(srcValue);
      }
    } else {
      isCommon = false;
    }
  }
  if (isCommon) {
    stack.set(srcValue, newValue);
    mergeFunc(newValue, srcValue, srcIndex, customizer, stack);
    stack["delete"](srcValue);
  }
  assignMergeValue_default(object, key, newValue);
}
var baseMergeDeep_default = baseMergeDeep;

// node_modules/lodash-es/_baseMerge.js
function baseMerge(object, source, srcIndex, customizer, stack) {
  if (object === source) {
    return;
  }
  baseFor_default(source, function(srcValue, key) {
    stack || (stack = new Stack_default());
    if (isObject_default(srcValue)) {
      baseMergeDeep_default(object, source, key, srcIndex, baseMerge, customizer, stack);
    } else {
      var newValue = customizer ? customizer(safeGet_default(object, key), srcValue, key + "", object, source, stack) : void 0;
      if (newValue === void 0) {
        newValue = srcValue;
      }
      assignMergeValue_default(object, key, newValue);
    }
  }, keysIn_default);
}
var baseMerge_default = baseMerge;

// node_modules/lodash-es/identity.js
function identity(value) {
  return value;
}
var identity_default = identity;

// node_modules/lodash-es/_apply.js
function apply(func, thisArg, args) {
  switch (args.length) {
    case 0:
      return func.call(thisArg);
    case 1:
      return func.call(thisArg, args[0]);
    case 2:
      return func.call(thisArg, args[0], args[1]);
    case 3:
      return func.call(thisArg, args[0], args[1], args[2]);
  }
  return func.apply(thisArg, args);
}
var apply_default = apply;

// node_modules/lodash-es/_overRest.js
var nativeMax = Math.max;
function overRest(func, start, transform) {
  start = nativeMax(start === void 0 ? func.length - 1 : start, 0);
  return function() {
    var args = arguments, index = -1, length = nativeMax(args.length - start, 0), array = Array(length);
    while (++index < length) {
      array[index] = args[start + index];
    }
    index = -1;
    var otherArgs = Array(start + 1);
    while (++index < start) {
      otherArgs[index] = args[index];
    }
    otherArgs[start] = transform(array);
    return apply_default(func, this, otherArgs);
  };
}
var overRest_default = overRest;

// node_modules/lodash-es/constant.js
function constant(value) {
  return function() {
    return value;
  };
}
var constant_default = constant;

// node_modules/lodash-es/_baseSetToString.js
var baseSetToString = !defineProperty_default ? identity_default : function(func, string) {
  return defineProperty_default(func, "toString", {
    "configurable": true,
    "enumerable": false,
    "value": constant_default(string),
    "writable": true
  });
};
var baseSetToString_default = baseSetToString;

// node_modules/lodash-es/_shortOut.js
var HOT_COUNT = 800;
var HOT_SPAN = 16;
var nativeNow = Date.now;
function shortOut(func) {
  var count = 0, lastCalled = 0;
  return function() {
    var stamp = nativeNow(), remaining = HOT_SPAN - (stamp - lastCalled);
    lastCalled = stamp;
    if (remaining > 0) {
      if (++count >= HOT_COUNT) {
        return arguments[0];
      }
    } else {
      count = 0;
    }
    return func.apply(void 0, arguments);
  };
}
var shortOut_default = shortOut;

// node_modules/lodash-es/_setToString.js
var setToString = shortOut_default(baseSetToString_default);
var setToString_default = setToString;

// node_modules/lodash-es/_baseRest.js
function baseRest(func, start) {
  return setToString_default(overRest_default(func, start, identity_default), func + "");
}
var baseRest_default = baseRest;

// node_modules/lodash-es/_isIterateeCall.js
function isIterateeCall(value, index, object) {
  if (!isObject_default(object)) {
    return false;
  }
  var type = typeof index;
  if (type == "number" ? isArrayLike_default(object) && isIndex_default(index, object.length) : type == "string" && index in object) {
    return eq_default(object[index], value);
  }
  return false;
}
var isIterateeCall_default = isIterateeCall;

// node_modules/lodash-es/_createAssigner.js
function createAssigner(assigner) {
  return baseRest_default(function(object, sources) {
    var index = -1, length = sources.length, customizer = length > 1 ? sources[length - 1] : void 0, guard = length > 2 ? sources[2] : void 0;
    customizer = assigner.length > 3 && typeof customizer == "function" ? (length--, customizer) : void 0;
    if (guard && isIterateeCall_default(sources[0], sources[1], guard)) {
      customizer = length < 3 ? void 0 : customizer;
      length = 1;
    }
    object = Object(object);
    while (++index < length) {
      var source = sources[index];
      if (source) {
        assigner(object, source, index, customizer);
      }
    }
    return object;
  });
}
var createAssigner_default = createAssigner;

// node_modules/lodash-es/merge.js
var merge = createAssigner_default(function(object, source, srcIndex) {
  baseMerge_default(object, source, srcIndex);
});
var merge_default = merge;

// node_modules/react-color/es/components/common/Raised.js
var Raised = function Raised2(_ref) {
  var zDepth = _ref.zDepth, radius = _ref.radius, background = _ref.background, children = _ref.children, _ref$styles = _ref.styles, passedStyles = _ref$styles === void 0 ? {} : _ref$styles;
  var styles = (0, import_reactcss5.default)(merge_default({
    "default": {
      wrap: {
        position: "relative",
        display: "inline-block"
      },
      content: {
        position: "relative"
      },
      bg: {
        absolute: "0px 0px 0px 0px",
        boxShadow: "0 " + zDepth + "px " + zDepth * 4 + "px rgba(0,0,0,.24)",
        borderRadius: radius,
        background
      }
    },
    "zDepth-0": {
      bg: {
        boxShadow: "none"
      }
    },
    "zDepth-1": {
      bg: {
        boxShadow: "0 2px 10px rgba(0,0,0,.12), 0 2px 5px rgba(0,0,0,.16)"
      }
    },
    "zDepth-2": {
      bg: {
        boxShadow: "0 6px 20px rgba(0,0,0,.19), 0 8px 17px rgba(0,0,0,.2)"
      }
    },
    "zDepth-3": {
      bg: {
        boxShadow: "0 17px 50px rgba(0,0,0,.19), 0 12px 15px rgba(0,0,0,.24)"
      }
    },
    "zDepth-4": {
      bg: {
        boxShadow: "0 25px 55px rgba(0,0,0,.21), 0 16px 28px rgba(0,0,0,.22)"
      }
    },
    "zDepth-5": {
      bg: {
        boxShadow: "0 40px 77px rgba(0,0,0,.22), 0 27px 24px rgba(0,0,0,.2)"
      }
    },
    "square": {
      bg: {
        borderRadius: "0"
      }
    },
    "circle": {
      bg: {
        borderRadius: "50%"
      }
    }
  }, passedStyles), { "zDepth-1": zDepth === 1 });
  return Cn.createElement(
    "div",
    { style: styles.wrap },
    Cn.createElement("div", { style: styles.bg }),
    Cn.createElement(
      "div",
      { style: styles.content },
      children
    )
  );
};
Raised.propTypes = {
  background: import_prop_types.default.string,
  zDepth: import_prop_types.default.oneOf([0, 1, 2, 3, 4, 5]),
  radius: import_prop_types.default.number,
  styles: import_prop_types.default.object
};
Raised.defaultProps = {
  background: "#fff",
  zDepth: 1,
  radius: 2,
  styles: {}
};
var Raised_default = Raised;

// node_modules/react-color/es/components/common/Saturation.js
init_react();
var import_reactcss6 = __toESM(require_lib());

// node_modules/lodash-es/now.js
var now = function() {
  return root_default.Date.now();
};
var now_default = now;

// node_modules/lodash-es/_trimmedEndIndex.js
var reWhitespace = /\s/;
function trimmedEndIndex(string) {
  var index = string.length;
  while (index-- && reWhitespace.test(string.charAt(index))) {
  }
  return index;
}
var trimmedEndIndex_default = trimmedEndIndex;

// node_modules/lodash-es/_baseTrim.js
var reTrimStart = /^\s+/;
function baseTrim(string) {
  return string ? string.slice(0, trimmedEndIndex_default(string) + 1).replace(reTrimStart, "") : string;
}
var baseTrim_default = baseTrim;

// node_modules/lodash-es/isSymbol.js
var symbolTag = "[object Symbol]";
function isSymbol(value) {
  return typeof value == "symbol" || isObjectLike_default(value) && baseGetTag_default(value) == symbolTag;
}
var isSymbol_default = isSymbol;

// node_modules/lodash-es/toNumber.js
var NAN = 0 / 0;
var reIsBadHex = /^[-+]0x[0-9a-f]+$/i;
var reIsBinary = /^0b[01]+$/i;
var reIsOctal = /^0o[0-7]+$/i;
var freeParseInt = parseInt;
function toNumber(value) {
  if (typeof value == "number") {
    return value;
  }
  if (isSymbol_default(value)) {
    return NAN;
  }
  if (isObject_default(value)) {
    var other = typeof value.valueOf == "function" ? value.valueOf() : value;
    value = isObject_default(other) ? other + "" : other;
  }
  if (typeof value != "string") {
    return value === 0 ? value : +value;
  }
  value = baseTrim_default(value);
  var isBinary = reIsBinary.test(value);
  return isBinary || reIsOctal.test(value) ? freeParseInt(value.slice(2), isBinary ? 2 : 8) : reIsBadHex.test(value) ? NAN : +value;
}
var toNumber_default = toNumber;

// node_modules/lodash-es/debounce.js
var FUNC_ERROR_TEXT = "Expected a function";
var nativeMax2 = Math.max;
var nativeMin = Math.min;
function debounce(func, wait, options) {
  var lastArgs, lastThis, maxWait, result, timerId, lastCallTime, lastInvokeTime = 0, leading = false, maxing = false, trailing = true;
  if (typeof func != "function") {
    throw new TypeError(FUNC_ERROR_TEXT);
  }
  wait = toNumber_default(wait) || 0;
  if (isObject_default(options)) {
    leading = !!options.leading;
    maxing = "maxWait" in options;
    maxWait = maxing ? nativeMax2(toNumber_default(options.maxWait) || 0, wait) : maxWait;
    trailing = "trailing" in options ? !!options.trailing : trailing;
  }
  function invokeFunc(time) {
    var args = lastArgs, thisArg = lastThis;
    lastArgs = lastThis = void 0;
    lastInvokeTime = time;
    result = func.apply(thisArg, args);
    return result;
  }
  function leadingEdge(time) {
    lastInvokeTime = time;
    timerId = setTimeout(timerExpired, wait);
    return leading ? invokeFunc(time) : result;
  }
  function remainingWait(time) {
    var timeSinceLastCall = time - lastCallTime, timeSinceLastInvoke = time - lastInvokeTime, timeWaiting = wait - timeSinceLastCall;
    return maxing ? nativeMin(timeWaiting, maxWait - timeSinceLastInvoke) : timeWaiting;
  }
  function shouldInvoke(time) {
    var timeSinceLastCall = time - lastCallTime, timeSinceLastInvoke = time - lastInvokeTime;
    return lastCallTime === void 0 || timeSinceLastCall >= wait || timeSinceLastCall < 0 || maxing && timeSinceLastInvoke >= maxWait;
  }
  function timerExpired() {
    var time = now_default();
    if (shouldInvoke(time)) {
      return trailingEdge(time);
    }
    timerId = setTimeout(timerExpired, remainingWait(time));
  }
  function trailingEdge(time) {
    timerId = void 0;
    if (trailing && lastArgs) {
      return invokeFunc(time);
    }
    lastArgs = lastThis = void 0;
    return result;
  }
  function cancel() {
    if (timerId !== void 0) {
      clearTimeout(timerId);
    }
    lastInvokeTime = 0;
    lastArgs = lastCallTime = lastThis = timerId = void 0;
  }
  function flush() {
    return timerId === void 0 ? result : trailingEdge(now_default());
  }
  function debounced() {
    var time = now_default(), isInvoking = shouldInvoke(time);
    lastArgs = arguments;
    lastThis = this;
    lastCallTime = time;
    if (isInvoking) {
      if (timerId === void 0) {
        return leadingEdge(lastCallTime);
      }
      if (maxing) {
        clearTimeout(timerId);
        timerId = setTimeout(timerExpired, wait);
        return invokeFunc(lastCallTime);
      }
    }
    if (timerId === void 0) {
      timerId = setTimeout(timerExpired, wait);
    }
    return result;
  }
  debounced.cancel = cancel;
  debounced.flush = flush;
  return debounced;
}
var debounce_default = debounce;

// node_modules/lodash-es/throttle.js
var FUNC_ERROR_TEXT2 = "Expected a function";
function throttle(func, wait, options) {
  var leading = true, trailing = true;
  if (typeof func != "function") {
    throw new TypeError(FUNC_ERROR_TEXT2);
  }
  if (isObject_default(options)) {
    leading = "leading" in options ? !!options.leading : leading;
    trailing = "trailing" in options ? !!options.trailing : trailing;
  }
  return debounce_default(func, wait, {
    "leading": leading,
    "maxWait": wait,
    "trailing": trailing
  });
}
var throttle_default = throttle;

// node_modules/react-color/es/helpers/saturation.js
var calculateChange5 = function calculateChange6(e9, hsl, container) {
  var _container$getBoundin = container.getBoundingClientRect(), containerWidth = _container$getBoundin.width, containerHeight = _container$getBoundin.height;
  var x5 = typeof e9.pageX === "number" ? e9.pageX : e9.touches[0].pageX;
  var y4 = typeof e9.pageY === "number" ? e9.pageY : e9.touches[0].pageY;
  var left = x5 - (container.getBoundingClientRect().left + window.pageXOffset);
  var top = y4 - (container.getBoundingClientRect().top + window.pageYOffset);
  if (left < 0) {
    left = 0;
  } else if (left > containerWidth) {
    left = containerWidth;
  }
  if (top < 0) {
    top = 0;
  } else if (top > containerHeight) {
    top = containerHeight;
  }
  var saturation = left / containerWidth;
  var bright = 1 - top / containerHeight;
  return {
    h: hsl.h,
    s: saturation,
    v: bright,
    a: hsl.a,
    source: "hsv"
  };
};

// node_modules/react-color/es/components/common/Saturation.js
var _createClass4 = function() {
  function defineProperties(target, props) {
    for (var i6 = 0; i6 < props.length; i6++) {
      var descriptor = props[i6];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor)
        descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }
  return function(Constructor, protoProps, staticProps) {
    if (protoProps)
      defineProperties(Constructor.prototype, protoProps);
    if (staticProps)
      defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();
function _classCallCheck4(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _possibleConstructorReturn4(self2, call) {
  if (!self2) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return call && (typeof call === "object" || typeof call === "function") ? call : self2;
}
function _inherits4(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
  if (superClass)
    Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
}
var Saturation = function(_ref) {
  _inherits4(Saturation2, _ref);
  function Saturation2(props) {
    _classCallCheck4(this, Saturation2);
    var _this = _possibleConstructorReturn4(this, (Saturation2.__proto__ || Object.getPrototypeOf(Saturation2)).call(this, props));
    _this.handleChange = function(e9) {
      typeof _this.props.onChange === "function" && _this.throttle(_this.props.onChange, calculateChange5(e9, _this.props.hsl, _this.container), e9);
    };
    _this.handleMouseDown = function(e9) {
      _this.handleChange(e9);
      var renderWindow = _this.getContainerRenderWindow();
      renderWindow.addEventListener("mousemove", _this.handleChange);
      renderWindow.addEventListener("mouseup", _this.handleMouseUp);
    };
    _this.handleMouseUp = function() {
      _this.unbindEventListeners();
    };
    _this.throttle = throttle_default(function(fn2, data, e9) {
      fn2(data, e9);
    }, 50);
    return _this;
  }
  _createClass4(Saturation2, [{
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      this.throttle.cancel();
      this.unbindEventListeners();
    }
  }, {
    key: "getContainerRenderWindow",
    value: function getContainerRenderWindow() {
      var container = this.container;
      var renderWindow = window;
      while (!renderWindow.document.contains(container) && renderWindow.parent !== renderWindow) {
        renderWindow = renderWindow.parent;
      }
      return renderWindow;
    }
  }, {
    key: "unbindEventListeners",
    value: function unbindEventListeners() {
      var renderWindow = this.getContainerRenderWindow();
      renderWindow.removeEventListener("mousemove", this.handleChange);
      renderWindow.removeEventListener("mouseup", this.handleMouseUp);
    }
  }, {
    key: "render",
    value: function render3() {
      var _this2 = this;
      var _ref2 = this.props.style || {}, color = _ref2.color, white = _ref2.white, black = _ref2.black, pointer = _ref2.pointer, circle = _ref2.circle;
      var styles = (0, import_reactcss6.default)({
        "default": {
          color: {
            absolute: "0px 0px 0px 0px",
            background: "hsl(" + this.props.hsl.h + ",100%, 50%)",
            borderRadius: this.props.radius
          },
          white: {
            absolute: "0px 0px 0px 0px",
            borderRadius: this.props.radius
          },
          black: {
            absolute: "0px 0px 0px 0px",
            boxShadow: this.props.shadow,
            borderRadius: this.props.radius
          },
          pointer: {
            position: "absolute",
            top: -(this.props.hsv.v * 100) + 100 + "%",
            left: this.props.hsv.s * 100 + "%",
            cursor: "default"
          },
          circle: {
            width: "4px",
            height: "4px",
            boxShadow: "0 0 0 1.5px #fff, inset 0 0 1px 1px rgba(0,0,0,.3),\n            0 0 1px 2px rgba(0,0,0,.4)",
            borderRadius: "50%",
            cursor: "hand",
            transform: "translate(-2px, -2px)"
          }
        },
        "custom": {
          color,
          white,
          black,
          pointer,
          circle
        }
      }, { "custom": !!this.props.style });
      return Cn.createElement(
        "div",
        {
          style: styles.color,
          ref: function ref(container) {
            return _this2.container = container;
          },
          onMouseDown: this.handleMouseDown,
          onTouchMove: this.handleChange,
          onTouchStart: this.handleChange
        },
        Cn.createElement(
          "style",
          null,
          "\n          .saturation-white {\n            background: -webkit-linear-gradient(to right, #fff, rgba(255,255,255,0));\n            background: linear-gradient(to right, #fff, rgba(255,255,255,0));\n          }\n          .saturation-black {\n            background: -webkit-linear-gradient(to top, #000, rgba(0,0,0,0));\n            background: linear-gradient(to top, #000, rgba(0,0,0,0));\n          }\n        "
        ),
        Cn.createElement(
          "div",
          { style: styles.white, className: "saturation-white" },
          Cn.createElement("div", { style: styles.black, className: "saturation-black" }),
          Cn.createElement(
            "div",
            { style: styles.pointer },
            this.props.pointer ? Cn.createElement(this.props.pointer, this.props) : Cn.createElement("div", { style: styles.circle })
          )
        )
      );
    }
  }]);
  return Saturation2;
}(w4 || b2);
var Saturation_default = Saturation;

// node_modules/react-color/es/components/common/ColorWrap.js
init_react();

// node_modules/lodash-es/_arrayEach.js
function arrayEach(array, iteratee) {
  var index = -1, length = array == null ? 0 : array.length;
  while (++index < length) {
    if (iteratee(array[index], index, array) === false) {
      break;
    }
  }
  return array;
}
var arrayEach_default = arrayEach;

// node_modules/lodash-es/_nativeKeys.js
var nativeKeys = overArg_default(Object.keys, Object);
var nativeKeys_default = nativeKeys;

// node_modules/lodash-es/_baseKeys.js
var objectProto12 = Object.prototype;
var hasOwnProperty10 = objectProto12.hasOwnProperty;
function baseKeys(object) {
  if (!isPrototype_default(object)) {
    return nativeKeys_default(object);
  }
  var result = [];
  for (var key in Object(object)) {
    if (hasOwnProperty10.call(object, key) && key != "constructor") {
      result.push(key);
    }
  }
  return result;
}
var baseKeys_default = baseKeys;

// node_modules/lodash-es/keys.js
function keys(object) {
  return isArrayLike_default(object) ? arrayLikeKeys_default(object) : baseKeys_default(object);
}
var keys_default = keys;

// node_modules/lodash-es/_baseForOwn.js
function baseForOwn(object, iteratee) {
  return object && baseFor_default(object, iteratee, keys_default);
}
var baseForOwn_default = baseForOwn;

// node_modules/lodash-es/_createBaseEach.js
function createBaseEach(eachFunc, fromRight) {
  return function(collection, iteratee) {
    if (collection == null) {
      return collection;
    }
    if (!isArrayLike_default(collection)) {
      return eachFunc(collection, iteratee);
    }
    var length = collection.length, index = fromRight ? length : -1, iterable = Object(collection);
    while (fromRight ? index-- : ++index < length) {
      if (iteratee(iterable[index], index, iterable) === false) {
        break;
      }
    }
    return collection;
  };
}
var createBaseEach_default = createBaseEach;

// node_modules/lodash-es/_baseEach.js
var baseEach = createBaseEach_default(baseForOwn_default);
var baseEach_default = baseEach;

// node_modules/lodash-es/_castFunction.js
function castFunction(value) {
  return typeof value == "function" ? value : identity_default;
}
var castFunction_default = castFunction;

// node_modules/lodash-es/forEach.js
function forEach(collection, iteratee) {
  var func = isArray_default(collection) ? arrayEach_default : baseEach_default;
  return func(collection, castFunction_default(iteratee));
}
var forEach_default = forEach;

// node_modules/tinycolor2/esm/tinycolor.js
function _typeof(obj) {
  "@babel/helpers - typeof";
  return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(obj2) {
    return typeof obj2;
  } : function(obj2) {
    return obj2 && "function" == typeof Symbol && obj2.constructor === Symbol && obj2 !== Symbol.prototype ? "symbol" : typeof obj2;
  }, _typeof(obj);
}
var trimLeft = /^\s+/;
var trimRight = /\s+$/;
function tinycolor(color, opts) {
  color = color ? color : "";
  opts = opts || {};
  if (color instanceof tinycolor) {
    return color;
  }
  if (!(this instanceof tinycolor)) {
    return new tinycolor(color, opts);
  }
  var rgb = inputToRGB(color);
  this._originalInput = color, this._r = rgb.r, this._g = rgb.g, this._b = rgb.b, this._a = rgb.a, this._roundA = Math.round(100 * this._a) / 100, this._format = opts.format || rgb.format;
  this._gradientType = opts.gradientType;
  if (this._r < 1)
    this._r = Math.round(this._r);
  if (this._g < 1)
    this._g = Math.round(this._g);
  if (this._b < 1)
    this._b = Math.round(this._b);
  this._ok = rgb.ok;
}
tinycolor.prototype = {
  isDark: function isDark() {
    return this.getBrightness() < 128;
  },
  isLight: function isLight() {
    return !this.isDark();
  },
  isValid: function isValid() {
    return this._ok;
  },
  getOriginalInput: function getOriginalInput() {
    return this._originalInput;
  },
  getFormat: function getFormat() {
    return this._format;
  },
  getAlpha: function getAlpha() {
    return this._a;
  },
  getBrightness: function getBrightness() {
    var rgb = this.toRgb();
    return (rgb.r * 299 + rgb.g * 587 + rgb.b * 114) / 1e3;
  },
  getLuminance: function getLuminance() {
    var rgb = this.toRgb();
    var RsRGB, GsRGB, BsRGB, R3, G3, B5;
    RsRGB = rgb.r / 255;
    GsRGB = rgb.g / 255;
    BsRGB = rgb.b / 255;
    if (RsRGB <= 0.03928)
      R3 = RsRGB / 12.92;
    else
      R3 = Math.pow((RsRGB + 0.055) / 1.055, 2.4);
    if (GsRGB <= 0.03928)
      G3 = GsRGB / 12.92;
    else
      G3 = Math.pow((GsRGB + 0.055) / 1.055, 2.4);
    if (BsRGB <= 0.03928)
      B5 = BsRGB / 12.92;
    else
      B5 = Math.pow((BsRGB + 0.055) / 1.055, 2.4);
    return 0.2126 * R3 + 0.7152 * G3 + 0.0722 * B5;
  },
  setAlpha: function setAlpha(value) {
    this._a = boundAlpha(value);
    this._roundA = Math.round(100 * this._a) / 100;
    return this;
  },
  toHsv: function toHsv() {
    var hsv = rgbToHsv(this._r, this._g, this._b);
    return {
      h: hsv.h * 360,
      s: hsv.s,
      v: hsv.v,
      a: this._a
    };
  },
  toHsvString: function toHsvString() {
    var hsv = rgbToHsv(this._r, this._g, this._b);
    var h5 = Math.round(hsv.h * 360), s7 = Math.round(hsv.s * 100), v4 = Math.round(hsv.v * 100);
    return this._a == 1 ? "hsv(" + h5 + ", " + s7 + "%, " + v4 + "%)" : "hsva(" + h5 + ", " + s7 + "%, " + v4 + "%, " + this._roundA + ")";
  },
  toHsl: function toHsl() {
    var hsl = rgbToHsl(this._r, this._g, this._b);
    return {
      h: hsl.h * 360,
      s: hsl.s,
      l: hsl.l,
      a: this._a
    };
  },
  toHslString: function toHslString() {
    var hsl = rgbToHsl(this._r, this._g, this._b);
    var h5 = Math.round(hsl.h * 360), s7 = Math.round(hsl.s * 100), l7 = Math.round(hsl.l * 100);
    return this._a == 1 ? "hsl(" + h5 + ", " + s7 + "%, " + l7 + "%)" : "hsla(" + h5 + ", " + s7 + "%, " + l7 + "%, " + this._roundA + ")";
  },
  toHex: function toHex(allow3Char) {
    return rgbToHex(this._r, this._g, this._b, allow3Char);
  },
  toHexString: function toHexString(allow3Char) {
    return "#" + this.toHex(allow3Char);
  },
  toHex8: function toHex8(allow4Char) {
    return rgbaToHex(this._r, this._g, this._b, this._a, allow4Char);
  },
  toHex8String: function toHex8String(allow4Char) {
    return "#" + this.toHex8(allow4Char);
  },
  toRgb: function toRgb() {
    return {
      r: Math.round(this._r),
      g: Math.round(this._g),
      b: Math.round(this._b),
      a: this._a
    };
  },
  toRgbString: function toRgbString() {
    return this._a == 1 ? "rgb(" + Math.round(this._r) + ", " + Math.round(this._g) + ", " + Math.round(this._b) + ")" : "rgba(" + Math.round(this._r) + ", " + Math.round(this._g) + ", " + Math.round(this._b) + ", " + this._roundA + ")";
  },
  toPercentageRgb: function toPercentageRgb() {
    return {
      r: Math.round(bound01(this._r, 255) * 100) + "%",
      g: Math.round(bound01(this._g, 255) * 100) + "%",
      b: Math.round(bound01(this._b, 255) * 100) + "%",
      a: this._a
    };
  },
  toPercentageRgbString: function toPercentageRgbString() {
    return this._a == 1 ? "rgb(" + Math.round(bound01(this._r, 255) * 100) + "%, " + Math.round(bound01(this._g, 255) * 100) + "%, " + Math.round(bound01(this._b, 255) * 100) + "%)" : "rgba(" + Math.round(bound01(this._r, 255) * 100) + "%, " + Math.round(bound01(this._g, 255) * 100) + "%, " + Math.round(bound01(this._b, 255) * 100) + "%, " + this._roundA + ")";
  },
  toName: function toName() {
    if (this._a === 0) {
      return "transparent";
    }
    if (this._a < 1) {
      return false;
    }
    return hexNames[rgbToHex(this._r, this._g, this._b, true)] || false;
  },
  toFilter: function toFilter(secondColor) {
    var hex8String = "#" + rgbaToArgbHex(this._r, this._g, this._b, this._a);
    var secondHex8String = hex8String;
    var gradientType = this._gradientType ? "GradientType = 1, " : "";
    if (secondColor) {
      var s7 = tinycolor(secondColor);
      secondHex8String = "#" + rgbaToArgbHex(s7._r, s7._g, s7._b, s7._a);
    }
    return "progid:DXImageTransform.Microsoft.gradient(" + gradientType + "startColorstr=" + hex8String + ",endColorstr=" + secondHex8String + ")";
  },
  toString: function toString(format) {
    var formatSet = !!format;
    format = format || this._format;
    var formattedString = false;
    var hasAlpha = this._a < 1 && this._a >= 0;
    var needsAlphaFormat = !formatSet && hasAlpha && (format === "hex" || format === "hex6" || format === "hex3" || format === "hex4" || format === "hex8" || format === "name");
    if (needsAlphaFormat) {
      if (format === "name" && this._a === 0) {
        return this.toName();
      }
      return this.toRgbString();
    }
    if (format === "rgb") {
      formattedString = this.toRgbString();
    }
    if (format === "prgb") {
      formattedString = this.toPercentageRgbString();
    }
    if (format === "hex" || format === "hex6") {
      formattedString = this.toHexString();
    }
    if (format === "hex3") {
      formattedString = this.toHexString(true);
    }
    if (format === "hex4") {
      formattedString = this.toHex8String(true);
    }
    if (format === "hex8") {
      formattedString = this.toHex8String();
    }
    if (format === "name") {
      formattedString = this.toName();
    }
    if (format === "hsl") {
      formattedString = this.toHslString();
    }
    if (format === "hsv") {
      formattedString = this.toHsvString();
    }
    return formattedString || this.toHexString();
  },
  clone: function clone() {
    return tinycolor(this.toString());
  },
  _applyModification: function _applyModification(fn2, args) {
    var color = fn2.apply(null, [this].concat([].slice.call(args)));
    this._r = color._r;
    this._g = color._g;
    this._b = color._b;
    this.setAlpha(color._a);
    return this;
  },
  lighten: function lighten() {
    return this._applyModification(_lighten, arguments);
  },
  brighten: function brighten() {
    return this._applyModification(_brighten, arguments);
  },
  darken: function darken() {
    return this._applyModification(_darken, arguments);
  },
  desaturate: function desaturate() {
    return this._applyModification(_desaturate, arguments);
  },
  saturate: function saturate() {
    return this._applyModification(_saturate, arguments);
  },
  greyscale: function greyscale() {
    return this._applyModification(_greyscale, arguments);
  },
  spin: function spin() {
    return this._applyModification(_spin, arguments);
  },
  _applyCombination: function _applyCombination(fn2, args) {
    return fn2.apply(null, [this].concat([].slice.call(args)));
  },
  analogous: function analogous() {
    return this._applyCombination(_analogous, arguments);
  },
  complement: function complement() {
    return this._applyCombination(_complement, arguments);
  },
  monochromatic: function monochromatic() {
    return this._applyCombination(_monochromatic, arguments);
  },
  splitcomplement: function splitcomplement() {
    return this._applyCombination(_splitcomplement, arguments);
  },
  // Disabled until https://github.com/bgrins/TinyColor/issues/254
  // polyad: function (number) {
  //   return this._applyCombination(polyad, [number]);
  // },
  triad: function triad() {
    return this._applyCombination(polyad, [3]);
  },
  tetrad: function tetrad() {
    return this._applyCombination(polyad, [4]);
  }
};
tinycolor.fromRatio = function(color, opts) {
  if (_typeof(color) == "object") {
    var newColor = {};
    for (var i6 in color) {
      if (color.hasOwnProperty(i6)) {
        if (i6 === "a") {
          newColor[i6] = color[i6];
        } else {
          newColor[i6] = convertToPercentage(color[i6]);
        }
      }
    }
    color = newColor;
  }
  return tinycolor(color, opts);
};
function inputToRGB(color) {
  var rgb = {
    r: 0,
    g: 0,
    b: 0
  };
  var a5 = 1;
  var s7 = null;
  var v4 = null;
  var l7 = null;
  var ok = false;
  var format = false;
  if (typeof color == "string") {
    color = stringInputToObject(color);
  }
  if (_typeof(color) == "object") {
    if (isValidCSSUnit(color.r) && isValidCSSUnit(color.g) && isValidCSSUnit(color.b)) {
      rgb = rgbToRgb(color.r, color.g, color.b);
      ok = true;
      format = String(color.r).substr(-1) === "%" ? "prgb" : "rgb";
    } else if (isValidCSSUnit(color.h) && isValidCSSUnit(color.s) && isValidCSSUnit(color.v)) {
      s7 = convertToPercentage(color.s);
      v4 = convertToPercentage(color.v);
      rgb = hsvToRgb(color.h, s7, v4);
      ok = true;
      format = "hsv";
    } else if (isValidCSSUnit(color.h) && isValidCSSUnit(color.s) && isValidCSSUnit(color.l)) {
      s7 = convertToPercentage(color.s);
      l7 = convertToPercentage(color.l);
      rgb = hslToRgb(color.h, s7, l7);
      ok = true;
      format = "hsl";
    }
    if (color.hasOwnProperty("a")) {
      a5 = color.a;
    }
  }
  a5 = boundAlpha(a5);
  return {
    ok,
    format: color.format || format,
    r: Math.min(255, Math.max(rgb.r, 0)),
    g: Math.min(255, Math.max(rgb.g, 0)),
    b: Math.min(255, Math.max(rgb.b, 0)),
    a: a5
  };
}
function rgbToRgb(r6, g5, b4) {
  return {
    r: bound01(r6, 255) * 255,
    g: bound01(g5, 255) * 255,
    b: bound01(b4, 255) * 255
  };
}
function rgbToHsl(r6, g5, b4) {
  r6 = bound01(r6, 255);
  g5 = bound01(g5, 255);
  b4 = bound01(b4, 255);
  var max = Math.max(r6, g5, b4), min = Math.min(r6, g5, b4);
  var h5, s7, l7 = (max + min) / 2;
  if (max == min) {
    h5 = s7 = 0;
  } else {
    var d5 = max - min;
    s7 = l7 > 0.5 ? d5 / (2 - max - min) : d5 / (max + min);
    switch (max) {
      case r6:
        h5 = (g5 - b4) / d5 + (g5 < b4 ? 6 : 0);
        break;
      case g5:
        h5 = (b4 - r6) / d5 + 2;
        break;
      case b4:
        h5 = (r6 - g5) / d5 + 4;
        break;
    }
    h5 /= 6;
  }
  return {
    h: h5,
    s: s7,
    l: l7
  };
}
function hslToRgb(h5, s7, l7) {
  var r6, g5, b4;
  h5 = bound01(h5, 360);
  s7 = bound01(s7, 100);
  l7 = bound01(l7, 100);
  function hue2rgb(p5, q5, t6) {
    if (t6 < 0)
      t6 += 1;
    if (t6 > 1)
      t6 -= 1;
    if (t6 < 1 / 6)
      return p5 + (q5 - p5) * 6 * t6;
    if (t6 < 1 / 2)
      return q5;
    if (t6 < 2 / 3)
      return p5 + (q5 - p5) * (2 / 3 - t6) * 6;
    return p5;
  }
  if (s7 === 0) {
    r6 = g5 = b4 = l7;
  } else {
    var q4 = l7 < 0.5 ? l7 * (1 + s7) : l7 + s7 - l7 * s7;
    var p4 = 2 * l7 - q4;
    r6 = hue2rgb(p4, q4, h5 + 1 / 3);
    g5 = hue2rgb(p4, q4, h5);
    b4 = hue2rgb(p4, q4, h5 - 1 / 3);
  }
  return {
    r: r6 * 255,
    g: g5 * 255,
    b: b4 * 255
  };
}
function rgbToHsv(r6, g5, b4) {
  r6 = bound01(r6, 255);
  g5 = bound01(g5, 255);
  b4 = bound01(b4, 255);
  var max = Math.max(r6, g5, b4), min = Math.min(r6, g5, b4);
  var h5, s7, v4 = max;
  var d5 = max - min;
  s7 = max === 0 ? 0 : d5 / max;
  if (max == min) {
    h5 = 0;
  } else {
    switch (max) {
      case r6:
        h5 = (g5 - b4) / d5 + (g5 < b4 ? 6 : 0);
        break;
      case g5:
        h5 = (b4 - r6) / d5 + 2;
        break;
      case b4:
        h5 = (r6 - g5) / d5 + 4;
        break;
    }
    h5 /= 6;
  }
  return {
    h: h5,
    s: s7,
    v: v4
  };
}
function hsvToRgb(h5, s7, v4) {
  h5 = bound01(h5, 360) * 6;
  s7 = bound01(s7, 100);
  v4 = bound01(v4, 100);
  var i6 = Math.floor(h5), f4 = h5 - i6, p4 = v4 * (1 - s7), q4 = v4 * (1 - f4 * s7), t6 = v4 * (1 - (1 - f4) * s7), mod = i6 % 6, r6 = [v4, q4, p4, p4, t6, v4][mod], g5 = [t6, v4, v4, q4, p4, p4][mod], b4 = [p4, p4, t6, v4, v4, q4][mod];
  return {
    r: r6 * 255,
    g: g5 * 255,
    b: b4 * 255
  };
}
function rgbToHex(r6, g5, b4, allow3Char) {
  var hex = [pad2(Math.round(r6).toString(16)), pad2(Math.round(g5).toString(16)), pad2(Math.round(b4).toString(16))];
  if (allow3Char && hex[0].charAt(0) == hex[0].charAt(1) && hex[1].charAt(0) == hex[1].charAt(1) && hex[2].charAt(0) == hex[2].charAt(1)) {
    return hex[0].charAt(0) + hex[1].charAt(0) + hex[2].charAt(0);
  }
  return hex.join("");
}
function rgbaToHex(r6, g5, b4, a5, allow4Char) {
  var hex = [pad2(Math.round(r6).toString(16)), pad2(Math.round(g5).toString(16)), pad2(Math.round(b4).toString(16)), pad2(convertDecimalToHex(a5))];
  if (allow4Char && hex[0].charAt(0) == hex[0].charAt(1) && hex[1].charAt(0) == hex[1].charAt(1) && hex[2].charAt(0) == hex[2].charAt(1) && hex[3].charAt(0) == hex[3].charAt(1)) {
    return hex[0].charAt(0) + hex[1].charAt(0) + hex[2].charAt(0) + hex[3].charAt(0);
  }
  return hex.join("");
}
function rgbaToArgbHex(r6, g5, b4, a5) {
  var hex = [pad2(convertDecimalToHex(a5)), pad2(Math.round(r6).toString(16)), pad2(Math.round(g5).toString(16)), pad2(Math.round(b4).toString(16))];
  return hex.join("");
}
tinycolor.equals = function(color1, color2) {
  if (!color1 || !color2)
    return false;
  return tinycolor(color1).toRgbString() == tinycolor(color2).toRgbString();
};
tinycolor.random = function() {
  return tinycolor.fromRatio({
    r: Math.random(),
    g: Math.random(),
    b: Math.random()
  });
};
function _desaturate(color, amount) {
  amount = amount === 0 ? 0 : amount || 10;
  var hsl = tinycolor(color).toHsl();
  hsl.s -= amount / 100;
  hsl.s = clamp01(hsl.s);
  return tinycolor(hsl);
}
function _saturate(color, amount) {
  amount = amount === 0 ? 0 : amount || 10;
  var hsl = tinycolor(color).toHsl();
  hsl.s += amount / 100;
  hsl.s = clamp01(hsl.s);
  return tinycolor(hsl);
}
function _greyscale(color) {
  return tinycolor(color).desaturate(100);
}
function _lighten(color, amount) {
  amount = amount === 0 ? 0 : amount || 10;
  var hsl = tinycolor(color).toHsl();
  hsl.l += amount / 100;
  hsl.l = clamp01(hsl.l);
  return tinycolor(hsl);
}
function _brighten(color, amount) {
  amount = amount === 0 ? 0 : amount || 10;
  var rgb = tinycolor(color).toRgb();
  rgb.r = Math.max(0, Math.min(255, rgb.r - Math.round(255 * -(amount / 100))));
  rgb.g = Math.max(0, Math.min(255, rgb.g - Math.round(255 * -(amount / 100))));
  rgb.b = Math.max(0, Math.min(255, rgb.b - Math.round(255 * -(amount / 100))));
  return tinycolor(rgb);
}
function _darken(color, amount) {
  amount = amount === 0 ? 0 : amount || 10;
  var hsl = tinycolor(color).toHsl();
  hsl.l -= amount / 100;
  hsl.l = clamp01(hsl.l);
  return tinycolor(hsl);
}
function _spin(color, amount) {
  var hsl = tinycolor(color).toHsl();
  var hue = (hsl.h + amount) % 360;
  hsl.h = hue < 0 ? 360 + hue : hue;
  return tinycolor(hsl);
}
function _complement(color) {
  var hsl = tinycolor(color).toHsl();
  hsl.h = (hsl.h + 180) % 360;
  return tinycolor(hsl);
}
function polyad(color, number) {
  if (isNaN(number) || number <= 0) {
    throw new Error("Argument to polyad must be a positive number");
  }
  var hsl = tinycolor(color).toHsl();
  var result = [tinycolor(color)];
  var step = 360 / number;
  for (var i6 = 1; i6 < number; i6++) {
    result.push(tinycolor({
      h: (hsl.h + i6 * step) % 360,
      s: hsl.s,
      l: hsl.l
    }));
  }
  return result;
}
function _splitcomplement(color) {
  var hsl = tinycolor(color).toHsl();
  var h5 = hsl.h;
  return [tinycolor(color), tinycolor({
    h: (h5 + 72) % 360,
    s: hsl.s,
    l: hsl.l
  }), tinycolor({
    h: (h5 + 216) % 360,
    s: hsl.s,
    l: hsl.l
  })];
}
function _analogous(color, results, slices) {
  results = results || 6;
  slices = slices || 30;
  var hsl = tinycolor(color).toHsl();
  var part = 360 / slices;
  var ret = [tinycolor(color)];
  for (hsl.h = (hsl.h - (part * results >> 1) + 720) % 360; --results; ) {
    hsl.h = (hsl.h + part) % 360;
    ret.push(tinycolor(hsl));
  }
  return ret;
}
function _monochromatic(color, results) {
  results = results || 6;
  var hsv = tinycolor(color).toHsv();
  var h5 = hsv.h, s7 = hsv.s, v4 = hsv.v;
  var ret = [];
  var modification = 1 / results;
  while (results--) {
    ret.push(tinycolor({
      h: h5,
      s: s7,
      v: v4
    }));
    v4 = (v4 + modification) % 1;
  }
  return ret;
}
tinycolor.mix = function(color1, color2, amount) {
  amount = amount === 0 ? 0 : amount || 50;
  var rgb1 = tinycolor(color1).toRgb();
  var rgb2 = tinycolor(color2).toRgb();
  var p4 = amount / 100;
  var rgba = {
    r: (rgb2.r - rgb1.r) * p4 + rgb1.r,
    g: (rgb2.g - rgb1.g) * p4 + rgb1.g,
    b: (rgb2.b - rgb1.b) * p4 + rgb1.b,
    a: (rgb2.a - rgb1.a) * p4 + rgb1.a
  };
  return tinycolor(rgba);
};
tinycolor.readability = function(color1, color2) {
  var c1 = tinycolor(color1);
  var c22 = tinycolor(color2);
  return (Math.max(c1.getLuminance(), c22.getLuminance()) + 0.05) / (Math.min(c1.getLuminance(), c22.getLuminance()) + 0.05);
};
tinycolor.isReadable = function(color1, color2, wcag2) {
  var readability = tinycolor.readability(color1, color2);
  var wcag2Parms, out;
  out = false;
  wcag2Parms = validateWCAG2Parms(wcag2);
  switch (wcag2Parms.level + wcag2Parms.size) {
    case "AAsmall":
    case "AAAlarge":
      out = readability >= 4.5;
      break;
    case "AAlarge":
      out = readability >= 3;
      break;
    case "AAAsmall":
      out = readability >= 7;
      break;
  }
  return out;
};
tinycolor.mostReadable = function(baseColor, colorList, args) {
  var bestColor = null;
  var bestScore = 0;
  var readability;
  var includeFallbackColors, level, size;
  args = args || {};
  includeFallbackColors = args.includeFallbackColors;
  level = args.level;
  size = args.size;
  for (var i6 = 0; i6 < colorList.length; i6++) {
    readability = tinycolor.readability(baseColor, colorList[i6]);
    if (readability > bestScore) {
      bestScore = readability;
      bestColor = tinycolor(colorList[i6]);
    }
  }
  if (tinycolor.isReadable(baseColor, bestColor, {
    level,
    size
  }) || !includeFallbackColors) {
    return bestColor;
  } else {
    args.includeFallbackColors = false;
    return tinycolor.mostReadable(baseColor, ["#fff", "#000"], args);
  }
};
var names = tinycolor.names = {
  aliceblue: "f0f8ff",
  antiquewhite: "faebd7",
  aqua: "0ff",
  aquamarine: "7fffd4",
  azure: "f0ffff",
  beige: "f5f5dc",
  bisque: "ffe4c4",
  black: "000",
  blanchedalmond: "ffebcd",
  blue: "00f",
  blueviolet: "8a2be2",
  brown: "a52a2a",
  burlywood: "deb887",
  burntsienna: "ea7e5d",
  cadetblue: "5f9ea0",
  chartreuse: "7fff00",
  chocolate: "d2691e",
  coral: "ff7f50",
  cornflowerblue: "6495ed",
  cornsilk: "fff8dc",
  crimson: "dc143c",
  cyan: "0ff",
  darkblue: "00008b",
  darkcyan: "008b8b",
  darkgoldenrod: "b8860b",
  darkgray: "a9a9a9",
  darkgreen: "006400",
  darkgrey: "a9a9a9",
  darkkhaki: "bdb76b",
  darkmagenta: "8b008b",
  darkolivegreen: "556b2f",
  darkorange: "ff8c00",
  darkorchid: "9932cc",
  darkred: "8b0000",
  darksalmon: "e9967a",
  darkseagreen: "8fbc8f",
  darkslateblue: "483d8b",
  darkslategray: "2f4f4f",
  darkslategrey: "2f4f4f",
  darkturquoise: "00ced1",
  darkviolet: "9400d3",
  deeppink: "ff1493",
  deepskyblue: "00bfff",
  dimgray: "696969",
  dimgrey: "696969",
  dodgerblue: "1e90ff",
  firebrick: "b22222",
  floralwhite: "fffaf0",
  forestgreen: "228b22",
  fuchsia: "f0f",
  gainsboro: "dcdcdc",
  ghostwhite: "f8f8ff",
  gold: "ffd700",
  goldenrod: "daa520",
  gray: "808080",
  green: "008000",
  greenyellow: "adff2f",
  grey: "808080",
  honeydew: "f0fff0",
  hotpink: "ff69b4",
  indianred: "cd5c5c",
  indigo: "4b0082",
  ivory: "fffff0",
  khaki: "f0e68c",
  lavender: "e6e6fa",
  lavenderblush: "fff0f5",
  lawngreen: "7cfc00",
  lemonchiffon: "fffacd",
  lightblue: "add8e6",
  lightcoral: "f08080",
  lightcyan: "e0ffff",
  lightgoldenrodyellow: "fafad2",
  lightgray: "d3d3d3",
  lightgreen: "90ee90",
  lightgrey: "d3d3d3",
  lightpink: "ffb6c1",
  lightsalmon: "ffa07a",
  lightseagreen: "20b2aa",
  lightskyblue: "87cefa",
  lightslategray: "789",
  lightslategrey: "789",
  lightsteelblue: "b0c4de",
  lightyellow: "ffffe0",
  lime: "0f0",
  limegreen: "32cd32",
  linen: "faf0e6",
  magenta: "f0f",
  maroon: "800000",
  mediumaquamarine: "66cdaa",
  mediumblue: "0000cd",
  mediumorchid: "ba55d3",
  mediumpurple: "9370db",
  mediumseagreen: "3cb371",
  mediumslateblue: "7b68ee",
  mediumspringgreen: "00fa9a",
  mediumturquoise: "48d1cc",
  mediumvioletred: "c71585",
  midnightblue: "191970",
  mintcream: "f5fffa",
  mistyrose: "ffe4e1",
  moccasin: "ffe4b5",
  navajowhite: "ffdead",
  navy: "000080",
  oldlace: "fdf5e6",
  olive: "808000",
  olivedrab: "6b8e23",
  orange: "ffa500",
  orangered: "ff4500",
  orchid: "da70d6",
  palegoldenrod: "eee8aa",
  palegreen: "98fb98",
  paleturquoise: "afeeee",
  palevioletred: "db7093",
  papayawhip: "ffefd5",
  peachpuff: "ffdab9",
  peru: "cd853f",
  pink: "ffc0cb",
  plum: "dda0dd",
  powderblue: "b0e0e6",
  purple: "800080",
  rebeccapurple: "663399",
  red: "f00",
  rosybrown: "bc8f8f",
  royalblue: "4169e1",
  saddlebrown: "8b4513",
  salmon: "fa8072",
  sandybrown: "f4a460",
  seagreen: "2e8b57",
  seashell: "fff5ee",
  sienna: "a0522d",
  silver: "c0c0c0",
  skyblue: "87ceeb",
  slateblue: "6a5acd",
  slategray: "708090",
  slategrey: "708090",
  snow: "fffafa",
  springgreen: "00ff7f",
  steelblue: "4682b4",
  tan: "d2b48c",
  teal: "008080",
  thistle: "d8bfd8",
  tomato: "ff6347",
  turquoise: "40e0d0",
  violet: "ee82ee",
  wheat: "f5deb3",
  white: "fff",
  whitesmoke: "f5f5f5",
  yellow: "ff0",
  yellowgreen: "9acd32"
};
var hexNames = tinycolor.hexNames = flip(names);
function flip(o8) {
  var flipped = {};
  for (var i6 in o8) {
    if (o8.hasOwnProperty(i6)) {
      flipped[o8[i6]] = i6;
    }
  }
  return flipped;
}
function boundAlpha(a5) {
  a5 = parseFloat(a5);
  if (isNaN(a5) || a5 < 0 || a5 > 1) {
    a5 = 1;
  }
  return a5;
}
function bound01(n8, max) {
  if (isOnePointZero(n8))
    n8 = "100%";
  var processPercent = isPercentage(n8);
  n8 = Math.min(max, Math.max(0, parseFloat(n8)));
  if (processPercent) {
    n8 = parseInt(n8 * max, 10) / 100;
  }
  if (Math.abs(n8 - max) < 1e-6) {
    return 1;
  }
  return n8 % max / parseFloat(max);
}
function clamp01(val) {
  return Math.min(1, Math.max(0, val));
}
function parseIntFromHex(val) {
  return parseInt(val, 16);
}
function isOnePointZero(n8) {
  return typeof n8 == "string" && n8.indexOf(".") != -1 && parseFloat(n8) === 1;
}
function isPercentage(n8) {
  return typeof n8 === "string" && n8.indexOf("%") != -1;
}
function pad2(c5) {
  return c5.length == 1 ? "0" + c5 : "" + c5;
}
function convertToPercentage(n8) {
  if (n8 <= 1) {
    n8 = n8 * 100 + "%";
  }
  return n8;
}
function convertDecimalToHex(d5) {
  return Math.round(parseFloat(d5) * 255).toString(16);
}
function convertHexToDecimal(h5) {
  return parseIntFromHex(h5) / 255;
}
var matchers = function() {
  var CSS_INTEGER = "[-\\+]?\\d+%?";
  var CSS_NUMBER = "[-\\+]?\\d*\\.\\d+%?";
  var CSS_UNIT = "(?:" + CSS_NUMBER + ")|(?:" + CSS_INTEGER + ")";
  var PERMISSIVE_MATCH3 = "[\\s|\\(]+(" + CSS_UNIT + ")[,|\\s]+(" + CSS_UNIT + ")[,|\\s]+(" + CSS_UNIT + ")\\s*\\)?";
  var PERMISSIVE_MATCH4 = "[\\s|\\(]+(" + CSS_UNIT + ")[,|\\s]+(" + CSS_UNIT + ")[,|\\s]+(" + CSS_UNIT + ")[,|\\s]+(" + CSS_UNIT + ")\\s*\\)?";
  return {
    CSS_UNIT: new RegExp(CSS_UNIT),
    rgb: new RegExp("rgb" + PERMISSIVE_MATCH3),
    rgba: new RegExp("rgba" + PERMISSIVE_MATCH4),
    hsl: new RegExp("hsl" + PERMISSIVE_MATCH3),
    hsla: new RegExp("hsla" + PERMISSIVE_MATCH4),
    hsv: new RegExp("hsv" + PERMISSIVE_MATCH3),
    hsva: new RegExp("hsva" + PERMISSIVE_MATCH4),
    hex3: /^#?([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})$/,
    hex6: /^#?([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})$/,
    hex4: /^#?([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})$/,
    hex8: /^#?([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})$/
  };
}();
function isValidCSSUnit(color) {
  return !!matchers.CSS_UNIT.exec(color);
}
function stringInputToObject(color) {
  color = color.replace(trimLeft, "").replace(trimRight, "").toLowerCase();
  var named = false;
  if (names[color]) {
    color = names[color];
    named = true;
  } else if (color == "transparent") {
    return {
      r: 0,
      g: 0,
      b: 0,
      a: 0,
      format: "name"
    };
  }
  var match;
  if (match = matchers.rgb.exec(color)) {
    return {
      r: match[1],
      g: match[2],
      b: match[3]
    };
  }
  if (match = matchers.rgba.exec(color)) {
    return {
      r: match[1],
      g: match[2],
      b: match[3],
      a: match[4]
    };
  }
  if (match = matchers.hsl.exec(color)) {
    return {
      h: match[1],
      s: match[2],
      l: match[3]
    };
  }
  if (match = matchers.hsla.exec(color)) {
    return {
      h: match[1],
      s: match[2],
      l: match[3],
      a: match[4]
    };
  }
  if (match = matchers.hsv.exec(color)) {
    return {
      h: match[1],
      s: match[2],
      v: match[3]
    };
  }
  if (match = matchers.hsva.exec(color)) {
    return {
      h: match[1],
      s: match[2],
      v: match[3],
      a: match[4]
    };
  }
  if (match = matchers.hex8.exec(color)) {
    return {
      r: parseIntFromHex(match[1]),
      g: parseIntFromHex(match[2]),
      b: parseIntFromHex(match[3]),
      a: convertHexToDecimal(match[4]),
      format: named ? "name" : "hex8"
    };
  }
  if (match = matchers.hex6.exec(color)) {
    return {
      r: parseIntFromHex(match[1]),
      g: parseIntFromHex(match[2]),
      b: parseIntFromHex(match[3]),
      format: named ? "name" : "hex"
    };
  }
  if (match = matchers.hex4.exec(color)) {
    return {
      r: parseIntFromHex(match[1] + "" + match[1]),
      g: parseIntFromHex(match[2] + "" + match[2]),
      b: parseIntFromHex(match[3] + "" + match[3]),
      a: convertHexToDecimal(match[4] + "" + match[4]),
      format: named ? "name" : "hex8"
    };
  }
  if (match = matchers.hex3.exec(color)) {
    return {
      r: parseIntFromHex(match[1] + "" + match[1]),
      g: parseIntFromHex(match[2] + "" + match[2]),
      b: parseIntFromHex(match[3] + "" + match[3]),
      format: named ? "name" : "hex"
    };
  }
  return false;
}
function validateWCAG2Parms(parms) {
  var level, size;
  parms = parms || {
    level: "AA",
    size: "small"
  };
  level = (parms.level || "AA").toUpperCase();
  size = (parms.size || "small").toLowerCase();
  if (level !== "AA" && level !== "AAA") {
    level = "AA";
  }
  if (size !== "small" && size !== "large") {
    size = "small";
  }
  return {
    level,
    size
  };
}

// node_modules/react-color/es/helpers/color.js
var simpleCheckForValidColor = function simpleCheckForValidColor2(data) {
  var keysToCheck = ["r", "g", "b", "a", "h", "s", "l", "v"];
  var checked = 0;
  var passed = 0;
  forEach_default(keysToCheck, function(letter) {
    if (data[letter]) {
      checked += 1;
      if (!isNaN(data[letter])) {
        passed += 1;
      }
      if (letter === "s" || letter === "l") {
        var percentPatt = /^\d+%$/;
        if (percentPatt.test(data[letter])) {
          passed += 1;
        }
      }
    }
  });
  return checked === passed ? data : false;
};
var toState = function toState2(data, oldHue) {
  var color = data.hex ? tinycolor(data.hex) : tinycolor(data);
  var hsl = color.toHsl();
  var hsv = color.toHsv();
  var rgb = color.toRgb();
  var hex = color.toHex();
  if (hsl.s === 0) {
    hsl.h = oldHue || 0;
    hsv.h = oldHue || 0;
  }
  var transparent = hex === "000000" && rgb.a === 0;
  return {
    hsl,
    hex: transparent ? "transparent" : "#" + hex,
    rgb,
    hsv,
    oldHue: data.h || oldHue || hsl.h,
    source: data.source
  };
};
var isValidHex = function isValidHex2(hex) {
  if (hex === "transparent") {
    return true;
  }
  var lh = String(hex).charAt(0) === "#" ? 1 : 0;
  return hex.length !== 4 + lh && hex.length < 7 + lh && tinycolor(hex).isValid();
};
var getContrastingColor = function getContrastingColor2(data) {
  if (!data) {
    return "#fff";
  }
  var col = toState(data);
  if (col.hex === "transparent") {
    return "rgba(0,0,0,0.4)";
  }
  var yiq = (col.rgb.r * 299 + col.rgb.g * 587 + col.rgb.b * 114) / 1e3;
  return yiq >= 128 ? "#000" : "#fff";
};
var isvalidColorString = function isvalidColorString2(string, type) {
  var stringWithoutDegree = string.replace("\xB0", "");
  return tinycolor(type + " (" + stringWithoutDegree + ")")._ok;
};

// node_modules/react-color/es/components/common/ColorWrap.js
var _extends3 = Object.assign || function(target) {
  for (var i6 = 1; i6 < arguments.length; i6++) {
    var source = arguments[i6];
    for (var key in source) {
      if (Object.prototype.hasOwnProperty.call(source, key)) {
        target[key] = source[key];
      }
    }
  }
  return target;
};
var _createClass5 = function() {
  function defineProperties(target, props) {
    for (var i6 = 0; i6 < props.length; i6++) {
      var descriptor = props[i6];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor)
        descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }
  return function(Constructor, protoProps, staticProps) {
    if (protoProps)
      defineProperties(Constructor.prototype, protoProps);
    if (staticProps)
      defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();
function _classCallCheck5(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _possibleConstructorReturn5(self2, call) {
  if (!self2) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return call && (typeof call === "object" || typeof call === "function") ? call : self2;
}
function _inherits5(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
  if (superClass)
    Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
}
var ColorWrap = function ColorWrap2(Picker) {
  var ColorPicker2 = function(_ref) {
    _inherits5(ColorPicker3, _ref);
    function ColorPicker3(props) {
      _classCallCheck5(this, ColorPicker3);
      var _this = _possibleConstructorReturn5(this, (ColorPicker3.__proto__ || Object.getPrototypeOf(ColorPicker3)).call(this));
      _this.handleChange = function(data, event) {
        var isValidColor = simpleCheckForValidColor(data);
        if (isValidColor) {
          var colors2 = toState(data, data.h || _this.state.oldHue);
          _this.setState(colors2);
          _this.props.onChangeComplete && _this.debounce(_this.props.onChangeComplete, colors2, event);
          _this.props.onChange && _this.props.onChange(colors2, event);
        }
      };
      _this.handleSwatchHover = function(data, event) {
        var isValidColor = simpleCheckForValidColor(data);
        if (isValidColor) {
          var colors2 = toState(data, data.h || _this.state.oldHue);
          _this.props.onSwatchHover && _this.props.onSwatchHover(colors2, event);
        }
      };
      _this.state = _extends3({}, toState(props.color, 0));
      _this.debounce = debounce_default(function(fn2, data, event) {
        fn2(data, event);
      }, 100);
      return _this;
    }
    _createClass5(ColorPicker3, [{
      key: "render",
      value: function render3() {
        var optionalEvents = {};
        if (this.props.onSwatchHover) {
          optionalEvents.onSwatchHover = this.handleSwatchHover;
        }
        return Cn.createElement(Picker, _extends3({}, this.props, this.state, {
          onChange: this.handleChange
        }, optionalEvents));
      }
    }], [{
      key: "getDerivedStateFromProps",
      value: function getDerivedStateFromProps(nextProps, state) {
        return _extends3({}, toState(nextProps.color, state.oldHue));
      }
    }]);
    return ColorPicker3;
  }(w4 || b2);
  ColorPicker2.propTypes = _extends3({}, Picker.propTypes);
  ColorPicker2.defaultProps = _extends3({}, Picker.defaultProps, {
    color: {
      h: 250,
      s: 0.5,
      l: 0.2,
      a: 1
    }
  });
  return ColorPicker2;
};
var ColorWrap_default = ColorWrap;

// node_modules/react-color/es/components/common/Swatch.js
init_react();
var import_reactcss7 = __toESM(require_lib());

// node_modules/react-color/es/helpers/interaction.js
init_react();
var _extends4 = Object.assign || function(target) {
  for (var i6 = 1; i6 < arguments.length; i6++) {
    var source = arguments[i6];
    for (var key in source) {
      if (Object.prototype.hasOwnProperty.call(source, key)) {
        target[key] = source[key];
      }
    }
  }
  return target;
};
var _createClass6 = function() {
  function defineProperties(target, props) {
    for (var i6 = 0; i6 < props.length; i6++) {
      var descriptor = props[i6];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor)
        descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }
  return function(Constructor, protoProps, staticProps) {
    if (protoProps)
      defineProperties(Constructor.prototype, protoProps);
    if (staticProps)
      defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();
function _classCallCheck6(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _possibleConstructorReturn6(self2, call) {
  if (!self2) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return call && (typeof call === "object" || typeof call === "function") ? call : self2;
}
function _inherits6(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
  if (superClass)
    Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
}
var handleFocus = function handleFocus2(Component) {
  var Span = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "span";
  return function(_React$Component) {
    _inherits6(Focus, _React$Component);
    function Focus() {
      var _ref;
      var _temp, _this, _ret;
      _classCallCheck6(this, Focus);
      for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }
      return _ret = (_temp = (_this = _possibleConstructorReturn6(this, (_ref = Focus.__proto__ || Object.getPrototypeOf(Focus)).call.apply(_ref, [this].concat(args))), _this), _this.state = { focus: false }, _this.handleFocus = function() {
        return _this.setState({ focus: true });
      }, _this.handleBlur = function() {
        return _this.setState({ focus: false });
      }, _temp), _possibleConstructorReturn6(_this, _ret);
    }
    _createClass6(Focus, [{
      key: "render",
      value: function render3() {
        return Cn.createElement(
          Span,
          { onFocus: this.handleFocus, onBlur: this.handleBlur },
          Cn.createElement(Component, _extends4({}, this.props, this.state))
        );
      }
    }]);
    return Focus;
  }(Cn.Component);
};

// node_modules/react-color/es/components/common/Swatch.js
var _extends5 = Object.assign || function(target) {
  for (var i6 = 1; i6 < arguments.length; i6++) {
    var source = arguments[i6];
    for (var key in source) {
      if (Object.prototype.hasOwnProperty.call(source, key)) {
        target[key] = source[key];
      }
    }
  }
  return target;
};
var ENTER = 13;
var Swatch = function Swatch2(_ref) {
  var color = _ref.color, style = _ref.style, _ref$onClick = _ref.onClick, onClick = _ref$onClick === void 0 ? function() {
  } : _ref$onClick, onHover = _ref.onHover, _ref$title = _ref.title, title = _ref$title === void 0 ? color : _ref$title, children = _ref.children, focus = _ref.focus, _ref$focusStyle = _ref.focusStyle, focusStyle = _ref$focusStyle === void 0 ? {} : _ref$focusStyle;
  var transparent = color === "transparent";
  var styles = (0, import_reactcss7.default)({
    default: {
      swatch: _extends5({
        background: color,
        height: "100%",
        width: "100%",
        cursor: "pointer",
        position: "relative",
        outline: "none"
      }, style, focus ? focusStyle : {})
    }
  });
  var handleClick = function handleClick2(e9) {
    return onClick(color, e9);
  };
  var handleKeyDown = function handleKeyDown2(e9) {
    return e9.keyCode === ENTER && onClick(color, e9);
  };
  var handleHover3 = function handleHover4(e9) {
    return onHover(color, e9);
  };
  var optionalEvents = {};
  if (onHover) {
    optionalEvents.onMouseOver = handleHover3;
  }
  return Cn.createElement(
    "div",
    _extends5({
      style: styles.swatch,
      onClick: handleClick,
      title,
      tabIndex: 0,
      onKeyDown: handleKeyDown
    }, optionalEvents),
    children,
    transparent && Cn.createElement(Checkboard_default, {
      borderRadius: styles.swatch.borderRadius,
      boxShadow: "inset 0 0 0 1px rgba(0,0,0,0.1)"
    })
  );
};
var Swatch_default = handleFocus(Swatch);

// node_modules/react-color/es/components/alpha/AlphaPointer.js
init_react();
var import_reactcss8 = __toESM(require_lib());
var AlphaPointer = function AlphaPointer2(_ref) {
  var direction = _ref.direction;
  var styles = (0, import_reactcss8.default)({
    "default": {
      picker: {
        width: "18px",
        height: "18px",
        borderRadius: "50%",
        transform: "translate(-9px, -1px)",
        backgroundColor: "rgb(248, 248, 248)",
        boxShadow: "0 1px 4px 0 rgba(0, 0, 0, 0.37)"
      }
    },
    "vertical": {
      picker: {
        transform: "translate(-3px, -9px)"
      }
    }
  }, { vertical: direction === "vertical" });
  return Cn.createElement("div", { style: styles.picker });
};
var AlphaPointer_default = AlphaPointer;

// node_modules/react-color/es/components/alpha/Alpha.js
var _extends6 = Object.assign || function(target) {
  for (var i6 = 1; i6 < arguments.length; i6++) {
    var source = arguments[i6];
    for (var key in source) {
      if (Object.prototype.hasOwnProperty.call(source, key)) {
        target[key] = source[key];
      }
    }
  }
  return target;
};
var AlphaPicker = function AlphaPicker2(_ref) {
  var rgb = _ref.rgb, hsl = _ref.hsl, width = _ref.width, height = _ref.height, onChange = _ref.onChange, direction = _ref.direction, style = _ref.style, renderers = _ref.renderers, pointer = _ref.pointer, _ref$className = _ref.className, className = _ref$className === void 0 ? "" : _ref$className;
  var styles = (0, import_reactcss9.default)({
    "default": {
      picker: {
        position: "relative",
        width,
        height
      },
      alpha: {
        radius: "2px",
        style
      }
    }
  });
  return Cn.createElement(
    "div",
    { style: styles.picker, className: "alpha-picker " + className },
    Cn.createElement(Alpha_default, _extends6({}, styles.alpha, {
      rgb,
      hsl,
      pointer,
      renderers,
      onChange,
      direction
    }))
  );
};
AlphaPicker.defaultProps = {
  width: "316px",
  height: "16px",
  direction: "horizontal",
  pointer: AlphaPointer_default
};
var Alpha_default2 = ColorWrap_default(AlphaPicker);

// node_modules/react-color/es/components/block/Block.js
init_react();
var import_prop_types2 = __toESM(require_prop_types());
var import_reactcss11 = __toESM(require_lib());

// node_modules/react-color/es/components/block/BlockSwatches.js
init_react();
var import_reactcss10 = __toESM(require_lib());

// node_modules/lodash-es/_arrayMap.js
function arrayMap(array, iteratee) {
  var index = -1, length = array == null ? 0 : array.length, result = Array(length);
  while (++index < length) {
    result[index] = iteratee(array[index], index, array);
  }
  return result;
}
var arrayMap_default = arrayMap;

// node_modules/lodash-es/_setCacheAdd.js
var HASH_UNDEFINED3 = "__lodash_hash_undefined__";
function setCacheAdd(value) {
  this.__data__.set(value, HASH_UNDEFINED3);
  return this;
}
var setCacheAdd_default = setCacheAdd;

// node_modules/lodash-es/_setCacheHas.js
function setCacheHas(value) {
  return this.__data__.has(value);
}
var setCacheHas_default = setCacheHas;

// node_modules/lodash-es/_SetCache.js
function SetCache(values) {
  var index = -1, length = values == null ? 0 : values.length;
  this.__data__ = new MapCache_default();
  while (++index < length) {
    this.add(values[index]);
  }
}
SetCache.prototype.add = SetCache.prototype.push = setCacheAdd_default;
SetCache.prototype.has = setCacheHas_default;
var SetCache_default = SetCache;

// node_modules/lodash-es/_arraySome.js
function arraySome(array, predicate) {
  var index = -1, length = array == null ? 0 : array.length;
  while (++index < length) {
    if (predicate(array[index], index, array)) {
      return true;
    }
  }
  return false;
}
var arraySome_default = arraySome;

// node_modules/lodash-es/_cacheHas.js
function cacheHas(cache, key) {
  return cache.has(key);
}
var cacheHas_default = cacheHas;

// node_modules/lodash-es/_equalArrays.js
var COMPARE_PARTIAL_FLAG = 1;
var COMPARE_UNORDERED_FLAG = 2;
function equalArrays(array, other, bitmask, customizer, equalFunc, stack) {
  var isPartial = bitmask & COMPARE_PARTIAL_FLAG, arrLength = array.length, othLength = other.length;
  if (arrLength != othLength && !(isPartial && othLength > arrLength)) {
    return false;
  }
  var arrStacked = stack.get(array);
  var othStacked = stack.get(other);
  if (arrStacked && othStacked) {
    return arrStacked == other && othStacked == array;
  }
  var index = -1, result = true, seen = bitmask & COMPARE_UNORDERED_FLAG ? new SetCache_default() : void 0;
  stack.set(array, other);
  stack.set(other, array);
  while (++index < arrLength) {
    var arrValue = array[index], othValue = other[index];
    if (customizer) {
      var compared = isPartial ? customizer(othValue, arrValue, index, other, array, stack) : customizer(arrValue, othValue, index, array, other, stack);
    }
    if (compared !== void 0) {
      if (compared) {
        continue;
      }
      result = false;
      break;
    }
    if (seen) {
      if (!arraySome_default(other, function(othValue2, othIndex) {
        if (!cacheHas_default(seen, othIndex) && (arrValue === othValue2 || equalFunc(arrValue, othValue2, bitmask, customizer, stack))) {
          return seen.push(othIndex);
        }
      })) {
        result = false;
        break;
      }
    } else if (!(arrValue === othValue || equalFunc(arrValue, othValue, bitmask, customizer, stack))) {
      result = false;
      break;
    }
  }
  stack["delete"](array);
  stack["delete"](other);
  return result;
}
var equalArrays_default = equalArrays;

// node_modules/lodash-es/_mapToArray.js
function mapToArray(map2) {
  var index = -1, result = Array(map2.size);
  map2.forEach(function(value, key) {
    result[++index] = [key, value];
  });
  return result;
}
var mapToArray_default = mapToArray;

// node_modules/lodash-es/_setToArray.js
function setToArray(set) {
  var index = -1, result = Array(set.size);
  set.forEach(function(value) {
    result[++index] = value;
  });
  return result;
}
var setToArray_default = setToArray;

// node_modules/lodash-es/_equalByTag.js
var COMPARE_PARTIAL_FLAG2 = 1;
var COMPARE_UNORDERED_FLAG2 = 2;
var boolTag2 = "[object Boolean]";
var dateTag2 = "[object Date]";
var errorTag2 = "[object Error]";
var mapTag2 = "[object Map]";
var numberTag2 = "[object Number]";
var regexpTag2 = "[object RegExp]";
var setTag2 = "[object Set]";
var stringTag2 = "[object String]";
var symbolTag2 = "[object Symbol]";
var arrayBufferTag2 = "[object ArrayBuffer]";
var dataViewTag2 = "[object DataView]";
var symbolProto = Symbol_default ? Symbol_default.prototype : void 0;
var symbolValueOf = symbolProto ? symbolProto.valueOf : void 0;
function equalByTag(object, other, tag, bitmask, customizer, equalFunc, stack) {
  switch (tag) {
    case dataViewTag2:
      if (object.byteLength != other.byteLength || object.byteOffset != other.byteOffset) {
        return false;
      }
      object = object.buffer;
      other = other.buffer;
    case arrayBufferTag2:
      if (object.byteLength != other.byteLength || !equalFunc(new Uint8Array_default(object), new Uint8Array_default(other))) {
        return false;
      }
      return true;
    case boolTag2:
    case dateTag2:
    case numberTag2:
      return eq_default(+object, +other);
    case errorTag2:
      return object.name == other.name && object.message == other.message;
    case regexpTag2:
    case stringTag2:
      return object == other + "";
    case mapTag2:
      var convert = mapToArray_default;
    case setTag2:
      var isPartial = bitmask & COMPARE_PARTIAL_FLAG2;
      convert || (convert = setToArray_default);
      if (object.size != other.size && !isPartial) {
        return false;
      }
      var stacked = stack.get(object);
      if (stacked) {
        return stacked == other;
      }
      bitmask |= COMPARE_UNORDERED_FLAG2;
      stack.set(object, other);
      var result = equalArrays_default(convert(object), convert(other), bitmask, customizer, equalFunc, stack);
      stack["delete"](object);
      return result;
    case symbolTag2:
      if (symbolValueOf) {
        return symbolValueOf.call(object) == symbolValueOf.call(other);
      }
  }
  return false;
}
var equalByTag_default = equalByTag;

// node_modules/lodash-es/_arrayPush.js
function arrayPush(array, values) {
  var index = -1, length = values.length, offset = array.length;
  while (++index < length) {
    array[offset + index] = values[index];
  }
  return array;
}
var arrayPush_default = arrayPush;

// node_modules/lodash-es/_baseGetAllKeys.js
function baseGetAllKeys(object, keysFunc, symbolsFunc) {
  var result = keysFunc(object);
  return isArray_default(object) ? result : arrayPush_default(result, symbolsFunc(object));
}
var baseGetAllKeys_default = baseGetAllKeys;

// node_modules/lodash-es/_arrayFilter.js
function arrayFilter(array, predicate) {
  var index = -1, length = array == null ? 0 : array.length, resIndex = 0, result = [];
  while (++index < length) {
    var value = array[index];
    if (predicate(value, index, array)) {
      result[resIndex++] = value;
    }
  }
  return result;
}
var arrayFilter_default = arrayFilter;

// node_modules/lodash-es/stubArray.js
function stubArray() {
  return [];
}
var stubArray_default = stubArray;

// node_modules/lodash-es/_getSymbols.js
var objectProto13 = Object.prototype;
var propertyIsEnumerable2 = objectProto13.propertyIsEnumerable;
var nativeGetSymbols = Object.getOwnPropertySymbols;
var getSymbols = !nativeGetSymbols ? stubArray_default : function(object) {
  if (object == null) {
    return [];
  }
  object = Object(object);
  return arrayFilter_default(nativeGetSymbols(object), function(symbol) {
    return propertyIsEnumerable2.call(object, symbol);
  });
};
var getSymbols_default = getSymbols;

// node_modules/lodash-es/_getAllKeys.js
function getAllKeys(object) {
  return baseGetAllKeys_default(object, keys_default, getSymbols_default);
}
var getAllKeys_default = getAllKeys;

// node_modules/lodash-es/_equalObjects.js
var COMPARE_PARTIAL_FLAG3 = 1;
var objectProto14 = Object.prototype;
var hasOwnProperty11 = objectProto14.hasOwnProperty;
function equalObjects(object, other, bitmask, customizer, equalFunc, stack) {
  var isPartial = bitmask & COMPARE_PARTIAL_FLAG3, objProps = getAllKeys_default(object), objLength = objProps.length, othProps = getAllKeys_default(other), othLength = othProps.length;
  if (objLength != othLength && !isPartial) {
    return false;
  }
  var index = objLength;
  while (index--) {
    var key = objProps[index];
    if (!(isPartial ? key in other : hasOwnProperty11.call(other, key))) {
      return false;
    }
  }
  var objStacked = stack.get(object);
  var othStacked = stack.get(other);
  if (objStacked && othStacked) {
    return objStacked == other && othStacked == object;
  }
  var result = true;
  stack.set(object, other);
  stack.set(other, object);
  var skipCtor = isPartial;
  while (++index < objLength) {
    key = objProps[index];
    var objValue = object[key], othValue = other[key];
    if (customizer) {
      var compared = isPartial ? customizer(othValue, objValue, key, other, object, stack) : customizer(objValue, othValue, key, object, other, stack);
    }
    if (!(compared === void 0 ? objValue === othValue || equalFunc(objValue, othValue, bitmask, customizer, stack) : compared)) {
      result = false;
      break;
    }
    skipCtor || (skipCtor = key == "constructor");
  }
  if (result && !skipCtor) {
    var objCtor = object.constructor, othCtor = other.constructor;
    if (objCtor != othCtor && ("constructor" in object && "constructor" in other) && !(typeof objCtor == "function" && objCtor instanceof objCtor && typeof othCtor == "function" && othCtor instanceof othCtor)) {
      result = false;
    }
  }
  stack["delete"](object);
  stack["delete"](other);
  return result;
}
var equalObjects_default = equalObjects;

// node_modules/lodash-es/_DataView.js
var DataView = getNative_default(root_default, "DataView");
var DataView_default = DataView;

// node_modules/lodash-es/_Promise.js
var Promise2 = getNative_default(root_default, "Promise");
var Promise_default = Promise2;

// node_modules/lodash-es/_Set.js
var Set2 = getNative_default(root_default, "Set");
var Set_default = Set2;

// node_modules/lodash-es/_WeakMap.js
var WeakMap2 = getNative_default(root_default, "WeakMap");
var WeakMap_default = WeakMap2;

// node_modules/lodash-es/_getTag.js
var mapTag3 = "[object Map]";
var objectTag3 = "[object Object]";
var promiseTag = "[object Promise]";
var setTag3 = "[object Set]";
var weakMapTag2 = "[object WeakMap]";
var dataViewTag3 = "[object DataView]";
var dataViewCtorString = toSource_default(DataView_default);
var mapCtorString = toSource_default(Map_default);
var promiseCtorString = toSource_default(Promise_default);
var setCtorString = toSource_default(Set_default);
var weakMapCtorString = toSource_default(WeakMap_default);
var getTag = baseGetTag_default;
if (DataView_default && getTag(new DataView_default(new ArrayBuffer(1))) != dataViewTag3 || Map_default && getTag(new Map_default()) != mapTag3 || Promise_default && getTag(Promise_default.resolve()) != promiseTag || Set_default && getTag(new Set_default()) != setTag3 || WeakMap_default && getTag(new WeakMap_default()) != weakMapTag2) {
  getTag = function(value) {
    var result = baseGetTag_default(value), Ctor = result == objectTag3 ? value.constructor : void 0, ctorString = Ctor ? toSource_default(Ctor) : "";
    if (ctorString) {
      switch (ctorString) {
        case dataViewCtorString:
          return dataViewTag3;
        case mapCtorString:
          return mapTag3;
        case promiseCtorString:
          return promiseTag;
        case setCtorString:
          return setTag3;
        case weakMapCtorString:
          return weakMapTag2;
      }
    }
    return result;
  };
}
var getTag_default = getTag;

// node_modules/lodash-es/_baseIsEqualDeep.js
var COMPARE_PARTIAL_FLAG4 = 1;
var argsTag3 = "[object Arguments]";
var arrayTag2 = "[object Array]";
var objectTag4 = "[object Object]";
var objectProto15 = Object.prototype;
var hasOwnProperty12 = objectProto15.hasOwnProperty;
function baseIsEqualDeep(object, other, bitmask, customizer, equalFunc, stack) {
  var objIsArr = isArray_default(object), othIsArr = isArray_default(other), objTag = objIsArr ? arrayTag2 : getTag_default(object), othTag = othIsArr ? arrayTag2 : getTag_default(other);
  objTag = objTag == argsTag3 ? objectTag4 : objTag;
  othTag = othTag == argsTag3 ? objectTag4 : othTag;
  var objIsObj = objTag == objectTag4, othIsObj = othTag == objectTag4, isSameTag = objTag == othTag;
  if (isSameTag && isBuffer_default(object)) {
    if (!isBuffer_default(other)) {
      return false;
    }
    objIsArr = true;
    objIsObj = false;
  }
  if (isSameTag && !objIsObj) {
    stack || (stack = new Stack_default());
    return objIsArr || isTypedArray_default(object) ? equalArrays_default(object, other, bitmask, customizer, equalFunc, stack) : equalByTag_default(object, other, objTag, bitmask, customizer, equalFunc, stack);
  }
  if (!(bitmask & COMPARE_PARTIAL_FLAG4)) {
    var objIsWrapped = objIsObj && hasOwnProperty12.call(object, "__wrapped__"), othIsWrapped = othIsObj && hasOwnProperty12.call(other, "__wrapped__");
    if (objIsWrapped || othIsWrapped) {
      var objUnwrapped = objIsWrapped ? object.value() : object, othUnwrapped = othIsWrapped ? other.value() : other;
      stack || (stack = new Stack_default());
      return equalFunc(objUnwrapped, othUnwrapped, bitmask, customizer, stack);
    }
  }
  if (!isSameTag) {
    return false;
  }
  stack || (stack = new Stack_default());
  return equalObjects_default(object, other, bitmask, customizer, equalFunc, stack);
}
var baseIsEqualDeep_default = baseIsEqualDeep;

// node_modules/lodash-es/_baseIsEqual.js
function baseIsEqual(value, other, bitmask, customizer, stack) {
  if (value === other) {
    return true;
  }
  if (value == null || other == null || !isObjectLike_default(value) && !isObjectLike_default(other)) {
    return value !== value && other !== other;
  }
  return baseIsEqualDeep_default(value, other, bitmask, customizer, baseIsEqual, stack);
}
var baseIsEqual_default = baseIsEqual;

// node_modules/lodash-es/_baseIsMatch.js
var COMPARE_PARTIAL_FLAG5 = 1;
var COMPARE_UNORDERED_FLAG3 = 2;
function baseIsMatch(object, source, matchData, customizer) {
  var index = matchData.length, length = index, noCustomizer = !customizer;
  if (object == null) {
    return !length;
  }
  object = Object(object);
  while (index--) {
    var data = matchData[index];
    if (noCustomizer && data[2] ? data[1] !== object[data[0]] : !(data[0] in object)) {
      return false;
    }
  }
  while (++index < length) {
    data = matchData[index];
    var key = data[0], objValue = object[key], srcValue = data[1];
    if (noCustomizer && data[2]) {
      if (objValue === void 0 && !(key in object)) {
        return false;
      }
    } else {
      var stack = new Stack_default();
      if (customizer) {
        var result = customizer(objValue, srcValue, key, object, source, stack);
      }
      if (!(result === void 0 ? baseIsEqual_default(srcValue, objValue, COMPARE_PARTIAL_FLAG5 | COMPARE_UNORDERED_FLAG3, customizer, stack) : result)) {
        return false;
      }
    }
  }
  return true;
}
var baseIsMatch_default = baseIsMatch;

// node_modules/lodash-es/_isStrictComparable.js
function isStrictComparable(value) {
  return value === value && !isObject_default(value);
}
var isStrictComparable_default = isStrictComparable;

// node_modules/lodash-es/_getMatchData.js
function getMatchData(object) {
  var result = keys_default(object), length = result.length;
  while (length--) {
    var key = result[length], value = object[key];
    result[length] = [key, value, isStrictComparable_default(value)];
  }
  return result;
}
var getMatchData_default = getMatchData;

// node_modules/lodash-es/_matchesStrictComparable.js
function matchesStrictComparable(key, srcValue) {
  return function(object) {
    if (object == null) {
      return false;
    }
    return object[key] === srcValue && (srcValue !== void 0 || key in Object(object));
  };
}
var matchesStrictComparable_default = matchesStrictComparable;

// node_modules/lodash-es/_baseMatches.js
function baseMatches(source) {
  var matchData = getMatchData_default(source);
  if (matchData.length == 1 && matchData[0][2]) {
    return matchesStrictComparable_default(matchData[0][0], matchData[0][1]);
  }
  return function(object) {
    return object === source || baseIsMatch_default(object, source, matchData);
  };
}
var baseMatches_default = baseMatches;

// node_modules/lodash-es/_isKey.js
var reIsDeepProp = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/;
var reIsPlainProp = /^\w*$/;
function isKey(value, object) {
  if (isArray_default(value)) {
    return false;
  }
  var type = typeof value;
  if (type == "number" || type == "symbol" || type == "boolean" || value == null || isSymbol_default(value)) {
    return true;
  }
  return reIsPlainProp.test(value) || !reIsDeepProp.test(value) || object != null && value in Object(object);
}
var isKey_default = isKey;

// node_modules/lodash-es/memoize.js
var FUNC_ERROR_TEXT3 = "Expected a function";
function memoize(func, resolver) {
  if (typeof func != "function" || resolver != null && typeof resolver != "function") {
    throw new TypeError(FUNC_ERROR_TEXT3);
  }
  var memoized = function() {
    var args = arguments, key = resolver ? resolver.apply(this, args) : args[0], cache = memoized.cache;
    if (cache.has(key)) {
      return cache.get(key);
    }
    var result = func.apply(this, args);
    memoized.cache = cache.set(key, result) || cache;
    return result;
  };
  memoized.cache = new (memoize.Cache || MapCache_default)();
  return memoized;
}
memoize.Cache = MapCache_default;
var memoize_default = memoize;

// node_modules/lodash-es/_memoizeCapped.js
var MAX_MEMOIZE_SIZE = 500;
function memoizeCapped(func) {
  var result = memoize_default(func, function(key) {
    if (cache.size === MAX_MEMOIZE_SIZE) {
      cache.clear();
    }
    return key;
  });
  var cache = result.cache;
  return result;
}
var memoizeCapped_default = memoizeCapped;

// node_modules/lodash-es/_stringToPath.js
var rePropName = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g;
var reEscapeChar = /\\(\\)?/g;
var stringToPath = memoizeCapped_default(function(string) {
  var result = [];
  if (string.charCodeAt(0) === 46) {
    result.push("");
  }
  string.replace(rePropName, function(match, number, quote, subString) {
    result.push(quote ? subString.replace(reEscapeChar, "$1") : number || match);
  });
  return result;
});
var stringToPath_default = stringToPath;

// node_modules/lodash-es/_baseToString.js
var INFINITY = 1 / 0;
var symbolProto2 = Symbol_default ? Symbol_default.prototype : void 0;
var symbolToString = symbolProto2 ? symbolProto2.toString : void 0;
function baseToString(value) {
  if (typeof value == "string") {
    return value;
  }
  if (isArray_default(value)) {
    return arrayMap_default(value, baseToString) + "";
  }
  if (isSymbol_default(value)) {
    return symbolToString ? symbolToString.call(value) : "";
  }
  var result = value + "";
  return result == "0" && 1 / value == -INFINITY ? "-0" : result;
}
var baseToString_default = baseToString;

// node_modules/lodash-es/toString.js
function toString2(value) {
  return value == null ? "" : baseToString_default(value);
}
var toString_default = toString2;

// node_modules/lodash-es/_castPath.js
function castPath(value, object) {
  if (isArray_default(value)) {
    return value;
  }
  return isKey_default(value, object) ? [value] : stringToPath_default(toString_default(value));
}
var castPath_default = castPath;

// node_modules/lodash-es/_toKey.js
var INFINITY2 = 1 / 0;
function toKey(value) {
  if (typeof value == "string" || isSymbol_default(value)) {
    return value;
  }
  var result = value + "";
  return result == "0" && 1 / value == -INFINITY2 ? "-0" : result;
}
var toKey_default = toKey;

// node_modules/lodash-es/_baseGet.js
function baseGet(object, path) {
  path = castPath_default(path, object);
  var index = 0, length = path.length;
  while (object != null && index < length) {
    object = object[toKey_default(path[index++])];
  }
  return index && index == length ? object : void 0;
}
var baseGet_default = baseGet;

// node_modules/lodash-es/get.js
function get3(object, path, defaultValue) {
  var result = object == null ? void 0 : baseGet_default(object, path);
  return result === void 0 ? defaultValue : result;
}
var get_default = get3;

// node_modules/lodash-es/_baseHasIn.js
function baseHasIn(object, key) {
  return object != null && key in Object(object);
}
var baseHasIn_default = baseHasIn;

// node_modules/lodash-es/_hasPath.js
function hasPath(object, path, hasFunc) {
  path = castPath_default(path, object);
  var index = -1, length = path.length, result = false;
  while (++index < length) {
    var key = toKey_default(path[index]);
    if (!(result = object != null && hasFunc(object, key))) {
      break;
    }
    object = object[key];
  }
  if (result || ++index != length) {
    return result;
  }
  length = object == null ? 0 : object.length;
  return !!length && isLength_default(length) && isIndex_default(key, length) && (isArray_default(object) || isArguments_default(object));
}
var hasPath_default = hasPath;

// node_modules/lodash-es/hasIn.js
function hasIn(object, path) {
  return object != null && hasPath_default(object, path, baseHasIn_default);
}
var hasIn_default = hasIn;

// node_modules/lodash-es/_baseMatchesProperty.js
var COMPARE_PARTIAL_FLAG6 = 1;
var COMPARE_UNORDERED_FLAG4 = 2;
function baseMatchesProperty(path, srcValue) {
  if (isKey_default(path) && isStrictComparable_default(srcValue)) {
    return matchesStrictComparable_default(toKey_default(path), srcValue);
  }
  return function(object) {
    var objValue = get_default(object, path);
    return objValue === void 0 && objValue === srcValue ? hasIn_default(object, path) : baseIsEqual_default(srcValue, objValue, COMPARE_PARTIAL_FLAG6 | COMPARE_UNORDERED_FLAG4);
  };
}
var baseMatchesProperty_default = baseMatchesProperty;

// node_modules/lodash-es/_baseProperty.js
function baseProperty(key) {
  return function(object) {
    return object == null ? void 0 : object[key];
  };
}
var baseProperty_default = baseProperty;

// node_modules/lodash-es/_basePropertyDeep.js
function basePropertyDeep(path) {
  return function(object) {
    return baseGet_default(object, path);
  };
}
var basePropertyDeep_default = basePropertyDeep;

// node_modules/lodash-es/property.js
function property(path) {
  return isKey_default(path) ? baseProperty_default(toKey_default(path)) : basePropertyDeep_default(path);
}
var property_default = property;

// node_modules/lodash-es/_baseIteratee.js
function baseIteratee(value) {
  if (typeof value == "function") {
    return value;
  }
  if (value == null) {
    return identity_default;
  }
  if (typeof value == "object") {
    return isArray_default(value) ? baseMatchesProperty_default(value[0], value[1]) : baseMatches_default(value);
  }
  return property_default(value);
}
var baseIteratee_default = baseIteratee;

// node_modules/lodash-es/_baseMap.js
function baseMap(collection, iteratee) {
  var index = -1, result = isArrayLike_default(collection) ? Array(collection.length) : [];
  baseEach_default(collection, function(value, key, collection2) {
    result[++index] = iteratee(value, key, collection2);
  });
  return result;
}
var baseMap_default = baseMap;

// node_modules/lodash-es/map.js
function map(collection, iteratee) {
  var func = isArray_default(collection) ? arrayMap_default : baseMap_default;
  return func(collection, baseIteratee_default(iteratee, 3));
}
var map_default = map;

// node_modules/react-color/es/components/block/BlockSwatches.js
var BlockSwatches = function BlockSwatches2(_ref) {
  var colors2 = _ref.colors, onClick = _ref.onClick, onSwatchHover = _ref.onSwatchHover;
  var styles = (0, import_reactcss10.default)({
    "default": {
      swatches: {
        marginRight: "-10px"
      },
      swatch: {
        width: "22px",
        height: "22px",
        float: "left",
        marginRight: "10px",
        marginBottom: "10px",
        borderRadius: "4px"
      },
      clear: {
        clear: "both"
      }
    }
  });
  return Cn.createElement(
    "div",
    { style: styles.swatches },
    map_default(colors2, function(c5) {
      return Cn.createElement(Swatch_default, {
        key: c5,
        color: c5,
        style: styles.swatch,
        onClick,
        onHover: onSwatchHover,
        focusStyle: {
          boxShadow: "0 0 4px " + c5
        }
      });
    }),
    Cn.createElement("div", { style: styles.clear })
  );
};
var BlockSwatches_default = BlockSwatches;

// node_modules/react-color/es/components/block/Block.js
var Block = function Block2(_ref) {
  var onChange = _ref.onChange, onSwatchHover = _ref.onSwatchHover, hex = _ref.hex, colors2 = _ref.colors, width = _ref.width, triangle = _ref.triangle, _ref$styles = _ref.styles, passedStyles = _ref$styles === void 0 ? {} : _ref$styles, _ref$className = _ref.className, className = _ref$className === void 0 ? "" : _ref$className;
  var transparent = hex === "transparent";
  var handleChange = function handleChange2(hexCode, e9) {
    isValidHex(hexCode) && onChange({
      hex: hexCode,
      source: "hex"
    }, e9);
  };
  var styles = (0, import_reactcss11.default)(merge_default({
    "default": {
      card: {
        width,
        background: "#fff",
        boxShadow: "0 1px rgba(0,0,0,.1)",
        borderRadius: "6px",
        position: "relative"
      },
      head: {
        height: "110px",
        background: hex,
        borderRadius: "6px 6px 0 0",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        position: "relative"
      },
      body: {
        padding: "10px"
      },
      label: {
        fontSize: "18px",
        color: getContrastingColor(hex),
        position: "relative"
      },
      triangle: {
        width: "0px",
        height: "0px",
        borderStyle: "solid",
        borderWidth: "0 10px 10px 10px",
        borderColor: "transparent transparent " + hex + " transparent",
        position: "absolute",
        top: "-10px",
        left: "50%",
        marginLeft: "-10px"
      },
      input: {
        width: "100%",
        fontSize: "12px",
        color: "#666",
        border: "0px",
        outline: "none",
        height: "22px",
        boxShadow: "inset 0 0 0 1px #ddd",
        borderRadius: "4px",
        padding: "0 7px",
        boxSizing: "border-box"
      }
    },
    "hide-triangle": {
      triangle: {
        display: "none"
      }
    }
  }, passedStyles), { "hide-triangle": triangle === "hide" });
  return Cn.createElement(
    "div",
    { style: styles.card, className: "block-picker " + className },
    Cn.createElement("div", { style: styles.triangle }),
    Cn.createElement(
      "div",
      { style: styles.head },
      transparent && Cn.createElement(Checkboard_default, { borderRadius: "6px 6px 0 0" }),
      Cn.createElement(
        "div",
        { style: styles.label },
        hex
      )
    ),
    Cn.createElement(
      "div",
      { style: styles.body },
      Cn.createElement(BlockSwatches_default, { colors: colors2, onClick: handleChange, onSwatchHover }),
      Cn.createElement(EditableInput_default, {
        style: { input: styles.input },
        value: hex,
        onChange: handleChange
      })
    )
  );
};
Block.propTypes = {
  width: import_prop_types2.default.oneOfType([import_prop_types2.default.string, import_prop_types2.default.number]),
  colors: import_prop_types2.default.arrayOf(import_prop_types2.default.string),
  triangle: import_prop_types2.default.oneOf(["top", "hide"]),
  styles: import_prop_types2.default.object
};
Block.defaultProps = {
  width: 170,
  colors: ["#D9E3F0", "#F47373", "#697689", "#37D67A", "#2CCCE4", "#555555", "#dce775", "#ff8a65", "#ba68c8"],
  triangle: "top",
  styles: {}
};
var Block_default = ColorWrap_default(Block);

// node_modules/react-color/es/components/circle/Circle.js
init_react();
var import_prop_types3 = __toESM(require_prop_types());
var import_reactcss13 = __toESM(require_lib());

// node_modules/material-colors/dist/colors.es2015.js
var red = { "50": "#ffebee", "100": "#ffcdd2", "200": "#ef9a9a", "300": "#e57373", "400": "#ef5350", "500": "#f44336", "600": "#e53935", "700": "#d32f2f", "800": "#c62828", "900": "#b71c1c", "a100": "#ff8a80", "a200": "#ff5252", "a400": "#ff1744", "a700": "#d50000" };
var pink = { "50": "#fce4ec", "100": "#f8bbd0", "200": "#f48fb1", "300": "#f06292", "400": "#ec407a", "500": "#e91e63", "600": "#d81b60", "700": "#c2185b", "800": "#ad1457", "900": "#880e4f", "a100": "#ff80ab", "a200": "#ff4081", "a400": "#f50057", "a700": "#c51162" };
var purple = { "50": "#f3e5f5", "100": "#e1bee7", "200": "#ce93d8", "300": "#ba68c8", "400": "#ab47bc", "500": "#9c27b0", "600": "#8e24aa", "700": "#7b1fa2", "800": "#6a1b9a", "900": "#4a148c", "a100": "#ea80fc", "a200": "#e040fb", "a400": "#d500f9", "a700": "#aa00ff" };
var deepPurple = { "50": "#ede7f6", "100": "#d1c4e9", "200": "#b39ddb", "300": "#9575cd", "400": "#7e57c2", "500": "#673ab7", "600": "#5e35b1", "700": "#512da8", "800": "#4527a0", "900": "#311b92", "a100": "#b388ff", "a200": "#7c4dff", "a400": "#651fff", "a700": "#6200ea" };
var indigo = { "50": "#e8eaf6", "100": "#c5cae9", "200": "#9fa8da", "300": "#7986cb", "400": "#5c6bc0", "500": "#3f51b5", "600": "#3949ab", "700": "#303f9f", "800": "#283593", "900": "#1a237e", "a100": "#8c9eff", "a200": "#536dfe", "a400": "#3d5afe", "a700": "#304ffe" };
var blue = { "50": "#e3f2fd", "100": "#bbdefb", "200": "#90caf9", "300": "#64b5f6", "400": "#42a5f5", "500": "#2196f3", "600": "#1e88e5", "700": "#1976d2", "800": "#1565c0", "900": "#0d47a1", "a100": "#82b1ff", "a200": "#448aff", "a400": "#2979ff", "a700": "#2962ff" };
var lightBlue = { "50": "#e1f5fe", "100": "#b3e5fc", "200": "#81d4fa", "300": "#4fc3f7", "400": "#29b6f6", "500": "#03a9f4", "600": "#039be5", "700": "#0288d1", "800": "#0277bd", "900": "#01579b", "a100": "#80d8ff", "a200": "#40c4ff", "a400": "#00b0ff", "a700": "#0091ea" };
var cyan = { "50": "#e0f7fa", "100": "#b2ebf2", "200": "#80deea", "300": "#4dd0e1", "400": "#26c6da", "500": "#00bcd4", "600": "#00acc1", "700": "#0097a7", "800": "#00838f", "900": "#006064", "a100": "#84ffff", "a200": "#18ffff", "a400": "#00e5ff", "a700": "#00b8d4" };
var teal = { "50": "#e0f2f1", "100": "#b2dfdb", "200": "#80cbc4", "300": "#4db6ac", "400": "#26a69a", "500": "#009688", "600": "#00897b", "700": "#00796b", "800": "#00695c", "900": "#004d40", "a100": "#a7ffeb", "a200": "#64ffda", "a400": "#1de9b6", "a700": "#00bfa5" };
var green = { "50": "#e8f5e9", "100": "#c8e6c9", "200": "#a5d6a7", "300": "#81c784", "400": "#66bb6a", "500": "#4caf50", "600": "#43a047", "700": "#388e3c", "800": "#2e7d32", "900": "#1b5e20", "a100": "#b9f6ca", "a200": "#69f0ae", "a400": "#00e676", "a700": "#00c853" };
var lightGreen = { "50": "#f1f8e9", "100": "#dcedc8", "200": "#c5e1a5", "300": "#aed581", "400": "#9ccc65", "500": "#8bc34a", "600": "#7cb342", "700": "#689f38", "800": "#558b2f", "900": "#33691e", "a100": "#ccff90", "a200": "#b2ff59", "a400": "#76ff03", "a700": "#64dd17" };
var lime = { "50": "#f9fbe7", "100": "#f0f4c3", "200": "#e6ee9c", "300": "#dce775", "400": "#d4e157", "500": "#cddc39", "600": "#c0ca33", "700": "#afb42b", "800": "#9e9d24", "900": "#827717", "a100": "#f4ff81", "a200": "#eeff41", "a400": "#c6ff00", "a700": "#aeea00" };
var yellow = { "50": "#fffde7", "100": "#fff9c4", "200": "#fff59d", "300": "#fff176", "400": "#ffee58", "500": "#ffeb3b", "600": "#fdd835", "700": "#fbc02d", "800": "#f9a825", "900": "#f57f17", "a100": "#ffff8d", "a200": "#ffff00", "a400": "#ffea00", "a700": "#ffd600" };
var amber = { "50": "#fff8e1", "100": "#ffecb3", "200": "#ffe082", "300": "#ffd54f", "400": "#ffca28", "500": "#ffc107", "600": "#ffb300", "700": "#ffa000", "800": "#ff8f00", "900": "#ff6f00", "a100": "#ffe57f", "a200": "#ffd740", "a400": "#ffc400", "a700": "#ffab00" };
var orange = { "50": "#fff3e0", "100": "#ffe0b2", "200": "#ffcc80", "300": "#ffb74d", "400": "#ffa726", "500": "#ff9800", "600": "#fb8c00", "700": "#f57c00", "800": "#ef6c00", "900": "#e65100", "a100": "#ffd180", "a200": "#ffab40", "a400": "#ff9100", "a700": "#ff6d00" };
var deepOrange = { "50": "#fbe9e7", "100": "#ffccbc", "200": "#ffab91", "300": "#ff8a65", "400": "#ff7043", "500": "#ff5722", "600": "#f4511e", "700": "#e64a19", "800": "#d84315", "900": "#bf360c", "a100": "#ff9e80", "a200": "#ff6e40", "a400": "#ff3d00", "a700": "#dd2c00" };
var brown = { "50": "#efebe9", "100": "#d7ccc8", "200": "#bcaaa4", "300": "#a1887f", "400": "#8d6e63", "500": "#795548", "600": "#6d4c41", "700": "#5d4037", "800": "#4e342e", "900": "#3e2723" };
var blueGrey = { "50": "#eceff1", "100": "#cfd8dc", "200": "#b0bec5", "300": "#90a4ae", "400": "#78909c", "500": "#607d8b", "600": "#546e7a", "700": "#455a64", "800": "#37474f", "900": "#263238" };

// node_modules/react-color/es/components/circle/CircleSwatch.js
init_react();
var import_reactcss12 = __toESM(require_lib());
var CircleSwatch = function CircleSwatch2(_ref) {
  var color = _ref.color, onClick = _ref.onClick, onSwatchHover = _ref.onSwatchHover, hover = _ref.hover, active = _ref.active, circleSize = _ref.circleSize, circleSpacing = _ref.circleSpacing;
  var styles = (0, import_reactcss12.default)({
    "default": {
      swatch: {
        width: circleSize,
        height: circleSize,
        marginRight: circleSpacing,
        marginBottom: circleSpacing,
        transform: "scale(1)",
        transition: "100ms transform ease"
      },
      Swatch: {
        borderRadius: "50%",
        background: "transparent",
        boxShadow: "inset 0 0 0 " + (circleSize / 2 + 1) + "px " + color,
        transition: "100ms box-shadow ease"
      }
    },
    "hover": {
      swatch: {
        transform: "scale(1.2)"
      }
    },
    "active": {
      Swatch: {
        boxShadow: "inset 0 0 0 3px " + color
      }
    }
  }, { hover, active });
  return Cn.createElement(
    "div",
    { style: styles.swatch },
    Cn.createElement(Swatch_default, {
      style: styles.Swatch,
      color,
      onClick,
      onHover: onSwatchHover,
      focusStyle: { boxShadow: styles.Swatch.boxShadow + ", 0 0 5px " + color }
    })
  );
};
CircleSwatch.defaultProps = {
  circleSize: 28,
  circleSpacing: 14
};
var CircleSwatch_default = (0, import_reactcss12.handleHover)(CircleSwatch);

// node_modules/react-color/es/components/circle/Circle.js
var Circle = function Circle2(_ref) {
  var width = _ref.width, onChange = _ref.onChange, onSwatchHover = _ref.onSwatchHover, colors2 = _ref.colors, hex = _ref.hex, circleSize = _ref.circleSize, _ref$styles = _ref.styles, passedStyles = _ref$styles === void 0 ? {} : _ref$styles, circleSpacing = _ref.circleSpacing, _ref$className = _ref.className, className = _ref$className === void 0 ? "" : _ref$className;
  var styles = (0, import_reactcss13.default)(merge_default({
    "default": {
      card: {
        width,
        display: "flex",
        flexWrap: "wrap",
        marginRight: -circleSpacing,
        marginBottom: -circleSpacing
      }
    }
  }, passedStyles));
  var handleChange = function handleChange2(hexCode, e9) {
    return onChange({ hex: hexCode, source: "hex" }, e9);
  };
  return Cn.createElement(
    "div",
    { style: styles.card, className: "circle-picker " + className },
    map_default(colors2, function(c5) {
      return Cn.createElement(CircleSwatch_default, {
        key: c5,
        color: c5,
        onClick: handleChange,
        onSwatchHover,
        active: hex === c5.toLowerCase(),
        circleSize,
        circleSpacing
      });
    })
  );
};
Circle.propTypes = {
  width: import_prop_types3.default.oneOfType([import_prop_types3.default.string, import_prop_types3.default.number]),
  circleSize: import_prop_types3.default.number,
  circleSpacing: import_prop_types3.default.number,
  styles: import_prop_types3.default.object
};
Circle.defaultProps = {
  width: 252,
  circleSize: 28,
  circleSpacing: 14,
  colors: [red["500"], pink["500"], purple["500"], deepPurple["500"], indigo["500"], blue["500"], lightBlue["500"], cyan["500"], teal["500"], green["500"], lightGreen["500"], lime["500"], yellow["500"], amber["500"], orange["500"], deepOrange["500"], brown["500"], blueGrey["500"]],
  styles: {}
};
var Circle_default = ColorWrap_default(Circle);

// node_modules/react-color/es/components/chrome/Chrome.js
init_react();
var import_prop_types4 = __toESM(require_prop_types());
var import_reactcss17 = __toESM(require_lib());

// node_modules/react-color/es/components/chrome/ChromeFields.js
init_react();
var import_reactcss14 = __toESM(require_lib());

// node_modules/lodash-es/isUndefined.js
function isUndefined(value) {
  return value === void 0;
}
var isUndefined_default = isUndefined;

// node_modules/react-color/es/components/chrome/ChromeFields.js
var import_UnfoldMoreHorizontalIcon = __toESM(require_UnfoldMoreHorizontalIcon());
var _createClass7 = function() {
  function defineProperties(target, props) {
    for (var i6 = 0; i6 < props.length; i6++) {
      var descriptor = props[i6];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor)
        descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }
  return function(Constructor, protoProps, staticProps) {
    if (protoProps)
      defineProperties(Constructor.prototype, protoProps);
    if (staticProps)
      defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();
function _classCallCheck7(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _possibleConstructorReturn7(self2, call) {
  if (!self2) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return call && (typeof call === "object" || typeof call === "function") ? call : self2;
}
function _inherits7(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
  if (superClass)
    Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
}
var ChromeFields = function(_React$Component) {
  _inherits7(ChromeFields2, _React$Component);
  function ChromeFields2(props) {
    _classCallCheck7(this, ChromeFields2);
    var _this = _possibleConstructorReturn7(this, (ChromeFields2.__proto__ || Object.getPrototypeOf(ChromeFields2)).call(this));
    _this.toggleViews = function() {
      if (_this.state.view === "hex") {
        _this.setState({ view: "rgb" });
      } else if (_this.state.view === "rgb") {
        _this.setState({ view: "hsl" });
      } else if (_this.state.view === "hsl") {
        if (_this.props.hsl.a === 1) {
          _this.setState({ view: "hex" });
        } else {
          _this.setState({ view: "rgb" });
        }
      }
    };
    _this.handleChange = function(data, e9) {
      if (data.hex) {
        isValidHex(data.hex) && _this.props.onChange({
          hex: data.hex,
          source: "hex"
        }, e9);
      } else if (data.r || data.g || data.b) {
        _this.props.onChange({
          r: data.r || _this.props.rgb.r,
          g: data.g || _this.props.rgb.g,
          b: data.b || _this.props.rgb.b,
          source: "rgb"
        }, e9);
      } else if (data.a) {
        if (data.a < 0) {
          data.a = 0;
        } else if (data.a > 1) {
          data.a = 1;
        }
        _this.props.onChange({
          h: _this.props.hsl.h,
          s: _this.props.hsl.s,
          l: _this.props.hsl.l,
          a: Math.round(data.a * 100) / 100,
          source: "rgb"
        }, e9);
      } else if (data.h || data.s || data.l) {
        if (typeof data.s === "string" && data.s.includes("%")) {
          data.s = data.s.replace("%", "");
        }
        if (typeof data.l === "string" && data.l.includes("%")) {
          data.l = data.l.replace("%", "");
        }
        if (data.s == 1) {
          data.s = 0.01;
        } else if (data.l == 1) {
          data.l = 0.01;
        }
        _this.props.onChange({
          h: data.h || _this.props.hsl.h,
          s: Number(!isUndefined_default(data.s) ? data.s : _this.props.hsl.s),
          l: Number(!isUndefined_default(data.l) ? data.l : _this.props.hsl.l),
          source: "hsl"
        }, e9);
      }
    };
    _this.showHighlight = function(e9) {
      e9.currentTarget.style.background = "#eee";
    };
    _this.hideHighlight = function(e9) {
      e9.currentTarget.style.background = "transparent";
    };
    if (props.hsl.a !== 1 && props.view === "hex") {
      _this.state = {
        view: "rgb"
      };
    } else {
      _this.state = {
        view: props.view
      };
    }
    return _this;
  }
  _createClass7(ChromeFields2, [{
    key: "render",
    value: function render3() {
      var _this2 = this;
      var styles = (0, import_reactcss14.default)({
        "default": {
          wrap: {
            paddingTop: "16px",
            display: "flex"
          },
          fields: {
            flex: "1",
            display: "flex",
            marginLeft: "-6px"
          },
          field: {
            paddingLeft: "6px",
            width: "100%"
          },
          alpha: {
            paddingLeft: "6px",
            width: "100%"
          },
          toggle: {
            width: "32px",
            textAlign: "right",
            position: "relative"
          },
          icon: {
            marginRight: "-4px",
            marginTop: "12px",
            cursor: "pointer",
            position: "relative"
          },
          iconHighlight: {
            position: "absolute",
            width: "24px",
            height: "28px",
            background: "#eee",
            borderRadius: "4px",
            top: "10px",
            left: "12px",
            display: "none"
          },
          input: {
            fontSize: "11px",
            color: "#333",
            width: "100%",
            borderRadius: "2px",
            border: "none",
            boxShadow: "inset 0 0 0 1px #dadada",
            height: "21px",
            textAlign: "center"
          },
          label: {
            textTransform: "uppercase",
            fontSize: "11px",
            lineHeight: "11px",
            color: "#969696",
            textAlign: "center",
            display: "block",
            marginTop: "12px"
          },
          svg: {
            fill: "#333",
            width: "24px",
            height: "24px",
            border: "1px transparent solid",
            borderRadius: "5px"
          }
        },
        "disableAlpha": {
          alpha: {
            display: "none"
          }
        }
      }, this.props, this.state);
      var fields = void 0;
      if (this.state.view === "hex") {
        fields = Cn.createElement(
          "div",
          { style: styles.fields, className: "flexbox-fix" },
          Cn.createElement(
            "div",
            { style: styles.field },
            Cn.createElement(EditableInput_default, {
              style: { input: styles.input, label: styles.label },
              label: "hex",
              value: this.props.hex,
              onChange: this.handleChange
            })
          )
        );
      } else if (this.state.view === "rgb") {
        fields = Cn.createElement(
          "div",
          { style: styles.fields, className: "flexbox-fix" },
          Cn.createElement(
            "div",
            { style: styles.field },
            Cn.createElement(EditableInput_default, {
              style: { input: styles.input, label: styles.label },
              label: "r",
              value: this.props.rgb.r,
              onChange: this.handleChange
            })
          ),
          Cn.createElement(
            "div",
            { style: styles.field },
            Cn.createElement(EditableInput_default, {
              style: { input: styles.input, label: styles.label },
              label: "g",
              value: this.props.rgb.g,
              onChange: this.handleChange
            })
          ),
          Cn.createElement(
            "div",
            { style: styles.field },
            Cn.createElement(EditableInput_default, {
              style: { input: styles.input, label: styles.label },
              label: "b",
              value: this.props.rgb.b,
              onChange: this.handleChange
            })
          ),
          Cn.createElement(
            "div",
            { style: styles.alpha },
            Cn.createElement(EditableInput_default, {
              style: { input: styles.input, label: styles.label },
              label: "a",
              value: this.props.rgb.a,
              arrowOffset: 0.01,
              onChange: this.handleChange
            })
          )
        );
      } else if (this.state.view === "hsl") {
        fields = Cn.createElement(
          "div",
          { style: styles.fields, className: "flexbox-fix" },
          Cn.createElement(
            "div",
            { style: styles.field },
            Cn.createElement(EditableInput_default, {
              style: { input: styles.input, label: styles.label },
              label: "h",
              value: Math.round(this.props.hsl.h),
              onChange: this.handleChange
            })
          ),
          Cn.createElement(
            "div",
            { style: styles.field },
            Cn.createElement(EditableInput_default, {
              style: { input: styles.input, label: styles.label },
              label: "s",
              value: Math.round(this.props.hsl.s * 100) + "%",
              onChange: this.handleChange
            })
          ),
          Cn.createElement(
            "div",
            { style: styles.field },
            Cn.createElement(EditableInput_default, {
              style: { input: styles.input, label: styles.label },
              label: "l",
              value: Math.round(this.props.hsl.l * 100) + "%",
              onChange: this.handleChange
            })
          ),
          Cn.createElement(
            "div",
            { style: styles.alpha },
            Cn.createElement(EditableInput_default, {
              style: { input: styles.input, label: styles.label },
              label: "a",
              value: this.props.hsl.a,
              arrowOffset: 0.01,
              onChange: this.handleChange
            })
          )
        );
      }
      return Cn.createElement(
        "div",
        { style: styles.wrap, className: "flexbox-fix" },
        fields,
        Cn.createElement(
          "div",
          { style: styles.toggle },
          Cn.createElement(
            "div",
            { style: styles.icon, onClick: this.toggleViews, ref: function ref(icon) {
              return _this2.icon = icon;
            } },
            Cn.createElement(import_UnfoldMoreHorizontalIcon.default, {
              style: styles.svg,
              onMouseOver: this.showHighlight,
              onMouseEnter: this.showHighlight,
              onMouseOut: this.hideHighlight
            })
          )
        )
      );
    }
  }], [{
    key: "getDerivedStateFromProps",
    value: function getDerivedStateFromProps(nextProps, state) {
      if (nextProps.hsl.a !== 1 && state.view === "hex") {
        return { view: "rgb" };
      }
      return null;
    }
  }]);
  return ChromeFields2;
}(Cn.Component);
ChromeFields.defaultProps = {
  view: "hex"
};
var ChromeFields_default = ChromeFields;

// node_modules/react-color/es/components/chrome/ChromePointer.js
init_react();
var import_reactcss15 = __toESM(require_lib());
var ChromePointer = function ChromePointer2() {
  var styles = (0, import_reactcss15.default)({
    "default": {
      picker: {
        width: "12px",
        height: "12px",
        borderRadius: "6px",
        transform: "translate(-6px, -1px)",
        backgroundColor: "rgb(248, 248, 248)",
        boxShadow: "0 1px 4px 0 rgba(0, 0, 0, 0.37)"
      }
    }
  });
  return Cn.createElement("div", { style: styles.picker });
};
var ChromePointer_default = ChromePointer;

// node_modules/react-color/es/components/chrome/ChromePointerCircle.js
init_react();
var import_reactcss16 = __toESM(require_lib());
var ChromePointerCircle = function ChromePointerCircle2() {
  var styles = (0, import_reactcss16.default)({
    "default": {
      picker: {
        width: "12px",
        height: "12px",
        borderRadius: "6px",
        boxShadow: "inset 0 0 0 1px #fff",
        transform: "translate(-6px, -6px)"
      }
    }
  });
  return Cn.createElement("div", { style: styles.picker });
};
var ChromePointerCircle_default = ChromePointerCircle;

// node_modules/react-color/es/components/chrome/Chrome.js
var Chrome = function Chrome2(_ref) {
  var width = _ref.width, onChange = _ref.onChange, disableAlpha = _ref.disableAlpha, rgb = _ref.rgb, hsl = _ref.hsl, hsv = _ref.hsv, hex = _ref.hex, renderers = _ref.renderers, _ref$styles = _ref.styles, passedStyles = _ref$styles === void 0 ? {} : _ref$styles, _ref$className = _ref.className, className = _ref$className === void 0 ? "" : _ref$className, defaultView = _ref.defaultView;
  var styles = (0, import_reactcss17.default)(merge_default({
    "default": {
      picker: {
        width,
        background: "#fff",
        borderRadius: "2px",
        boxShadow: "0 0 2px rgba(0,0,0,.3), 0 4px 8px rgba(0,0,0,.3)",
        boxSizing: "initial",
        fontFamily: "Menlo"
      },
      saturation: {
        width: "100%",
        paddingBottom: "55%",
        position: "relative",
        borderRadius: "2px 2px 0 0",
        overflow: "hidden"
      },
      Saturation: {
        radius: "2px 2px 0 0"
      },
      body: {
        padding: "16px 16px 12px"
      },
      controls: {
        display: "flex"
      },
      color: {
        width: "32px"
      },
      swatch: {
        marginTop: "6px",
        width: "16px",
        height: "16px",
        borderRadius: "8px",
        position: "relative",
        overflow: "hidden"
      },
      active: {
        absolute: "0px 0px 0px 0px",
        borderRadius: "8px",
        boxShadow: "inset 0 0 0 1px rgba(0,0,0,.1)",
        background: "rgba(" + rgb.r + ", " + rgb.g + ", " + rgb.b + ", " + rgb.a + ")",
        zIndex: "2"
      },
      toggles: {
        flex: "1"
      },
      hue: {
        height: "10px",
        position: "relative",
        marginBottom: "8px"
      },
      Hue: {
        radius: "2px"
      },
      alpha: {
        height: "10px",
        position: "relative"
      },
      Alpha: {
        radius: "2px"
      }
    },
    "disableAlpha": {
      color: {
        width: "22px"
      },
      alpha: {
        display: "none"
      },
      hue: {
        marginBottom: "0px"
      },
      swatch: {
        width: "10px",
        height: "10px",
        marginTop: "0px"
      }
    }
  }, passedStyles), { disableAlpha });
  return Cn.createElement(
    "div",
    { style: styles.picker, className: "chrome-picker " + className },
    Cn.createElement(
      "div",
      { style: styles.saturation },
      Cn.createElement(Saturation_default, {
        style: styles.Saturation,
        hsl,
        hsv,
        pointer: ChromePointerCircle_default,
        onChange
      })
    ),
    Cn.createElement(
      "div",
      { style: styles.body },
      Cn.createElement(
        "div",
        { style: styles.controls, className: "flexbox-fix" },
        Cn.createElement(
          "div",
          { style: styles.color },
          Cn.createElement(
            "div",
            { style: styles.swatch },
            Cn.createElement("div", { style: styles.active }),
            Cn.createElement(Checkboard_default, { renderers })
          )
        ),
        Cn.createElement(
          "div",
          { style: styles.toggles },
          Cn.createElement(
            "div",
            { style: styles.hue },
            Cn.createElement(Hue_default, {
              style: styles.Hue,
              hsl,
              pointer: ChromePointer_default,
              onChange
            })
          ),
          Cn.createElement(
            "div",
            { style: styles.alpha },
            Cn.createElement(Alpha_default, {
              style: styles.Alpha,
              rgb,
              hsl,
              pointer: ChromePointer_default,
              renderers,
              onChange
            })
          )
        )
      ),
      Cn.createElement(ChromeFields_default, {
        rgb,
        hsl,
        hex,
        view: defaultView,
        onChange,
        disableAlpha
      })
    )
  );
};
Chrome.propTypes = {
  width: import_prop_types4.default.oneOfType([import_prop_types4.default.string, import_prop_types4.default.number]),
  disableAlpha: import_prop_types4.default.bool,
  styles: import_prop_types4.default.object,
  defaultView: import_prop_types4.default.oneOf(["hex", "rgb", "hsl"])
};
Chrome.defaultProps = {
  width: 225,
  disableAlpha: false,
  styles: {}
};
var Chrome_default = ColorWrap_default(Chrome);

// node_modules/react-color/es/components/compact/Compact.js
init_react();
var import_prop_types5 = __toESM(require_prop_types());
var import_reactcss20 = __toESM(require_lib());

// node_modules/react-color/es/components/compact/CompactColor.js
init_react();
var import_reactcss18 = __toESM(require_lib());
var CompactColor = function CompactColor2(_ref) {
  var color = _ref.color, _ref$onClick = _ref.onClick, onClick = _ref$onClick === void 0 ? function() {
  } : _ref$onClick, onSwatchHover = _ref.onSwatchHover, active = _ref.active;
  var styles = (0, import_reactcss18.default)({
    "default": {
      color: {
        background: color,
        width: "15px",
        height: "15px",
        float: "left",
        marginRight: "5px",
        marginBottom: "5px",
        position: "relative",
        cursor: "pointer"
      },
      dot: {
        absolute: "5px 5px 5px 5px",
        background: getContrastingColor(color),
        borderRadius: "50%",
        opacity: "0"
      }
    },
    "active": {
      dot: {
        opacity: "1"
      }
    },
    "color-#FFFFFF": {
      color: {
        boxShadow: "inset 0 0 0 1px #ddd"
      },
      dot: {
        background: "#000"
      }
    },
    "transparent": {
      dot: {
        background: "#000"
      }
    }
  }, { active, "color-#FFFFFF": color === "#FFFFFF", "transparent": color === "transparent" });
  return Cn.createElement(
    Swatch_default,
    {
      style: styles.color,
      color,
      onClick,
      onHover: onSwatchHover,
      focusStyle: { boxShadow: "0 0 4px " + color }
    },
    Cn.createElement("div", { style: styles.dot })
  );
};
var CompactColor_default = CompactColor;

// node_modules/react-color/es/components/compact/CompactFields.js
init_react();
var import_reactcss19 = __toESM(require_lib());
var CompactFields = function CompactFields2(_ref) {
  var hex = _ref.hex, rgb = _ref.rgb, onChange = _ref.onChange;
  var styles = (0, import_reactcss19.default)({
    "default": {
      fields: {
        display: "flex",
        paddingBottom: "6px",
        paddingRight: "5px",
        position: "relative"
      },
      active: {
        position: "absolute",
        top: "6px",
        left: "5px",
        height: "9px",
        width: "9px",
        background: hex
      },
      HEXwrap: {
        flex: "6",
        position: "relative"
      },
      HEXinput: {
        width: "80%",
        padding: "0px",
        paddingLeft: "20%",
        border: "none",
        outline: "none",
        background: "none",
        fontSize: "12px",
        color: "#333",
        height: "16px"
      },
      HEXlabel: {
        display: "none"
      },
      RGBwrap: {
        flex: "3",
        position: "relative"
      },
      RGBinput: {
        width: "70%",
        padding: "0px",
        paddingLeft: "30%",
        border: "none",
        outline: "none",
        background: "none",
        fontSize: "12px",
        color: "#333",
        height: "16px"
      },
      RGBlabel: {
        position: "absolute",
        top: "3px",
        left: "0px",
        lineHeight: "16px",
        textTransform: "uppercase",
        fontSize: "12px",
        color: "#999"
      }
    }
  });
  var handleChange = function handleChange2(data, e9) {
    if (data.r || data.g || data.b) {
      onChange({
        r: data.r || rgb.r,
        g: data.g || rgb.g,
        b: data.b || rgb.b,
        source: "rgb"
      }, e9);
    } else {
      onChange({
        hex: data.hex,
        source: "hex"
      }, e9);
    }
  };
  return Cn.createElement(
    "div",
    { style: styles.fields, className: "flexbox-fix" },
    Cn.createElement("div", { style: styles.active }),
    Cn.createElement(EditableInput_default, {
      style: { wrap: styles.HEXwrap, input: styles.HEXinput, label: styles.HEXlabel },
      label: "hex",
      value: hex,
      onChange: handleChange
    }),
    Cn.createElement(EditableInput_default, {
      style: { wrap: styles.RGBwrap, input: styles.RGBinput, label: styles.RGBlabel },
      label: "r",
      value: rgb.r,
      onChange: handleChange
    }),
    Cn.createElement(EditableInput_default, {
      style: { wrap: styles.RGBwrap, input: styles.RGBinput, label: styles.RGBlabel },
      label: "g",
      value: rgb.g,
      onChange: handleChange
    }),
    Cn.createElement(EditableInput_default, {
      style: { wrap: styles.RGBwrap, input: styles.RGBinput, label: styles.RGBlabel },
      label: "b",
      value: rgb.b,
      onChange: handleChange
    })
  );
};
var CompactFields_default = CompactFields;

// node_modules/react-color/es/components/compact/Compact.js
var Compact = function Compact2(_ref) {
  var onChange = _ref.onChange, onSwatchHover = _ref.onSwatchHover, colors2 = _ref.colors, hex = _ref.hex, rgb = _ref.rgb, _ref$styles = _ref.styles, passedStyles = _ref$styles === void 0 ? {} : _ref$styles, _ref$className = _ref.className, className = _ref$className === void 0 ? "" : _ref$className;
  var styles = (0, import_reactcss20.default)(merge_default({
    "default": {
      Compact: {
        background: "#f6f6f6",
        radius: "4px"
      },
      compact: {
        paddingTop: "5px",
        paddingLeft: "5px",
        boxSizing: "initial",
        width: "240px"
      },
      clear: {
        clear: "both"
      }
    }
  }, passedStyles));
  var handleChange = function handleChange2(data, e9) {
    if (data.hex) {
      isValidHex(data.hex) && onChange({
        hex: data.hex,
        source: "hex"
      }, e9);
    } else {
      onChange(data, e9);
    }
  };
  return Cn.createElement(
    Raised_default,
    { style: styles.Compact, styles: passedStyles },
    Cn.createElement(
      "div",
      { style: styles.compact, className: "compact-picker " + className },
      Cn.createElement(
        "div",
        null,
        map_default(colors2, function(c5) {
          return Cn.createElement(CompactColor_default, {
            key: c5,
            color: c5,
            active: c5.toLowerCase() === hex,
            onClick: handleChange,
            onSwatchHover
          });
        }),
        Cn.createElement("div", { style: styles.clear })
      ),
      Cn.createElement(CompactFields_default, { hex, rgb, onChange: handleChange })
    )
  );
};
Compact.propTypes = {
  colors: import_prop_types5.default.arrayOf(import_prop_types5.default.string),
  styles: import_prop_types5.default.object
};
Compact.defaultProps = {
  colors: ["#4D4D4D", "#999999", "#FFFFFF", "#F44E3B", "#FE9200", "#FCDC00", "#DBDF00", "#A4DD00", "#68CCCA", "#73D8FF", "#AEA1FF", "#FDA1FF", "#333333", "#808080", "#cccccc", "#D33115", "#E27300", "#FCC400", "#B0BC00", "#68BC00", "#16A5A5", "#009CE0", "#7B64FF", "#FA28FF", "#000000", "#666666", "#B3B3B3", "#9F0500", "#C45100", "#FB9E00", "#808900", "#194D33", "#0C797D", "#0062B1", "#653294", "#AB149E"],
  styles: {}
};
var Compact_default = ColorWrap_default(Compact);

// node_modules/react-color/es/components/github/Github.js
init_react();
var import_prop_types6 = __toESM(require_prop_types());
var import_reactcss22 = __toESM(require_lib());

// node_modules/react-color/es/components/github/GithubSwatch.js
init_react();
var import_reactcss21 = __toESM(require_lib());
var GithubSwatch = function GithubSwatch2(_ref) {
  var hover = _ref.hover, color = _ref.color, onClick = _ref.onClick, onSwatchHover = _ref.onSwatchHover;
  var hoverSwatch = {
    position: "relative",
    zIndex: "2",
    outline: "2px solid #fff",
    boxShadow: "0 0 5px 2px rgba(0,0,0,0.25)"
  };
  var styles = (0, import_reactcss21.default)({
    "default": {
      swatch: {
        width: "25px",
        height: "25px",
        fontSize: "0"
      }
    },
    "hover": {
      swatch: hoverSwatch
    }
  }, { hover });
  return Cn.createElement(
    "div",
    { style: styles.swatch },
    Cn.createElement(Swatch_default, {
      color,
      onClick,
      onHover: onSwatchHover,
      focusStyle: hoverSwatch
    })
  );
};
var GithubSwatch_default = (0, import_reactcss21.handleHover)(GithubSwatch);

// node_modules/react-color/es/components/github/Github.js
var Github = function Github2(_ref) {
  var width = _ref.width, colors2 = _ref.colors, onChange = _ref.onChange, onSwatchHover = _ref.onSwatchHover, triangle = _ref.triangle, _ref$styles = _ref.styles, passedStyles = _ref$styles === void 0 ? {} : _ref$styles, _ref$className = _ref.className, className = _ref$className === void 0 ? "" : _ref$className;
  var styles = (0, import_reactcss22.default)(merge_default({
    "default": {
      card: {
        width,
        background: "#fff",
        border: "1px solid rgba(0,0,0,0.2)",
        boxShadow: "0 3px 12px rgba(0,0,0,0.15)",
        borderRadius: "4px",
        position: "relative",
        padding: "5px",
        display: "flex",
        flexWrap: "wrap"
      },
      triangle: {
        position: "absolute",
        border: "7px solid transparent",
        borderBottomColor: "#fff"
      },
      triangleShadow: {
        position: "absolute",
        border: "8px solid transparent",
        borderBottomColor: "rgba(0,0,0,0.15)"
      }
    },
    "hide-triangle": {
      triangle: {
        display: "none"
      },
      triangleShadow: {
        display: "none"
      }
    },
    "top-left-triangle": {
      triangle: {
        top: "-14px",
        left: "10px"
      },
      triangleShadow: {
        top: "-16px",
        left: "9px"
      }
    },
    "top-right-triangle": {
      triangle: {
        top: "-14px",
        right: "10px"
      },
      triangleShadow: {
        top: "-16px",
        right: "9px"
      }
    },
    "bottom-left-triangle": {
      triangle: {
        top: "35px",
        left: "10px",
        transform: "rotate(180deg)"
      },
      triangleShadow: {
        top: "37px",
        left: "9px",
        transform: "rotate(180deg)"
      }
    },
    "bottom-right-triangle": {
      triangle: {
        top: "35px",
        right: "10px",
        transform: "rotate(180deg)"
      },
      triangleShadow: {
        top: "37px",
        right: "9px",
        transform: "rotate(180deg)"
      }
    }
  }, passedStyles), {
    "hide-triangle": triangle === "hide",
    "top-left-triangle": triangle === "top-left",
    "top-right-triangle": triangle === "top-right",
    "bottom-left-triangle": triangle === "bottom-left",
    "bottom-right-triangle": triangle === "bottom-right"
  });
  var handleChange = function handleChange2(hex, e9) {
    return onChange({ hex, source: "hex" }, e9);
  };
  return Cn.createElement(
    "div",
    { style: styles.card, className: "github-picker " + className },
    Cn.createElement("div", { style: styles.triangleShadow }),
    Cn.createElement("div", { style: styles.triangle }),
    map_default(colors2, function(c5) {
      return Cn.createElement(GithubSwatch_default, {
        color: c5,
        key: c5,
        onClick: handleChange,
        onSwatchHover
      });
    })
  );
};
Github.propTypes = {
  width: import_prop_types6.default.oneOfType([import_prop_types6.default.string, import_prop_types6.default.number]),
  colors: import_prop_types6.default.arrayOf(import_prop_types6.default.string),
  triangle: import_prop_types6.default.oneOf(["hide", "top-left", "top-right", "bottom-left", "bottom-right"]),
  styles: import_prop_types6.default.object
};
Github.defaultProps = {
  width: 200,
  colors: ["#B80000", "#DB3E00", "#FCCB00", "#008B02", "#006B76", "#1273DE", "#004DCF", "#5300EB", "#EB9694", "#FAD0C3", "#FEF3BD", "#C1E1C5", "#BEDADC", "#C4DEF6", "#BED3F3", "#D4C4FB"],
  triangle: "top-left",
  styles: {}
};
var Github_default = ColorWrap_default(Github);

// node_modules/react-color/es/components/hue/Hue.js
init_react();
var import_prop_types7 = __toESM(require_prop_types());
var import_reactcss24 = __toESM(require_lib());

// node_modules/react-color/es/components/hue/HuePointer.js
init_react();
var import_reactcss23 = __toESM(require_lib());
var SliderPointer = function SliderPointer2(_ref) {
  var direction = _ref.direction;
  var styles = (0, import_reactcss23.default)({
    "default": {
      picker: {
        width: "18px",
        height: "18px",
        borderRadius: "50%",
        transform: "translate(-9px, -1px)",
        backgroundColor: "rgb(248, 248, 248)",
        boxShadow: "0 1px 4px 0 rgba(0, 0, 0, 0.37)"
      }
    },
    "vertical": {
      picker: {
        transform: "translate(-3px, -9px)"
      }
    }
  }, { vertical: direction === "vertical" });
  return Cn.createElement("div", { style: styles.picker });
};
var HuePointer_default = SliderPointer;

// node_modules/react-color/es/components/hue/Hue.js
var _extends7 = Object.assign || function(target) {
  for (var i6 = 1; i6 < arguments.length; i6++) {
    var source = arguments[i6];
    for (var key in source) {
      if (Object.prototype.hasOwnProperty.call(source, key)) {
        target[key] = source[key];
      }
    }
  }
  return target;
};
var HuePicker = function HuePicker2(_ref) {
  var width = _ref.width, height = _ref.height, onChange = _ref.onChange, hsl = _ref.hsl, direction = _ref.direction, pointer = _ref.pointer, _ref$styles = _ref.styles, passedStyles = _ref$styles === void 0 ? {} : _ref$styles, _ref$className = _ref.className, className = _ref$className === void 0 ? "" : _ref$className;
  var styles = (0, import_reactcss24.default)(merge_default({
    "default": {
      picker: {
        position: "relative",
        width,
        height
      },
      hue: {
        radius: "2px"
      }
    }
  }, passedStyles));
  var handleChange = function handleChange2(data) {
    return onChange({ a: 1, h: data.h, l: 0.5, s: 1 });
  };
  return Cn.createElement(
    "div",
    { style: styles.picker, className: "hue-picker " + className },
    Cn.createElement(Hue_default, _extends7({}, styles.hue, {
      hsl,
      pointer,
      onChange: handleChange,
      direction
    }))
  );
};
HuePicker.propTypes = {
  styles: import_prop_types7.default.object
};
HuePicker.defaultProps = {
  width: "316px",
  height: "16px",
  direction: "horizontal",
  pointer: HuePointer_default,
  styles: {}
};
var Hue_default2 = ColorWrap_default(HuePicker);

// node_modules/react-color/es/components/material/Material.js
init_react();
var import_reactcss25 = __toESM(require_lib());
var Material = function Material2(_ref) {
  var onChange = _ref.onChange, hex = _ref.hex, rgb = _ref.rgb, _ref$styles = _ref.styles, passedStyles = _ref$styles === void 0 ? {} : _ref$styles, _ref$className = _ref.className, className = _ref$className === void 0 ? "" : _ref$className;
  var styles = (0, import_reactcss25.default)(merge_default({
    "default": {
      material: {
        width: "98px",
        height: "98px",
        padding: "16px",
        fontFamily: "Roboto"
      },
      HEXwrap: {
        position: "relative"
      },
      HEXinput: {
        width: "100%",
        marginTop: "12px",
        fontSize: "15px",
        color: "#333",
        padding: "0px",
        border: "0px",
        borderBottom: "2px solid " + hex,
        outline: "none",
        height: "30px"
      },
      HEXlabel: {
        position: "absolute",
        top: "0px",
        left: "0px",
        fontSize: "11px",
        color: "#999999",
        textTransform: "capitalize"
      },
      Hex: {
        style: {}
      },
      RGBwrap: {
        position: "relative"
      },
      RGBinput: {
        width: "100%",
        marginTop: "12px",
        fontSize: "15px",
        color: "#333",
        padding: "0px",
        border: "0px",
        borderBottom: "1px solid #eee",
        outline: "none",
        height: "30px"
      },
      RGBlabel: {
        position: "absolute",
        top: "0px",
        left: "0px",
        fontSize: "11px",
        color: "#999999",
        textTransform: "capitalize"
      },
      split: {
        display: "flex",
        marginRight: "-10px",
        paddingTop: "11px"
      },
      third: {
        flex: "1",
        paddingRight: "10px"
      }
    }
  }, passedStyles));
  var handleChange = function handleChange2(data, e9) {
    if (data.hex) {
      isValidHex(data.hex) && onChange({
        hex: data.hex,
        source: "hex"
      }, e9);
    } else if (data.r || data.g || data.b) {
      onChange({
        r: data.r || rgb.r,
        g: data.g || rgb.g,
        b: data.b || rgb.b,
        source: "rgb"
      }, e9);
    }
  };
  return Cn.createElement(
    Raised_default,
    { styles: passedStyles },
    Cn.createElement(
      "div",
      { style: styles.material, className: "material-picker " + className },
      Cn.createElement(EditableInput_default, {
        style: { wrap: styles.HEXwrap, input: styles.HEXinput, label: styles.HEXlabel },
        label: "hex",
        value: hex,
        onChange: handleChange
      }),
      Cn.createElement(
        "div",
        { style: styles.split, className: "flexbox-fix" },
        Cn.createElement(
          "div",
          { style: styles.third },
          Cn.createElement(EditableInput_default, {
            style: { wrap: styles.RGBwrap, input: styles.RGBinput, label: styles.RGBlabel },
            label: "r",
            value: rgb.r,
            onChange: handleChange
          })
        ),
        Cn.createElement(
          "div",
          { style: styles.third },
          Cn.createElement(EditableInput_default, {
            style: { wrap: styles.RGBwrap, input: styles.RGBinput, label: styles.RGBlabel },
            label: "g",
            value: rgb.g,
            onChange: handleChange
          })
        ),
        Cn.createElement(
          "div",
          { style: styles.third },
          Cn.createElement(EditableInput_default, {
            style: { wrap: styles.RGBwrap, input: styles.RGBinput, label: styles.RGBlabel },
            label: "b",
            value: rgb.b,
            onChange: handleChange
          })
        )
      )
    )
  );
};
var Material_default = ColorWrap_default(Material);

// node_modules/react-color/es/components/photoshop/Photoshop.js
init_react();
var import_prop_types8 = __toESM(require_prop_types());
var import_reactcss31 = __toESM(require_lib());

// node_modules/react-color/es/components/photoshop/PhotoshopFields.js
init_react();
var import_reactcss26 = __toESM(require_lib());
var PhotoshopPicker = function PhotoshopPicker2(_ref) {
  var onChange = _ref.onChange, rgb = _ref.rgb, hsv = _ref.hsv, hex = _ref.hex;
  var styles = (0, import_reactcss26.default)({
    "default": {
      fields: {
        paddingTop: "5px",
        paddingBottom: "9px",
        width: "80px",
        position: "relative"
      },
      divider: {
        height: "5px"
      },
      RGBwrap: {
        position: "relative"
      },
      RGBinput: {
        marginLeft: "40%",
        width: "40%",
        height: "18px",
        border: "1px solid #888888",
        boxShadow: "inset 0 1px 1px rgba(0,0,0,.1), 0 1px 0 0 #ECECEC",
        marginBottom: "5px",
        fontSize: "13px",
        paddingLeft: "3px",
        marginRight: "10px"
      },
      RGBlabel: {
        left: "0px",
        top: "0px",
        width: "34px",
        textTransform: "uppercase",
        fontSize: "13px",
        height: "18px",
        lineHeight: "22px",
        position: "absolute"
      },
      HEXwrap: {
        position: "relative"
      },
      HEXinput: {
        marginLeft: "20%",
        width: "80%",
        height: "18px",
        border: "1px solid #888888",
        boxShadow: "inset 0 1px 1px rgba(0,0,0,.1), 0 1px 0 0 #ECECEC",
        marginBottom: "6px",
        fontSize: "13px",
        paddingLeft: "3px"
      },
      HEXlabel: {
        position: "absolute",
        top: "0px",
        left: "0px",
        width: "14px",
        textTransform: "uppercase",
        fontSize: "13px",
        height: "18px",
        lineHeight: "22px"
      },
      fieldSymbols: {
        position: "absolute",
        top: "5px",
        right: "-7px",
        fontSize: "13px"
      },
      symbol: {
        height: "20px",
        lineHeight: "22px",
        paddingBottom: "7px"
      }
    }
  });
  var handleChange = function handleChange2(data, e9) {
    if (data["#"]) {
      isValidHex(data["#"]) && onChange({
        hex: data["#"],
        source: "hex"
      }, e9);
    } else if (data.r || data.g || data.b) {
      onChange({
        r: data.r || rgb.r,
        g: data.g || rgb.g,
        b: data.b || rgb.b,
        source: "rgb"
      }, e9);
    } else if (data.h || data.s || data.v) {
      onChange({
        h: data.h || hsv.h,
        s: data.s || hsv.s,
        v: data.v || hsv.v,
        source: "hsv"
      }, e9);
    }
  };
  return Cn.createElement(
    "div",
    { style: styles.fields },
    Cn.createElement(EditableInput_default, {
      style: { wrap: styles.RGBwrap, input: styles.RGBinput, label: styles.RGBlabel },
      label: "h",
      value: Math.round(hsv.h),
      onChange: handleChange
    }),
    Cn.createElement(EditableInput_default, {
      style: { wrap: styles.RGBwrap, input: styles.RGBinput, label: styles.RGBlabel },
      label: "s",
      value: Math.round(hsv.s * 100),
      onChange: handleChange
    }),
    Cn.createElement(EditableInput_default, {
      style: { wrap: styles.RGBwrap, input: styles.RGBinput, label: styles.RGBlabel },
      label: "v",
      value: Math.round(hsv.v * 100),
      onChange: handleChange
    }),
    Cn.createElement("div", { style: styles.divider }),
    Cn.createElement(EditableInput_default, {
      style: { wrap: styles.RGBwrap, input: styles.RGBinput, label: styles.RGBlabel },
      label: "r",
      value: rgb.r,
      onChange: handleChange
    }),
    Cn.createElement(EditableInput_default, {
      style: { wrap: styles.RGBwrap, input: styles.RGBinput, label: styles.RGBlabel },
      label: "g",
      value: rgb.g,
      onChange: handleChange
    }),
    Cn.createElement(EditableInput_default, {
      style: { wrap: styles.RGBwrap, input: styles.RGBinput, label: styles.RGBlabel },
      label: "b",
      value: rgb.b,
      onChange: handleChange
    }),
    Cn.createElement("div", { style: styles.divider }),
    Cn.createElement(EditableInput_default, {
      style: { wrap: styles.HEXwrap, input: styles.HEXinput, label: styles.HEXlabel },
      label: "#",
      value: hex.replace("#", ""),
      onChange: handleChange
    }),
    Cn.createElement(
      "div",
      { style: styles.fieldSymbols },
      Cn.createElement(
        "div",
        { style: styles.symbol },
        "\xB0"
      ),
      Cn.createElement(
        "div",
        { style: styles.symbol },
        "%"
      ),
      Cn.createElement(
        "div",
        { style: styles.symbol },
        "%"
      )
    )
  );
};
var PhotoshopFields_default = PhotoshopPicker;

// node_modules/react-color/es/components/photoshop/PhotoshopPointerCircle.js
init_react();
var import_reactcss27 = __toESM(require_lib());
var PhotoshopPointerCircle = function PhotoshopPointerCircle2(_ref) {
  var hsl = _ref.hsl;
  var styles = (0, import_reactcss27.default)({
    "default": {
      picker: {
        width: "12px",
        height: "12px",
        borderRadius: "6px",
        boxShadow: "inset 0 0 0 1px #fff",
        transform: "translate(-6px, -6px)"
      }
    },
    "black-outline": {
      picker: {
        boxShadow: "inset 0 0 0 1px #000"
      }
    }
  }, { "black-outline": hsl.l > 0.5 });
  return Cn.createElement("div", { style: styles.picker });
};
var PhotoshopPointerCircle_default = PhotoshopPointerCircle;

// node_modules/react-color/es/components/photoshop/PhotoshopPointer.js
init_react();
var import_reactcss28 = __toESM(require_lib());
var PhotoshopPointerCircle3 = function PhotoshopPointerCircle4() {
  var styles = (0, import_reactcss28.default)({
    "default": {
      triangle: {
        width: 0,
        height: 0,
        borderStyle: "solid",
        borderWidth: "4px 0 4px 6px",
        borderColor: "transparent transparent transparent #fff",
        position: "absolute",
        top: "1px",
        left: "1px"
      },
      triangleBorder: {
        width: 0,
        height: 0,
        borderStyle: "solid",
        borderWidth: "5px 0 5px 8px",
        borderColor: "transparent transparent transparent #555"
      },
      left: {
        Extend: "triangleBorder",
        transform: "translate(-13px, -4px)"
      },
      leftInside: {
        Extend: "triangle",
        transform: "translate(-8px, -5px)"
      },
      right: {
        Extend: "triangleBorder",
        transform: "translate(20px, -14px) rotate(180deg)"
      },
      rightInside: {
        Extend: "triangle",
        transform: "translate(-8px, -5px)"
      }
    }
  });
  return Cn.createElement(
    "div",
    { style: styles.pointer },
    Cn.createElement(
      "div",
      { style: styles.left },
      Cn.createElement("div", { style: styles.leftInside })
    ),
    Cn.createElement(
      "div",
      { style: styles.right },
      Cn.createElement("div", { style: styles.rightInside })
    )
  );
};
var PhotoshopPointer_default = PhotoshopPointerCircle3;

// node_modules/react-color/es/components/photoshop/PhotoshopButton.js
init_react();
var import_reactcss29 = __toESM(require_lib());
var PhotoshopButton = function PhotoshopButton2(_ref) {
  var onClick = _ref.onClick, label = _ref.label, children = _ref.children, active = _ref.active;
  var styles = (0, import_reactcss29.default)({
    "default": {
      button: {
        backgroundImage: "linear-gradient(-180deg, #FFFFFF 0%, #E6E6E6 100%)",
        border: "1px solid #878787",
        borderRadius: "2px",
        height: "20px",
        boxShadow: "0 1px 0 0 #EAEAEA",
        fontSize: "14px",
        color: "#000",
        lineHeight: "20px",
        textAlign: "center",
        marginBottom: "10px",
        cursor: "pointer"
      }
    },
    "active": {
      button: {
        boxShadow: "0 0 0 1px #878787"
      }
    }
  }, { active });
  return Cn.createElement(
    "div",
    { style: styles.button, onClick },
    label || children
  );
};
var PhotoshopButton_default = PhotoshopButton;

// node_modules/react-color/es/components/photoshop/PhotoshopPreviews.js
init_react();
var import_reactcss30 = __toESM(require_lib());
var PhotoshopPreviews = function PhotoshopPreviews2(_ref) {
  var rgb = _ref.rgb, currentColor = _ref.currentColor;
  var styles = (0, import_reactcss30.default)({
    "default": {
      swatches: {
        border: "1px solid #B3B3B3",
        borderBottom: "1px solid #F0F0F0",
        marginBottom: "2px",
        marginTop: "1px"
      },
      new: {
        height: "34px",
        background: "rgb(" + rgb.r + "," + rgb.g + ", " + rgb.b + ")",
        boxShadow: "inset 1px 0 0 #000, inset -1px 0 0 #000, inset 0 1px 0 #000"
      },
      current: {
        height: "34px",
        background: currentColor,
        boxShadow: "inset 1px 0 0 #000, inset -1px 0 0 #000, inset 0 -1px 0 #000"
      },
      label: {
        fontSize: "14px",
        color: "#000",
        textAlign: "center"
      }
    }
  });
  return Cn.createElement(
    "div",
    null,
    Cn.createElement(
      "div",
      { style: styles.label },
      "new"
    ),
    Cn.createElement(
      "div",
      { style: styles.swatches },
      Cn.createElement("div", { style: styles.new }),
      Cn.createElement("div", { style: styles.current })
    ),
    Cn.createElement(
      "div",
      { style: styles.label },
      "current"
    )
  );
};
var PhotoshopPreviews_default = PhotoshopPreviews;

// node_modules/react-color/es/components/photoshop/Photoshop.js
var _createClass8 = function() {
  function defineProperties(target, props) {
    for (var i6 = 0; i6 < props.length; i6++) {
      var descriptor = props[i6];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor)
        descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }
  return function(Constructor, protoProps, staticProps) {
    if (protoProps)
      defineProperties(Constructor.prototype, protoProps);
    if (staticProps)
      defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();
function _classCallCheck8(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _possibleConstructorReturn8(self2, call) {
  if (!self2) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return call && (typeof call === "object" || typeof call === "function") ? call : self2;
}
function _inherits8(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
  if (superClass)
    Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
}
var Photoshop = function(_React$Component) {
  _inherits8(Photoshop2, _React$Component);
  function Photoshop2(props) {
    _classCallCheck8(this, Photoshop2);
    var _this = _possibleConstructorReturn8(this, (Photoshop2.__proto__ || Object.getPrototypeOf(Photoshop2)).call(this));
    _this.state = {
      currentColor: props.hex
    };
    return _this;
  }
  _createClass8(Photoshop2, [{
    key: "render",
    value: function render3() {
      var _props = this.props, _props$styles = _props.styles, passedStyles = _props$styles === void 0 ? {} : _props$styles, _props$className = _props.className, className = _props$className === void 0 ? "" : _props$className;
      var styles = (0, import_reactcss31.default)(merge_default({
        "default": {
          picker: {
            background: "#DCDCDC",
            borderRadius: "4px",
            boxShadow: "0 0 0 1px rgba(0,0,0,.25), 0 8px 16px rgba(0,0,0,.15)",
            boxSizing: "initial",
            width: "513px"
          },
          head: {
            backgroundImage: "linear-gradient(-180deg, #F0F0F0 0%, #D4D4D4 100%)",
            borderBottom: "1px solid #B1B1B1",
            boxShadow: "inset 0 1px 0 0 rgba(255,255,255,.2), inset 0 -1px 0 0 rgba(0,0,0,.02)",
            height: "23px",
            lineHeight: "24px",
            borderRadius: "4px 4px 0 0",
            fontSize: "13px",
            color: "#4D4D4D",
            textAlign: "center"
          },
          body: {
            padding: "15px 15px 0",
            display: "flex"
          },
          saturation: {
            width: "256px",
            height: "256px",
            position: "relative",
            border: "2px solid #B3B3B3",
            borderBottom: "2px solid #F0F0F0",
            overflow: "hidden"
          },
          hue: {
            position: "relative",
            height: "256px",
            width: "19px",
            marginLeft: "10px",
            border: "2px solid #B3B3B3",
            borderBottom: "2px solid #F0F0F0"
          },
          controls: {
            width: "180px",
            marginLeft: "10px"
          },
          top: {
            display: "flex"
          },
          previews: {
            width: "60px"
          },
          actions: {
            flex: "1",
            marginLeft: "20px"
          }
        }
      }, passedStyles));
      return Cn.createElement(
        "div",
        { style: styles.picker, className: "photoshop-picker " + className },
        Cn.createElement(
          "div",
          { style: styles.head },
          this.props.header
        ),
        Cn.createElement(
          "div",
          { style: styles.body, className: "flexbox-fix" },
          Cn.createElement(
            "div",
            { style: styles.saturation },
            Cn.createElement(Saturation_default, {
              hsl: this.props.hsl,
              hsv: this.props.hsv,
              pointer: PhotoshopPointerCircle_default,
              onChange: this.props.onChange
            })
          ),
          Cn.createElement(
            "div",
            { style: styles.hue },
            Cn.createElement(Hue_default, {
              direction: "vertical",
              hsl: this.props.hsl,
              pointer: PhotoshopPointer_default,
              onChange: this.props.onChange
            })
          ),
          Cn.createElement(
            "div",
            { style: styles.controls },
            Cn.createElement(
              "div",
              { style: styles.top, className: "flexbox-fix" },
              Cn.createElement(
                "div",
                { style: styles.previews },
                Cn.createElement(PhotoshopPreviews_default, {
                  rgb: this.props.rgb,
                  currentColor: this.state.currentColor
                })
              ),
              Cn.createElement(
                "div",
                { style: styles.actions },
                Cn.createElement(PhotoshopButton_default, { label: "OK", onClick: this.props.onAccept, active: true }),
                Cn.createElement(PhotoshopButton_default, { label: "Cancel", onClick: this.props.onCancel }),
                Cn.createElement(PhotoshopFields_default, {
                  onChange: this.props.onChange,
                  rgb: this.props.rgb,
                  hsv: this.props.hsv,
                  hex: this.props.hex
                })
              )
            )
          )
        )
      );
    }
  }]);
  return Photoshop2;
}(Cn.Component);
Photoshop.propTypes = {
  header: import_prop_types8.default.string,
  styles: import_prop_types8.default.object
};
Photoshop.defaultProps = {
  header: "Color Picker",
  styles: {}
};
var Photoshop_default = ColorWrap_default(Photoshop);

// node_modules/react-color/es/components/sketch/Sketch.js
init_react();
var import_prop_types10 = __toESM(require_prop_types());
var import_reactcss34 = __toESM(require_lib());

// node_modules/react-color/es/components/sketch/SketchFields.js
init_react();
var import_reactcss32 = __toESM(require_lib());
var SketchFields = function SketchFields2(_ref) {
  var onChange = _ref.onChange, rgb = _ref.rgb, hsl = _ref.hsl, hex = _ref.hex, disableAlpha = _ref.disableAlpha;
  var styles = (0, import_reactcss32.default)({
    "default": {
      fields: {
        display: "flex",
        paddingTop: "4px"
      },
      single: {
        flex: "1",
        paddingLeft: "6px"
      },
      alpha: {
        flex: "1",
        paddingLeft: "6px"
      },
      double: {
        flex: "2"
      },
      input: {
        width: "80%",
        padding: "4px 10% 3px",
        border: "none",
        boxShadow: "inset 0 0 0 1px #ccc",
        fontSize: "11px"
      },
      label: {
        display: "block",
        textAlign: "center",
        fontSize: "11px",
        color: "#222",
        paddingTop: "3px",
        paddingBottom: "4px",
        textTransform: "capitalize"
      }
    },
    "disableAlpha": {
      alpha: {
        display: "none"
      }
    }
  }, { disableAlpha });
  var handleChange = function handleChange2(data, e9) {
    if (data.hex) {
      isValidHex(data.hex) && onChange({
        hex: data.hex,
        source: "hex"
      }, e9);
    } else if (data.r || data.g || data.b) {
      onChange({
        r: data.r || rgb.r,
        g: data.g || rgb.g,
        b: data.b || rgb.b,
        a: rgb.a,
        source: "rgb"
      }, e9);
    } else if (data.a) {
      if (data.a < 0) {
        data.a = 0;
      } else if (data.a > 100) {
        data.a = 100;
      }
      data.a /= 100;
      onChange({
        h: hsl.h,
        s: hsl.s,
        l: hsl.l,
        a: data.a,
        source: "rgb"
      }, e9);
    }
  };
  return Cn.createElement(
    "div",
    { style: styles.fields, className: "flexbox-fix" },
    Cn.createElement(
      "div",
      { style: styles.double },
      Cn.createElement(EditableInput_default, {
        style: { input: styles.input, label: styles.label },
        label: "hex",
        value: hex.replace("#", ""),
        onChange: handleChange
      })
    ),
    Cn.createElement(
      "div",
      { style: styles.single },
      Cn.createElement(EditableInput_default, {
        style: { input: styles.input, label: styles.label },
        label: "r",
        value: rgb.r,
        onChange: handleChange,
        dragLabel: "true",
        dragMax: "255"
      })
    ),
    Cn.createElement(
      "div",
      { style: styles.single },
      Cn.createElement(EditableInput_default, {
        style: { input: styles.input, label: styles.label },
        label: "g",
        value: rgb.g,
        onChange: handleChange,
        dragLabel: "true",
        dragMax: "255"
      })
    ),
    Cn.createElement(
      "div",
      { style: styles.single },
      Cn.createElement(EditableInput_default, {
        style: { input: styles.input, label: styles.label },
        label: "b",
        value: rgb.b,
        onChange: handleChange,
        dragLabel: "true",
        dragMax: "255"
      })
    ),
    Cn.createElement(
      "div",
      { style: styles.alpha },
      Cn.createElement(EditableInput_default, {
        style: { input: styles.input, label: styles.label },
        label: "a",
        value: Math.round(rgb.a * 100),
        onChange: handleChange,
        dragLabel: "true",
        dragMax: "100"
      })
    )
  );
};
var SketchFields_default = SketchFields;

// node_modules/react-color/es/components/sketch/SketchPresetColors.js
init_react();
var import_prop_types9 = __toESM(require_prop_types());
var import_reactcss33 = __toESM(require_lib());
var _extends8 = Object.assign || function(target) {
  for (var i6 = 1; i6 < arguments.length; i6++) {
    var source = arguments[i6];
    for (var key in source) {
      if (Object.prototype.hasOwnProperty.call(source, key)) {
        target[key] = source[key];
      }
    }
  }
  return target;
};
var SketchPresetColors = function SketchPresetColors2(_ref) {
  var colors2 = _ref.colors, _ref$onClick = _ref.onClick, onClick = _ref$onClick === void 0 ? function() {
  } : _ref$onClick, onSwatchHover = _ref.onSwatchHover;
  var styles = (0, import_reactcss33.default)({
    "default": {
      colors: {
        margin: "0 -10px",
        padding: "10px 0 0 10px",
        borderTop: "1px solid #eee",
        display: "flex",
        flexWrap: "wrap",
        position: "relative"
      },
      swatchWrap: {
        width: "16px",
        height: "16px",
        margin: "0 10px 10px 0"
      },
      swatch: {
        borderRadius: "3px",
        boxShadow: "inset 0 0 0 1px rgba(0,0,0,.15)"
      }
    },
    "no-presets": {
      colors: {
        display: "none"
      }
    }
  }, {
    "no-presets": !colors2 || !colors2.length
  });
  var handleClick = function handleClick2(hex, e9) {
    onClick({
      hex,
      source: "hex"
    }, e9);
  };
  return Cn.createElement(
    "div",
    { style: styles.colors, className: "flexbox-fix" },
    colors2.map(function(colorObjOrString) {
      var c5 = typeof colorObjOrString === "string" ? { color: colorObjOrString } : colorObjOrString;
      var key = "" + c5.color + (c5.title || "");
      return Cn.createElement(
        "div",
        { key, style: styles.swatchWrap },
        Cn.createElement(Swatch_default, _extends8({}, c5, {
          style: styles.swatch,
          onClick: handleClick,
          onHover: onSwatchHover,
          focusStyle: {
            boxShadow: "inset 0 0 0 1px rgba(0,0,0,.15), 0 0 4px " + c5.color
          }
        }))
      );
    })
  );
};
SketchPresetColors.propTypes = {
  colors: import_prop_types9.default.arrayOf(import_prop_types9.default.oneOfType([import_prop_types9.default.string, import_prop_types9.default.shape({
    color: import_prop_types9.default.string,
    title: import_prop_types9.default.string
  })])).isRequired
};
var SketchPresetColors_default = SketchPresetColors;

// node_modules/react-color/es/components/sketch/Sketch.js
var _extends9 = Object.assign || function(target) {
  for (var i6 = 1; i6 < arguments.length; i6++) {
    var source = arguments[i6];
    for (var key in source) {
      if (Object.prototype.hasOwnProperty.call(source, key)) {
        target[key] = source[key];
      }
    }
  }
  return target;
};
var Sketch = function Sketch2(_ref) {
  var width = _ref.width, rgb = _ref.rgb, hex = _ref.hex, hsv = _ref.hsv, hsl = _ref.hsl, onChange = _ref.onChange, onSwatchHover = _ref.onSwatchHover, disableAlpha = _ref.disableAlpha, presetColors = _ref.presetColors, renderers = _ref.renderers, _ref$styles = _ref.styles, passedStyles = _ref$styles === void 0 ? {} : _ref$styles, _ref$className = _ref.className, className = _ref$className === void 0 ? "" : _ref$className;
  var styles = (0, import_reactcss34.default)(merge_default({
    "default": _extends9({
      picker: {
        width,
        padding: "10px 10px 0",
        boxSizing: "initial",
        background: "#fff",
        borderRadius: "4px",
        boxShadow: "0 0 0 1px rgba(0,0,0,.15), 0 8px 16px rgba(0,0,0,.15)"
      },
      saturation: {
        width: "100%",
        paddingBottom: "75%",
        position: "relative",
        overflow: "hidden"
      },
      Saturation: {
        radius: "3px",
        shadow: "inset 0 0 0 1px rgba(0,0,0,.15), inset 0 0 4px rgba(0,0,0,.25)"
      },
      controls: {
        display: "flex"
      },
      sliders: {
        padding: "4px 0",
        flex: "1"
      },
      color: {
        width: "24px",
        height: "24px",
        position: "relative",
        marginTop: "4px",
        marginLeft: "4px",
        borderRadius: "3px"
      },
      activeColor: {
        absolute: "0px 0px 0px 0px",
        borderRadius: "2px",
        background: "rgba(" + rgb.r + "," + rgb.g + "," + rgb.b + "," + rgb.a + ")",
        boxShadow: "inset 0 0 0 1px rgba(0,0,0,.15), inset 0 0 4px rgba(0,0,0,.25)"
      },
      hue: {
        position: "relative",
        height: "10px",
        overflow: "hidden"
      },
      Hue: {
        radius: "2px",
        shadow: "inset 0 0 0 1px rgba(0,0,0,.15), inset 0 0 4px rgba(0,0,0,.25)"
      },
      alpha: {
        position: "relative",
        height: "10px",
        marginTop: "4px",
        overflow: "hidden"
      },
      Alpha: {
        radius: "2px",
        shadow: "inset 0 0 0 1px rgba(0,0,0,.15), inset 0 0 4px rgba(0,0,0,.25)"
      }
    }, passedStyles),
    "disableAlpha": {
      color: {
        height: "10px"
      },
      hue: {
        height: "10px"
      },
      alpha: {
        display: "none"
      }
    }
  }, passedStyles), { disableAlpha });
  return Cn.createElement(
    "div",
    { style: styles.picker, className: "sketch-picker " + className },
    Cn.createElement(
      "div",
      { style: styles.saturation },
      Cn.createElement(Saturation_default, {
        style: styles.Saturation,
        hsl,
        hsv,
        onChange
      })
    ),
    Cn.createElement(
      "div",
      { style: styles.controls, className: "flexbox-fix" },
      Cn.createElement(
        "div",
        { style: styles.sliders },
        Cn.createElement(
          "div",
          { style: styles.hue },
          Cn.createElement(Hue_default, {
            style: styles.Hue,
            hsl,
            onChange
          })
        ),
        Cn.createElement(
          "div",
          { style: styles.alpha },
          Cn.createElement(Alpha_default, {
            style: styles.Alpha,
            rgb,
            hsl,
            renderers,
            onChange
          })
        )
      ),
      Cn.createElement(
        "div",
        { style: styles.color },
        Cn.createElement(Checkboard_default, null),
        Cn.createElement("div", { style: styles.activeColor })
      )
    ),
    Cn.createElement(SketchFields_default, {
      rgb,
      hsl,
      hex,
      onChange,
      disableAlpha
    }),
    Cn.createElement(SketchPresetColors_default, {
      colors: presetColors,
      onClick: onChange,
      onSwatchHover
    })
  );
};
Sketch.propTypes = {
  disableAlpha: import_prop_types10.default.bool,
  width: import_prop_types10.default.oneOfType([import_prop_types10.default.string, import_prop_types10.default.number]),
  styles: import_prop_types10.default.object
};
Sketch.defaultProps = {
  disableAlpha: false,
  width: 200,
  styles: {},
  presetColors: ["#D0021B", "#F5A623", "#F8E71C", "#8B572A", "#7ED321", "#417505", "#BD10E0", "#9013FE", "#4A90E2", "#50E3C2", "#B8E986", "#000000", "#4A4A4A", "#9B9B9B", "#FFFFFF"]
};
var Sketch_default = ColorWrap_default(Sketch);

// node_modules/react-color/es/components/slider/Slider.js
init_react();
var import_prop_types11 = __toESM(require_prop_types());
var import_reactcss38 = __toESM(require_lib());

// node_modules/react-color/es/components/slider/SliderSwatches.js
init_react();
var import_reactcss36 = __toESM(require_lib());

// node_modules/react-color/es/components/slider/SliderSwatch.js
init_react();
var import_reactcss35 = __toESM(require_lib());
var SliderSwatch = function SliderSwatch2(_ref) {
  var hsl = _ref.hsl, offset = _ref.offset, _ref$onClick = _ref.onClick, onClick = _ref$onClick === void 0 ? function() {
  } : _ref$onClick, active = _ref.active, first = _ref.first, last = _ref.last;
  var styles = (0, import_reactcss35.default)({
    "default": {
      swatch: {
        height: "12px",
        background: "hsl(" + hsl.h + ", 50%, " + offset * 100 + "%)",
        cursor: "pointer"
      }
    },
    "first": {
      swatch: {
        borderRadius: "2px 0 0 2px"
      }
    },
    "last": {
      swatch: {
        borderRadius: "0 2px 2px 0"
      }
    },
    "active": {
      swatch: {
        transform: "scaleY(1.8)",
        borderRadius: "3.6px/2px"
      }
    }
  }, { active, first, last });
  var handleClick = function handleClick2(e9) {
    return onClick({
      h: hsl.h,
      s: 0.5,
      l: offset,
      source: "hsl"
    }, e9);
  };
  return Cn.createElement("div", { style: styles.swatch, onClick: handleClick });
};
var SliderSwatch_default = SliderSwatch;

// node_modules/react-color/es/components/slider/SliderSwatches.js
var SliderSwatches = function SliderSwatches2(_ref) {
  var onClick = _ref.onClick, hsl = _ref.hsl;
  var styles = (0, import_reactcss36.default)({
    "default": {
      swatches: {
        marginTop: "20px"
      },
      swatch: {
        boxSizing: "border-box",
        width: "20%",
        paddingRight: "1px",
        float: "left"
      },
      clear: {
        clear: "both"
      }
    }
  });
  var epsilon = 0.1;
  return Cn.createElement(
    "div",
    { style: styles.swatches },
    Cn.createElement(
      "div",
      { style: styles.swatch },
      Cn.createElement(SliderSwatch_default, {
        hsl,
        offset: ".80",
        active: Math.abs(hsl.l - 0.8) < epsilon && Math.abs(hsl.s - 0.5) < epsilon,
        onClick,
        first: true
      })
    ),
    Cn.createElement(
      "div",
      { style: styles.swatch },
      Cn.createElement(SliderSwatch_default, {
        hsl,
        offset: ".65",
        active: Math.abs(hsl.l - 0.65) < epsilon && Math.abs(hsl.s - 0.5) < epsilon,
        onClick
      })
    ),
    Cn.createElement(
      "div",
      { style: styles.swatch },
      Cn.createElement(SliderSwatch_default, {
        hsl,
        offset: ".50",
        active: Math.abs(hsl.l - 0.5) < epsilon && Math.abs(hsl.s - 0.5) < epsilon,
        onClick
      })
    ),
    Cn.createElement(
      "div",
      { style: styles.swatch },
      Cn.createElement(SliderSwatch_default, {
        hsl,
        offset: ".35",
        active: Math.abs(hsl.l - 0.35) < epsilon && Math.abs(hsl.s - 0.5) < epsilon,
        onClick
      })
    ),
    Cn.createElement(
      "div",
      { style: styles.swatch },
      Cn.createElement(SliderSwatch_default, {
        hsl,
        offset: ".20",
        active: Math.abs(hsl.l - 0.2) < epsilon && Math.abs(hsl.s - 0.5) < epsilon,
        onClick,
        last: true
      })
    ),
    Cn.createElement("div", { style: styles.clear })
  );
};
var SliderSwatches_default = SliderSwatches;

// node_modules/react-color/es/components/slider/SliderPointer.js
init_react();
var import_reactcss37 = __toESM(require_lib());
var SliderPointer3 = function SliderPointer4() {
  var styles = (0, import_reactcss37.default)({
    "default": {
      picker: {
        width: "14px",
        height: "14px",
        borderRadius: "6px",
        transform: "translate(-7px, -1px)",
        backgroundColor: "rgb(248, 248, 248)",
        boxShadow: "0 1px 4px 0 rgba(0, 0, 0, 0.37)"
      }
    }
  });
  return Cn.createElement("div", { style: styles.picker });
};
var SliderPointer_default = SliderPointer3;

// node_modules/react-color/es/components/slider/Slider.js
var Slider = function Slider2(_ref) {
  var hsl = _ref.hsl, onChange = _ref.onChange, pointer = _ref.pointer, _ref$styles = _ref.styles, passedStyles = _ref$styles === void 0 ? {} : _ref$styles, _ref$className = _ref.className, className = _ref$className === void 0 ? "" : _ref$className;
  var styles = (0, import_reactcss38.default)(merge_default({
    "default": {
      hue: {
        height: "12px",
        position: "relative"
      },
      Hue: {
        radius: "2px"
      }
    }
  }, passedStyles));
  return Cn.createElement(
    "div",
    { style: styles.wrap || {}, className: "slider-picker " + className },
    Cn.createElement(
      "div",
      { style: styles.hue },
      Cn.createElement(Hue_default, {
        style: styles.Hue,
        hsl,
        pointer,
        onChange
      })
    ),
    Cn.createElement(
      "div",
      { style: styles.swatches },
      Cn.createElement(SliderSwatches_default, { hsl, onClick: onChange })
    )
  );
};
Slider.propTypes = {
  styles: import_prop_types11.default.object
};
Slider.defaultProps = {
  pointer: SliderPointer_default,
  styles: {}
};
var Slider_default = ColorWrap_default(Slider);

// node_modules/react-color/es/components/swatches/Swatches.js
init_react();
var import_prop_types12 = __toESM(require_prop_types());
var import_reactcss41 = __toESM(require_lib());

// node_modules/react-color/es/components/swatches/SwatchesGroup.js
init_react();
var import_reactcss40 = __toESM(require_lib());

// node_modules/react-color/es/components/swatches/SwatchesColor.js
init_react();
var import_reactcss39 = __toESM(require_lib());
var import_CheckIcon = __toESM(require_CheckIcon());
var SwatchesColor = function SwatchesColor2(_ref) {
  var color = _ref.color, _ref$onClick = _ref.onClick, onClick = _ref$onClick === void 0 ? function() {
  } : _ref$onClick, onSwatchHover = _ref.onSwatchHover, first = _ref.first, last = _ref.last, active = _ref.active;
  var styles = (0, import_reactcss39.default)({
    "default": {
      color: {
        width: "40px",
        height: "24px",
        cursor: "pointer",
        background: color,
        marginBottom: "1px"
      },
      check: {
        color: getContrastingColor(color),
        marginLeft: "8px",
        display: "none"
      }
    },
    "first": {
      color: {
        overflow: "hidden",
        borderRadius: "2px 2px 0 0"
      }
    },
    "last": {
      color: {
        overflow: "hidden",
        borderRadius: "0 0 2px 2px"
      }
    },
    "active": {
      check: {
        display: "block"
      }
    },
    "color-#FFFFFF": {
      color: {
        boxShadow: "inset 0 0 0 1px #ddd"
      },
      check: {
        color: "#333"
      }
    },
    "transparent": {
      check: {
        color: "#333"
      }
    }
  }, {
    first,
    last,
    active,
    "color-#FFFFFF": color === "#FFFFFF",
    "transparent": color === "transparent"
  });
  return Cn.createElement(
    Swatch_default,
    {
      color,
      style: styles.color,
      onClick,
      onHover: onSwatchHover,
      focusStyle: { boxShadow: "0 0 4px " + color }
    },
    Cn.createElement(
      "div",
      { style: styles.check },
      Cn.createElement(import_CheckIcon.default, null)
    )
  );
};
var SwatchesColor_default = SwatchesColor;

// node_modules/react-color/es/components/swatches/SwatchesGroup.js
var SwatchesGroup = function SwatchesGroup2(_ref) {
  var onClick = _ref.onClick, onSwatchHover = _ref.onSwatchHover, group = _ref.group, active = _ref.active;
  var styles = (0, import_reactcss40.default)({
    "default": {
      group: {
        paddingBottom: "10px",
        width: "40px",
        float: "left",
        marginRight: "10px"
      }
    }
  });
  return Cn.createElement(
    "div",
    { style: styles.group },
    map_default(group, function(color, i6) {
      return Cn.createElement(SwatchesColor_default, {
        key: color,
        color,
        active: color.toLowerCase() === active,
        first: i6 === 0,
        last: i6 === group.length - 1,
        onClick,
        onSwatchHover
      });
    })
  );
};
var SwatchesGroup_default = SwatchesGroup;

// node_modules/react-color/es/components/swatches/Swatches.js
var Swatches = function Swatches2(_ref) {
  var width = _ref.width, height = _ref.height, onChange = _ref.onChange, onSwatchHover = _ref.onSwatchHover, colors2 = _ref.colors, hex = _ref.hex, _ref$styles = _ref.styles, passedStyles = _ref$styles === void 0 ? {} : _ref$styles, _ref$className = _ref.className, className = _ref$className === void 0 ? "" : _ref$className;
  var styles = (0, import_reactcss41.default)(merge_default({
    "default": {
      picker: {
        width,
        height
      },
      overflow: {
        height,
        overflowY: "scroll"
      },
      body: {
        padding: "16px 0 6px 16px"
      },
      clear: {
        clear: "both"
      }
    }
  }, passedStyles));
  var handleChange = function handleChange2(data, e9) {
    return onChange({ hex: data, source: "hex" }, e9);
  };
  return Cn.createElement(
    "div",
    { style: styles.picker, className: "swatches-picker " + className },
    Cn.createElement(
      Raised_default,
      null,
      Cn.createElement(
        "div",
        { style: styles.overflow },
        Cn.createElement(
          "div",
          { style: styles.body },
          map_default(colors2, function(group) {
            return Cn.createElement(SwatchesGroup_default, {
              key: group.toString(),
              group,
              active: hex,
              onClick: handleChange,
              onSwatchHover
            });
          }),
          Cn.createElement("div", { style: styles.clear })
        )
      )
    )
  );
};
Swatches.propTypes = {
  width: import_prop_types12.default.oneOfType([import_prop_types12.default.string, import_prop_types12.default.number]),
  height: import_prop_types12.default.oneOfType([import_prop_types12.default.string, import_prop_types12.default.number]),
  colors: import_prop_types12.default.arrayOf(import_prop_types12.default.arrayOf(import_prop_types12.default.string)),
  styles: import_prop_types12.default.object
  /* eslint-disable max-len */
};
Swatches.defaultProps = {
  width: 320,
  height: 240,
  colors: [[red["900"], red["700"], red["500"], red["300"], red["100"]], [pink["900"], pink["700"], pink["500"], pink["300"], pink["100"]], [purple["900"], purple["700"], purple["500"], purple["300"], purple["100"]], [deepPurple["900"], deepPurple["700"], deepPurple["500"], deepPurple["300"], deepPurple["100"]], [indigo["900"], indigo["700"], indigo["500"], indigo["300"], indigo["100"]], [blue["900"], blue["700"], blue["500"], blue["300"], blue["100"]], [lightBlue["900"], lightBlue["700"], lightBlue["500"], lightBlue["300"], lightBlue["100"]], [cyan["900"], cyan["700"], cyan["500"], cyan["300"], cyan["100"]], [teal["900"], teal["700"], teal["500"], teal["300"], teal["100"]], ["#194D33", green["700"], green["500"], green["300"], green["100"]], [lightGreen["900"], lightGreen["700"], lightGreen["500"], lightGreen["300"], lightGreen["100"]], [lime["900"], lime["700"], lime["500"], lime["300"], lime["100"]], [yellow["900"], yellow["700"], yellow["500"], yellow["300"], yellow["100"]], [amber["900"], amber["700"], amber["500"], amber["300"], amber["100"]], [orange["900"], orange["700"], orange["500"], orange["300"], orange["100"]], [deepOrange["900"], deepOrange["700"], deepOrange["500"], deepOrange["300"], deepOrange["100"]], [brown["900"], brown["700"], brown["500"], brown["300"], brown["100"]], [blueGrey["900"], blueGrey["700"], blueGrey["500"], blueGrey["300"], blueGrey["100"]], ["#000000", "#525252", "#969696", "#D9D9D9", "#FFFFFF"]],
  styles: {}
};
var Swatches_default = ColorWrap_default(Swatches);

// node_modules/react-color/es/components/twitter/Twitter.js
init_react();
var import_prop_types13 = __toESM(require_prop_types());
var import_reactcss42 = __toESM(require_lib());
var Twitter = function Twitter2(_ref) {
  var onChange = _ref.onChange, onSwatchHover = _ref.onSwatchHover, hex = _ref.hex, colors2 = _ref.colors, width = _ref.width, triangle = _ref.triangle, _ref$styles = _ref.styles, passedStyles = _ref$styles === void 0 ? {} : _ref$styles, _ref$className = _ref.className, className = _ref$className === void 0 ? "" : _ref$className;
  var styles = (0, import_reactcss42.default)(merge_default({
    "default": {
      card: {
        width,
        background: "#fff",
        border: "0 solid rgba(0,0,0,0.25)",
        boxShadow: "0 1px 4px rgba(0,0,0,0.25)",
        borderRadius: "4px",
        position: "relative"
      },
      body: {
        padding: "15px 9px 9px 15px"
      },
      label: {
        fontSize: "18px",
        color: "#fff"
      },
      triangle: {
        width: "0px",
        height: "0px",
        borderStyle: "solid",
        borderWidth: "0 9px 10px 9px",
        borderColor: "transparent transparent #fff transparent",
        position: "absolute"
      },
      triangleShadow: {
        width: "0px",
        height: "0px",
        borderStyle: "solid",
        borderWidth: "0 9px 10px 9px",
        borderColor: "transparent transparent rgba(0,0,0,.1) transparent",
        position: "absolute"
      },
      hash: {
        background: "#F0F0F0",
        height: "30px",
        width: "30px",
        borderRadius: "4px 0 0 4px",
        float: "left",
        color: "#98A1A4",
        display: "flex",
        alignItems: "center",
        justifyContent: "center"
      },
      input: {
        width: "100px",
        fontSize: "14px",
        color: "#666",
        border: "0px",
        outline: "none",
        height: "28px",
        boxShadow: "inset 0 0 0 1px #F0F0F0",
        boxSizing: "content-box",
        borderRadius: "0 4px 4px 0",
        float: "left",
        paddingLeft: "8px"
      },
      swatch: {
        width: "30px",
        height: "30px",
        float: "left",
        borderRadius: "4px",
        margin: "0 6px 6px 0"
      },
      clear: {
        clear: "both"
      }
    },
    "hide-triangle": {
      triangle: {
        display: "none"
      },
      triangleShadow: {
        display: "none"
      }
    },
    "top-left-triangle": {
      triangle: {
        top: "-10px",
        left: "12px"
      },
      triangleShadow: {
        top: "-11px",
        left: "12px"
      }
    },
    "top-right-triangle": {
      triangle: {
        top: "-10px",
        right: "12px"
      },
      triangleShadow: {
        top: "-11px",
        right: "12px"
      }
    }
  }, passedStyles), {
    "hide-triangle": triangle === "hide",
    "top-left-triangle": triangle === "top-left",
    "top-right-triangle": triangle === "top-right"
  });
  var handleChange = function handleChange2(hexcode, e9) {
    isValidHex(hexcode) && onChange({
      hex: hexcode,
      source: "hex"
    }, e9);
  };
  return Cn.createElement(
    "div",
    { style: styles.card, className: "twitter-picker " + className },
    Cn.createElement("div", { style: styles.triangleShadow }),
    Cn.createElement("div", { style: styles.triangle }),
    Cn.createElement(
      "div",
      { style: styles.body },
      map_default(colors2, function(c5, i6) {
        return Cn.createElement(Swatch_default, {
          key: i6,
          color: c5,
          hex: c5,
          style: styles.swatch,
          onClick: handleChange,
          onHover: onSwatchHover,
          focusStyle: {
            boxShadow: "0 0 4px " + c5
          }
        });
      }),
      Cn.createElement(
        "div",
        { style: styles.hash },
        "#"
      ),
      Cn.createElement(EditableInput_default, {
        label: null,
        style: { input: styles.input },
        value: hex.replace("#", ""),
        onChange: handleChange
      }),
      Cn.createElement("div", { style: styles.clear })
    )
  );
};
Twitter.propTypes = {
  width: import_prop_types13.default.oneOfType([import_prop_types13.default.string, import_prop_types13.default.number]),
  triangle: import_prop_types13.default.oneOf(["hide", "top-left", "top-right"]),
  colors: import_prop_types13.default.arrayOf(import_prop_types13.default.string),
  styles: import_prop_types13.default.object
};
Twitter.defaultProps = {
  width: 276,
  colors: ["#FF6900", "#FCB900", "#7BDCB5", "#00D084", "#8ED1FC", "#0693E3", "#ABB8C3", "#EB144C", "#F78DA7", "#9900EF"],
  triangle: "top-left",
  styles: {}
};
var Twitter_default = ColorWrap_default(Twitter);

// node_modules/react-color/es/components/google/Google.js
init_react();
var import_prop_types16 = __toESM(require_prop_types());
var import_reactcss46 = __toESM(require_lib());

// node_modules/react-color/es/components/google/GooglePointerCircle.js
init_react();
var import_reactcss43 = __toESM(require_lib());
var import_prop_types14 = __toESM(require_prop_types());
var GooglePointerCircle = function GooglePointerCircle2(props) {
  var styles = (0, import_reactcss43.default)({
    "default": {
      picker: {
        width: "20px",
        height: "20px",
        borderRadius: "22px",
        border: "2px #fff solid",
        transform: "translate(-12px, -13px)",
        background: "hsl(" + Math.round(props.hsl.h) + ", " + Math.round(props.hsl.s * 100) + "%, " + Math.round(props.hsl.l * 100) + "%)"
      }
    }
  });
  return Cn.createElement("div", { style: styles.picker });
};
GooglePointerCircle.propTypes = {
  hsl: import_prop_types14.default.shape({
    h: import_prop_types14.default.number,
    s: import_prop_types14.default.number,
    l: import_prop_types14.default.number,
    a: import_prop_types14.default.number
  })
};
GooglePointerCircle.defaultProps = {
  hsl: { a: 1, h: 249.94, l: 0.2, s: 0.5 }
};
var GooglePointerCircle_default = GooglePointerCircle;

// node_modules/react-color/es/components/google/GooglePointer.js
init_react();
var import_reactcss44 = __toESM(require_lib());
var import_prop_types15 = __toESM(require_prop_types());
var GooglePointer = function GooglePointer2(props) {
  var styles = (0, import_reactcss44.default)({
    "default": {
      picker: {
        width: "20px",
        height: "20px",
        borderRadius: "22px",
        transform: "translate(-10px, -7px)",
        background: "hsl(" + Math.round(props.hsl.h) + ", 100%, 50%)",
        border: "2px white solid"
      }
    }
  });
  return Cn.createElement("div", { style: styles.picker });
};
GooglePointer.propTypes = {
  hsl: import_prop_types15.default.shape({
    h: import_prop_types15.default.number,
    s: import_prop_types15.default.number,
    l: import_prop_types15.default.number,
    a: import_prop_types15.default.number
  })
};
GooglePointer.defaultProps = {
  hsl: { a: 1, h: 249.94, l: 0.2, s: 0.5 }
};
var GooglePointer_default = GooglePointer;

// node_modules/react-color/es/components/google/GoogleFields.js
init_react();
var import_reactcss45 = __toESM(require_lib());
var GoogleFields = function GoogleFields2(_ref) {
  var onChange = _ref.onChange, rgb = _ref.rgb, hsl = _ref.hsl, hex = _ref.hex, hsv = _ref.hsv;
  var handleChange = function handleChange2(data, e9) {
    if (data.hex) {
      isValidHex(data.hex) && onChange({
        hex: data.hex,
        source: "hex"
      }, e9);
    } else if (data.rgb) {
      var values = data.rgb.split(",");
      isvalidColorString(data.rgb, "rgb") && onChange({
        r: values[0],
        g: values[1],
        b: values[2],
        a: 1,
        source: "rgb"
      }, e9);
    } else if (data.hsv) {
      var _values = data.hsv.split(",");
      if (isvalidColorString(data.hsv, "hsv")) {
        _values[2] = _values[2].replace("%", "");
        _values[1] = _values[1].replace("%", "");
        _values[0] = _values[0].replace("\xB0", "");
        if (_values[1] == 1) {
          _values[1] = 0.01;
        } else if (_values[2] == 1) {
          _values[2] = 0.01;
        }
        onChange({
          h: Number(_values[0]),
          s: Number(_values[1]),
          v: Number(_values[2]),
          source: "hsv"
        }, e9);
      }
    } else if (data.hsl) {
      var _values2 = data.hsl.split(",");
      if (isvalidColorString(data.hsl, "hsl")) {
        _values2[2] = _values2[2].replace("%", "");
        _values2[1] = _values2[1].replace("%", "");
        _values2[0] = _values2[0].replace("\xB0", "");
        if (hsvValue[1] == 1) {
          hsvValue[1] = 0.01;
        } else if (hsvValue[2] == 1) {
          hsvValue[2] = 0.01;
        }
        onChange({
          h: Number(_values2[0]),
          s: Number(_values2[1]),
          v: Number(_values2[2]),
          source: "hsl"
        }, e9);
      }
    }
  };
  var styles = (0, import_reactcss45.default)({
    "default": {
      wrap: {
        display: "flex",
        height: "100px",
        marginTop: "4px"
      },
      fields: {
        width: "100%"
      },
      column: {
        paddingTop: "10px",
        display: "flex",
        justifyContent: "space-between"
      },
      double: {
        padding: "0px 4.4px",
        boxSizing: "border-box"
      },
      input: {
        width: "100%",
        height: "38px",
        boxSizing: "border-box",
        padding: "4px 10% 3px",
        textAlign: "center",
        border: "1px solid #dadce0",
        fontSize: "11px",
        textTransform: "lowercase",
        borderRadius: "5px",
        outline: "none",
        fontFamily: "Roboto,Arial,sans-serif"
      },
      input2: {
        height: "38px",
        width: "100%",
        border: "1px solid #dadce0",
        boxSizing: "border-box",
        fontSize: "11px",
        textTransform: "lowercase",
        borderRadius: "5px",
        outline: "none",
        paddingLeft: "10px",
        fontFamily: "Roboto,Arial,sans-serif"
      },
      label: {
        textAlign: "center",
        fontSize: "12px",
        background: "#fff",
        position: "absolute",
        textTransform: "uppercase",
        color: "#3c4043",
        width: "35px",
        top: "-6px",
        left: "0",
        right: "0",
        marginLeft: "auto",
        marginRight: "auto",
        fontFamily: "Roboto,Arial,sans-serif"
      },
      label2: {
        left: "10px",
        textAlign: "center",
        fontSize: "12px",
        background: "#fff",
        position: "absolute",
        textTransform: "uppercase",
        color: "#3c4043",
        width: "32px",
        top: "-6px",
        fontFamily: "Roboto,Arial,sans-serif"
      },
      single: {
        flexGrow: "1",
        margin: "0px 4.4px"
      }
    }
  });
  var rgbValue = rgb.r + ", " + rgb.g + ", " + rgb.b;
  var hslValue = Math.round(hsl.h) + "\xB0, " + Math.round(hsl.s * 100) + "%, " + Math.round(hsl.l * 100) + "%";
  var hsvValue = Math.round(hsv.h) + "\xB0, " + Math.round(hsv.s * 100) + "%, " + Math.round(hsv.v * 100) + "%";
  return Cn.createElement(
    "div",
    { style: styles.wrap, className: "flexbox-fix" },
    Cn.createElement(
      "div",
      { style: styles.fields },
      Cn.createElement(
        "div",
        { style: styles.double },
        Cn.createElement(EditableInput_default, {
          style: { input: styles.input, label: styles.label },
          label: "hex",
          value: hex,
          onChange: handleChange
        })
      ),
      Cn.createElement(
        "div",
        { style: styles.column },
        Cn.createElement(
          "div",
          { style: styles.single },
          Cn.createElement(EditableInput_default, {
            style: { input: styles.input2, label: styles.label2 },
            label: "rgb",
            value: rgbValue,
            onChange: handleChange
          })
        ),
        Cn.createElement(
          "div",
          { style: styles.single },
          Cn.createElement(EditableInput_default, {
            style: { input: styles.input2, label: styles.label2 },
            label: "hsv",
            value: hsvValue,
            onChange: handleChange
          })
        ),
        Cn.createElement(
          "div",
          { style: styles.single },
          Cn.createElement(EditableInput_default, {
            style: { input: styles.input2, label: styles.label2 },
            label: "hsl",
            value: hslValue,
            onChange: handleChange
          })
        )
      )
    )
  );
};
var GoogleFields_default = GoogleFields;

// node_modules/react-color/es/components/google/Google.js
var Google = function Google2(_ref) {
  var width = _ref.width, onChange = _ref.onChange, rgb = _ref.rgb, hsl = _ref.hsl, hsv = _ref.hsv, hex = _ref.hex, header = _ref.header, _ref$styles = _ref.styles, passedStyles = _ref$styles === void 0 ? {} : _ref$styles, _ref$className = _ref.className, className = _ref$className === void 0 ? "" : _ref$className;
  var styles = (0, import_reactcss46.default)(merge_default({
    "default": {
      picker: {
        width,
        background: "#fff",
        border: "1px solid #dfe1e5",
        boxSizing: "initial",
        display: "flex",
        flexWrap: "wrap",
        borderRadius: "8px 8px 0px 0px"
      },
      head: {
        height: "57px",
        width: "100%",
        paddingTop: "16px",
        paddingBottom: "16px",
        paddingLeft: "16px",
        fontSize: "20px",
        boxSizing: "border-box",
        fontFamily: "Roboto-Regular,HelveticaNeue,Arial,sans-serif"
      },
      saturation: {
        width: "70%",
        padding: "0px",
        position: "relative",
        overflow: "hidden"
      },
      swatch: {
        width: "30%",
        height: "228px",
        padding: "0px",
        background: "rgba(" + rgb.r + ", " + rgb.g + ", " + rgb.b + ", 1)",
        position: "relative",
        overflow: "hidden"
      },
      body: {
        margin: "auto",
        width: "95%"
      },
      controls: {
        display: "flex",
        boxSizing: "border-box",
        height: "52px",
        paddingTop: "22px"
      },
      color: {
        width: "32px"
      },
      hue: {
        height: "8px",
        position: "relative",
        margin: "0px 16px 0px 16px",
        width: "100%"
      },
      Hue: {
        radius: "2px"
      }
    }
  }, passedStyles));
  return Cn.createElement(
    "div",
    { style: styles.picker, className: "google-picker " + className },
    Cn.createElement(
      "div",
      { style: styles.head },
      header
    ),
    Cn.createElement("div", { style: styles.swatch }),
    Cn.createElement(
      "div",
      { style: styles.saturation },
      Cn.createElement(Saturation_default, {
        hsl,
        hsv,
        pointer: GooglePointerCircle_default,
        onChange
      })
    ),
    Cn.createElement(
      "div",
      { style: styles.body },
      Cn.createElement(
        "div",
        { style: styles.controls, className: "flexbox-fix" },
        Cn.createElement(
          "div",
          { style: styles.hue },
          Cn.createElement(Hue_default, {
            style: styles.Hue,
            hsl,
            radius: "4px",
            pointer: GooglePointer_default,
            onChange
          })
        )
      ),
      Cn.createElement(GoogleFields_default, {
        rgb,
        hsl,
        hex,
        hsv,
        onChange
      })
    )
  );
};
Google.propTypes = {
  width: import_prop_types16.default.oneOfType([import_prop_types16.default.string, import_prop_types16.default.number]),
  styles: import_prop_types16.default.object,
  header: import_prop_types16.default.string
};
Google.defaultProps = {
  width: 652,
  styles: {},
  header: "Color picker"
};
var Google_default = ColorWrap_default(Google);

// node_modules/preact/compat/client.mjs
init_compat_module();
function createRoot(container) {
  return {
    render(children) {
      G2(children, container);
    },
    unmount() {
      hn(container);
    }
  };
}

// src/make_value_change_emitter.ts
var DATA_PASSING_EVENT_ID = "shiny-data-passing-event";
function isDataPassingPayload(x5) {
  if (typeof x5 !== "object") {
    return false;
  }
  if (x5 === null) {
    return false;
  }
  const hasTypeField = "type" in x5 && typeof x5.type === "string";
  const hasValueField = "value" in x5;
  if (!hasTypeField || !hasValueField)
    return false;
  switch (x5.type) {
    case "string":
      return typeof x5.value === "string";
    case "number":
      return typeof x5.value === "number";
    case "boolean":
      return typeof x5.value === "boolean";
    case "string[]":
      return Array.isArray(x5.value) && x5.value.every((x6) => typeof x6 === "string");
    default:
      return true;
  }
}
function makeDataPassingPayload(id, msg) {
  return { ...msg, id };
}
function getDataPassingEventValue(evt, id) {
  if (!(evt instanceof CustomEvent)) {
    return null;
  }
  if (evt.type !== DATA_PASSING_EVENT_ID) {
    return null;
  }
  const payload = evt.detail;
  if (typeof payload !== "object") {
    return null;
  }
  if (typeof payload.id !== "string" || payload.id !== id) {
    return null;
  }
  if (!isDataPassingPayload(payload)) {
    return null;
  }
  return payload;
}
function makeValueChangeEmitter(el, id) {
  return (payload) => {
    const event = new CustomEvent(DATA_PASSING_EVENT_ID, {
      detail: makeDataPassingPayload(id, payload),
      bubbles: true
    });
    el.dispatchEvent(event);
  };
}
var dummyDataPassingWatcher = {
  unsubscribe: () => {
  }
};
function makeDataPassingWatcher(watchId, callback) {
  const onEvent = (e9) => {
    const payload = getDataPassingEventValue(e9, watchId);
    if (payload === null) {
      return;
    }
    const value = payload.value;
    if (value === null || value === void 0) {
      return;
    }
    callback(payload);
  };
  window.addEventListener(DATA_PASSING_EVENT_ID, onEvent);
  return {
    unsubscribe: () => {
      window.removeEventListener(DATA_PASSING_EVENT_ID, onEvent);
    }
  };
}

// src/shiny/OptionalShiny.ts
var Shiny = window.Shiny;

// src/shiny/make-input-binding.ts
function makeInputBinding(tagName, { type = null } = {}) {
  if (!Shiny) {
    return;
  }
  class NewCustomBinding extends Shiny["InputBinding"] {
    constructor() {
      super();
    }
    find(scope) {
      return $(scope).find(tagName);
    }
    getValue(el) {
      if ("getValue" in el) {
        return el.getValue();
      } else {
        return el.value;
      }
    }
    getType(el) {
      return type;
    }
    subscribe(el, callback) {
      el.onChangeCallback = callback;
    }
    unsubscribe(el) {
      el.onChangeCallback = (x5) => {
      };
    }
  }
  Shiny.inputBindings.register(new NewCustomBinding(), `${tagName}-Binding`);
}

// src/color-picker.tsx
function ColorPickerReact({
  currentColorCallback
}) {
  const [currentColor, setCurrentColor] = Cn.useState("#fff");
  function handleChange(color) {
    setCurrentColor(color.hex);
    currentColorCallback(color.hex);
  }
  return /* @__PURE__ */ Cn.createElement(Sketch_default, { color: currentColor, onChange: handleChange });
}
var ColorPicker = class extends HTMLElement {
  constructor() {
    super();
    this.onValueChange = makeValueChangeEmitter(this, this.id);
    this.value = "#ffffff";
    this.onChangeCallback = (x5) => {
    };
  }
  currentColorCallback(x5) {
    this.value = x5;
    this.notifyChange();
  }
  notifyChange() {
    this.onChangeCallback(true);
    this.onValueChange({ type: "string", value: this.value });
  }
  connectedCallback() {
    const shadowRoot = this.attachShadow({ mode: "open" });
    const root2 = createRoot(shadowRoot);
    setTimeout(() => {
      this.notifyChange();
    }, 0);
    root2.render(
      /* @__PURE__ */ Cn.createElement(
        ColorPickerReact,
        {
          currentColorCallback: (x5) => this.currentColorCallback(x5)
        }
      )
    );
  }
};
customElements.define("color-picker", ColorPicker);
makeInputBinding("color-picker");

// src/design-preview.ts
var colors = [
  "primary",
  "action",
  "error",
  "bg",
  "bg-1",
  "bg-2",
  "border",
  "border-1",
  "border-2",
  "text",
  "text-1",
  "text-2"
].map((c5) => `--color-${c5}`);
var fontSizes = [
  "heading-1",
  "heading-2",
  "heading-3",
  "heading-4",
  "body",
  "small",
  "x-small"
].map((s7) => `--font-${s7}`);
var sml = ["small", "medium", "large"];
var shadows = sml.map((x5) => `--shadow-${x5}`);
var borders = sml.map((x5) => `--border-${x5}`);
var radii = sml.map((x5) => `--radius-${x5}`);
var spacings = ["x-small", ...sml, "x-large", "xx-large"].map(
  (s7) => `--space-${s7}`
);
var DesignPreview = class extends s4 {
  static {
    this.properties = {};
  }
  static {
    // Styles are scoped to this element: they won't conflict with styles
    // on the main page or in other components. Styling API can be exposed
    // via CSS custom properties.
    this.styles = i`
    :host {
      display: block;
      height: 100%;
      overflow: auto;
      position: relative;
      padding: var(--space-medium);
      color: var(--color-text);
    }

    :host > div {
      padding: var(--space-medium);
      position: relative;
      margin-block: var(--space-medium);
      outline: var(--border-small) solid var(--color-border);
      border-radius: var(--radius-small);
      box-shadow: var(--shadow-small);
    }

    .box-container {
      width: 100%;
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
      grid-gap: var(--space-medium);
    }

    .box {
      min-width: 0;
      max-width: 100%;
      aspect-ratio: 1;
      display: grid;
      align-items: end;
      border: 0 solid var(--color-border);
      box-shadow: var(--shadow-medium);
      border-radius: var(--radius-small);
      background-color: var(--color-bg-2);
      overflow: hidden;
    }

    .label {
      font-size: var(--font-x-small);
      font-family: var(--font-mono);
    }

    .box > div.label {
      background-color: var(--color-bg-1);
      padding-inline: var(--space-medium);
    }

    .font-sizes-container > p {
      padding: 0;
      margin: 0;
      line-height: var(--font-lineheight-5);
    }

    .spacings {
      display: flex;
      align-items: center;
      padding: var(--space-small);
      gap: var(--space-small);
    }
  `;
  }
  render() {
    return x`
      <div>
        <h2>Colors</h2>
        <div class="box-container">
          ${colors.map(
      (c5) => x`<div class="box" style="background-color: var(${c5})">
              <div class="label">${c5}</div>
            </div>`
    )}
        </div>
      </div>

      <div>
        <h2>Font Sizes</h2>
        <div class="font-sizes-container">
          ${fontSizes.map(
      (size) => x`<p class="font-size" style="font-size: var(${size})">
              ${size}
            </p>`
    )}
        </div>
      </div>

      <div>
        <h2>Border Widths</h2>
        <div class="box-container">
          ${borders.map(
      (border) => x`<div
              class="box"
              style="border-width: var(${border});"
            >
              <div class="label">${border}</div>
            </div>`
    )}
        </div>
      </div>

      <div>
        <h2>Radii</h2>
        <div class="box-container">
          ${radii.map(
      (r6) => x`<div class="box" style="border-radius: var(${r6});">
              <div class="label">${r6}</div>
            </div>`
    )}
        </div>
      </div>

      <div>
        <h2>Spacings</h2>
        <div>
          ${spacings.map(
      (s7) => x`
              <div class="spacings">
                <div
                  style="width: var(${s7}); aspect-ratio: 1; background-color: var(--color-primary);"
                ></div>
                <div class="label">${s7}</div>
              </div>
            `
    )}
        </div>
      </div>
      <div>
        <h2>Box Shadows</h2>
        <div class="box-container">
          ${shadows.map(
      (shadow) => x`<div
              class="box"
              style="box-shadow: var(${shadow});"
            >
              <div class="label">${shadow}</div>
            </div>`
    )}
        </div>
      </div>
    `;
  }
};
customElements.define("design-preview", DesignPreview);

// node_modules/@lit/reactive-element/decorators/custom-element.js
var e6 = (e9) => (n8) => "function" == typeof n8 ? ((e10, n9) => (customElements.define(e10, n9), n9))(e9, n8) : ((e10, n9) => {
  const { kind: t6, elements: s7 } = n9;
  return { kind: t6, elements: s7, finisher(n10) {
    customElements.define(e10, n10);
  } };
})(e9, n8);

// node_modules/@lit/reactive-element/decorators/property.js
var i5 = (i6, e9) => "method" === e9.kind && e9.descriptor && !("value" in e9.descriptor) ? { ...e9, finisher(n8) {
  n8.createProperty(e9.key, i6);
} } : { kind: "field", key: Symbol(), placement: "own", descriptor: {}, originalKey: e9.key, initializer() {
  "function" == typeof e9.initializer && (this[e9.key] = e9.initializer.call(this));
}, finisher(n8) {
  n8.createProperty(e9.key, i6);
} };
var e7 = (i6, e9, n8) => {
  e9.constructor.createProperty(n8, i6);
};
function n6(n8) {
  return (t6, o8) => void 0 !== o8 ? e7(n8, t6, o8) : i5(n8, t6);
}

// node_modules/@lit/reactive-element/decorators/state.js
function t5(t6) {
  return n6({ ...t6, state: true });
}

// node_modules/@lit/reactive-element/decorators/query-assigned-elements.js
var n7;
var e8 = null != (null === (n7 = window.HTMLSlotElement) || void 0 === n7 ? void 0 : n7.prototype.assignedElements) ? (o8, n8) => o8.assignedElements(n8) : (o8, n8) => o8.assignedNodes(n8).filter((o9) => o9.nodeType === Node.ELEMENT_NODE);

// src/set_el_attr.ts
function setElAttr(el, type, value) {
  const attr = document.createAttribute(type);
  attr.value = value;
  if (!el.attributes.getNamedItem(type)) {
    el.attributes.setNamedItem(attr);
  }
  return el;
}

// src/footer.ts
var DashboardFooter = class extends s4 {
  constructor() {
    super();
    setElAttr(this, "slot", "footer");
  }
  render() {
    return x`
      <div class="footer">
        <slot></slot>
      </div>
    `;
  }
};
DashboardFooter.properties = {};
// Styles are scoped to this element: they won't conflict with styles
// on the main page or in other components. Styling API can be exposed
// via CSS custom properties.
DashboardFooter.styles = i`
    :host {
      display: block;
      position: relative;
      width: 100%;
    }

    .footer {
      width: 100%;
      display: flex;
      justify-content: space-between;
    }
  `;
DashboardFooter = __decorateClass([
  e6("shiny-dashboard-footer")
], DashboardFooter);

// src/general-output.ts
var GeneralOutput = class extends s4 {
  constructor() {
    super(...arguments);
    this.value = null;
    this.watch = "";
    this.watcher = dummyDataPassingWatcher;
  }
  static {
    this.properties = {
      value: {},
      watch: { type: String }
    };
  }
  connectedCallback() {
    super.connectedCallback();
    this.watcher = makeDataPassingWatcher(this.watch, (payload) => {
      this.value = String(payload.value);
    });
  }
  render() {
    return x`<span class="value">${this.value}</span>`;
  }
};
customElements.define("general-output", GeneralOutput);

// src/grid.ts
var Grid = class extends s4 {
  constructor() {
    super(...arguments);
    this.nRows = 1;
    this.nCols = 2;
    this.alignItems = "stretch";
  }
  connectedCallback() {
    super.connectedCallback();
    this.style.setProperty("--nRows", this.nRows.toString());
    this.style.setProperty("--nCols", this.nCols.toString());
    this.style.setProperty("--align-items", this.alignItems);
  }
  render() {
    return x`<slot></slot>`;
  }
};
// Styles are scoped to this element: they won't conflict with styles
// on the main page or in other components. Styling API can be exposed
// via CSS custom properties.
Grid.styles = i`
    :host {
      display: grid;
      grid-template-columns: repeat(var(--nCols), 1fr);
      grid-template-rows: repeat(var(--nRows), 1fr);
      gap: var(--grid-gap, var(--size-m));
      align-items: var(--align-items);
      height: 100%;
    }

    * {
      box-sizing: border-box;
    }

    ::slotted(*) {
      min-height: 0;
      min-width: 0;
    }
  `;
__decorateClass([
  n6({ type: Number })
], Grid.prototype, "nRows", 2);
__decorateClass([
  n6({ type: Number })
], Grid.prototype, "nCols", 2);
__decorateClass([
  n6({ type: String })
], Grid.prototype, "alignItems", 2);
Grid = __decorateClass([
  e6("shiny-grid")
], Grid);

// src/grid-item.ts
var GridItem = class extends s4 {
  constructor() {
    super(...arguments);
    this.width = 1;
    this.height = 1;
    this.cardStyled = true;
  }
  static {
    this.styles = i`
    :host {
      display: flex;
      flex-direction: column;
    }
  `;
  }
  connectedCallback() {
    super.connectedCallback();
    this.style.setProperty(
      "grid-area",
      `span ${this.height} / span ${this.width}`
    );
  }
  render() {
    const children = x`<slot></slot>`;
    return this.cardStyled ? x`<shiny-card>${children}</shiny-card>` : children;
  }
};
__decorateClass([
  n6({ type: Number })
], GridItem.prototype, "width", 2);
__decorateClass([
  n6({ type: Number })
], GridItem.prototype, "height", 2);
__decorateClass([
  n6({ type: Boolean })
], GridItem.prototype, "cardStyled", 2);
customElements.define("shiny-grid-item", GridItem);

// node_modules/iconify-icon/dist/iconify-icon.mjs
var defaultIconDimensions = Object.freeze(
  {
    left: 0,
    top: 0,
    width: 16,
    height: 16
  }
);
var defaultIconTransformations = Object.freeze({
  rotate: 0,
  vFlip: false,
  hFlip: false
});
var defaultIconProps = Object.freeze({
  ...defaultIconDimensions,
  ...defaultIconTransformations
});
var defaultExtendedIconProps = Object.freeze({
  ...defaultIconProps,
  body: "",
  hidden: false
});
var defaultIconSizeCustomisations = Object.freeze({
  width: null,
  height: null
});
var defaultIconCustomisations = Object.freeze({
  // Dimensions
  ...defaultIconSizeCustomisations,
  // Transformations
  ...defaultIconTransformations
});
function rotateFromString(value, defaultValue = 0) {
  const units = value.replace(/^-?[0-9.]*/, "");
  function cleanup(value2) {
    while (value2 < 0) {
      value2 += 4;
    }
    return value2 % 4;
  }
  if (units === "") {
    const num = parseInt(value);
    return isNaN(num) ? 0 : cleanup(num);
  } else if (units !== value) {
    let split = 0;
    switch (units) {
      case "%":
        split = 25;
        break;
      case "deg":
        split = 90;
    }
    if (split) {
      let num = parseFloat(value.slice(0, value.length - units.length));
      if (isNaN(num)) {
        return 0;
      }
      num = num / split;
      return num % 1 === 0 ? cleanup(num) : 0;
    }
  }
  return defaultValue;
}
var separator = /[\s,]+/;
function flipFromString(custom, flip2) {
  flip2.split(separator).forEach((str) => {
    const value = str.trim();
    switch (value) {
      case "horizontal":
        custom.hFlip = true;
        break;
      case "vertical":
        custom.vFlip = true;
        break;
    }
  });
}
var defaultCustomisations = {
  ...defaultIconCustomisations,
  preserveAspectRatio: ""
};
function getCustomisations(node) {
  const customisations = {
    ...defaultCustomisations
  };
  const attr = (key, def) => node.getAttribute(key) || def;
  customisations.width = attr("width", null);
  customisations.height = attr("height", null);
  customisations.rotate = rotateFromString(attr("rotate", ""));
  flipFromString(customisations, attr("flip", ""));
  customisations.preserveAspectRatio = attr("preserveAspectRatio", attr("preserveaspectratio", ""));
  return customisations;
}
function haveCustomisationsChanged(value1, value2) {
  for (const key in defaultCustomisations) {
    if (value1[key] !== value2[key]) {
      return true;
    }
  }
  return false;
}
var matchIconName = /^[a-z0-9]+(-[a-z0-9]+)*$/;
var stringToIcon = (value, validate, allowSimpleName, provider = "") => {
  const colonSeparated = value.split(":");
  if (value.slice(0, 1) === "@") {
    if (colonSeparated.length < 2 || colonSeparated.length > 3) {
      return null;
    }
    provider = colonSeparated.shift().slice(1);
  }
  if (colonSeparated.length > 3 || !colonSeparated.length) {
    return null;
  }
  if (colonSeparated.length > 1) {
    const name2 = colonSeparated.pop();
    const prefix = colonSeparated.pop();
    const result = {
      // Allow provider without '@': "provider:prefix:name"
      provider: colonSeparated.length > 0 ? colonSeparated[0] : provider,
      prefix,
      name: name2
    };
    return validate && !validateIconName(result) ? null : result;
  }
  const name = colonSeparated[0];
  const dashSeparated = name.split("-");
  if (dashSeparated.length > 1) {
    const result = {
      provider,
      prefix: dashSeparated.shift(),
      name: dashSeparated.join("-")
    };
    return validate && !validateIconName(result) ? null : result;
  }
  if (allowSimpleName && provider === "") {
    const result = {
      provider,
      prefix: "",
      name
    };
    return validate && !validateIconName(result, allowSimpleName) ? null : result;
  }
  return null;
};
var validateIconName = (icon, allowSimpleName) => {
  if (!icon) {
    return false;
  }
  return !!((icon.provider === "" || icon.provider.match(matchIconName)) && (allowSimpleName && icon.prefix === "" || icon.prefix.match(matchIconName)) && icon.name.match(matchIconName));
};
function mergeIconTransformations(obj1, obj2) {
  const result = {};
  if (!obj1.hFlip !== !obj2.hFlip) {
    result.hFlip = true;
  }
  if (!obj1.vFlip !== !obj2.vFlip) {
    result.vFlip = true;
  }
  const rotate = ((obj1.rotate || 0) + (obj2.rotate || 0)) % 4;
  if (rotate) {
    result.rotate = rotate;
  }
  return result;
}
function mergeIconData(parent, child) {
  const result = mergeIconTransformations(parent, child);
  for (const key in defaultExtendedIconProps) {
    if (key in defaultIconTransformations) {
      if (key in parent && !(key in result)) {
        result[key] = defaultIconTransformations[key];
      }
    } else if (key in child) {
      result[key] = child[key];
    } else if (key in parent) {
      result[key] = parent[key];
    }
  }
  return result;
}
function getIconsTree(data, names2) {
  const icons = data.icons;
  const aliases = data.aliases || /* @__PURE__ */ Object.create(null);
  const resolved = /* @__PURE__ */ Object.create(null);
  function resolve(name) {
    if (icons[name]) {
      return resolved[name] = [];
    }
    if (!(name in resolved)) {
      resolved[name] = null;
      const parent = aliases[name] && aliases[name].parent;
      const value = parent && resolve(parent);
      if (value) {
        resolved[name] = [parent].concat(value);
      }
    }
    return resolved[name];
  }
  (names2 || Object.keys(icons).concat(Object.keys(aliases))).forEach(resolve);
  return resolved;
}
function internalGetIconData(data, name, tree) {
  const icons = data.icons;
  const aliases = data.aliases || /* @__PURE__ */ Object.create(null);
  let currentProps = {};
  function parse(name2) {
    currentProps = mergeIconData(
      icons[name2] || aliases[name2],
      currentProps
    );
  }
  parse(name);
  tree.forEach(parse);
  return mergeIconData(data, currentProps);
}
function parseIconSet(data, callback) {
  const names2 = [];
  if (typeof data !== "object" || typeof data.icons !== "object") {
    return names2;
  }
  if (data.not_found instanceof Array) {
    data.not_found.forEach((name) => {
      callback(name, null);
      names2.push(name);
    });
  }
  const tree = getIconsTree(data);
  for (const name in tree) {
    const item = tree[name];
    if (item) {
      callback(name, internalGetIconData(data, name, item));
      names2.push(name);
    }
  }
  return names2;
}
var optionalPropertyDefaults = {
  provider: "",
  aliases: {},
  not_found: {},
  ...defaultIconDimensions
};
function checkOptionalProps(item, defaults) {
  for (const prop in defaults) {
    if (prop in item && typeof item[prop] !== typeof defaults[prop]) {
      return false;
    }
  }
  return true;
}
function quicklyValidateIconSet(obj) {
  if (typeof obj !== "object" || obj === null) {
    return null;
  }
  const data = obj;
  if (typeof data.prefix !== "string" || !obj.icons || typeof obj.icons !== "object") {
    return null;
  }
  if (!checkOptionalProps(obj, optionalPropertyDefaults)) {
    return null;
  }
  const icons = data.icons;
  for (const name in icons) {
    const icon = icons[name];
    if (!name.match(matchIconName) || typeof icon.body !== "string" || !checkOptionalProps(
      icon,
      defaultExtendedIconProps
    )) {
      return null;
    }
  }
  const aliases = data.aliases || /* @__PURE__ */ Object.create(null);
  for (const name in aliases) {
    const icon = aliases[name];
    const parent = icon.parent;
    if (!name.match(matchIconName) || typeof parent !== "string" || !icons[parent] && !aliases[parent] || !checkOptionalProps(
      icon,
      defaultExtendedIconProps
    )) {
      return null;
    }
  }
  return data;
}
var dataStorage = /* @__PURE__ */ Object.create(null);
function newStorage(provider, prefix) {
  return {
    provider,
    prefix,
    icons: /* @__PURE__ */ Object.create(null),
    missing: /* @__PURE__ */ new Set()
  };
}
function getStorage(provider, prefix) {
  const providerStorage = dataStorage[provider] || (dataStorage[provider] = /* @__PURE__ */ Object.create(null));
  return providerStorage[prefix] || (providerStorage[prefix] = newStorage(provider, prefix));
}
function addIconSet(storage2, data) {
  if (!quicklyValidateIconSet(data)) {
    return [];
  }
  return parseIconSet(data, (name, icon) => {
    if (icon) {
      storage2.icons[name] = icon;
    } else {
      storage2.missing.add(name);
    }
  });
}
function addIconToStorage(storage2, name, icon) {
  try {
    if (typeof icon.body === "string") {
      storage2.icons[name] = { ...icon };
      return true;
    }
  } catch (err) {
  }
  return false;
}
function listIcons$1(provider, prefix) {
  let allIcons = [];
  const providers = typeof provider === "string" ? [provider] : Object.keys(dataStorage);
  providers.forEach((provider2) => {
    const prefixes = typeof provider2 === "string" && typeof prefix === "string" ? [prefix] : Object.keys(dataStorage[provider2] || {});
    prefixes.forEach((prefix2) => {
      const storage2 = getStorage(provider2, prefix2);
      allIcons = allIcons.concat(
        Object.keys(storage2.icons).map(
          (name) => (provider2 !== "" ? "@" + provider2 + ":" : "") + prefix2 + ":" + name
        )
      );
    });
  });
  return allIcons;
}
var simpleNames = false;
function allowSimpleNames(allow) {
  if (typeof allow === "boolean") {
    simpleNames = allow;
  }
  return simpleNames;
}
function getIconData(name) {
  const icon = typeof name === "string" ? stringToIcon(name, true, simpleNames) : name;
  if (icon) {
    const storage2 = getStorage(icon.provider, icon.prefix);
    const iconName = icon.name;
    return storage2.icons[iconName] || (storage2.missing.has(iconName) ? null : void 0);
  }
}
function addIcon$1(name, data) {
  const icon = stringToIcon(name, true, simpleNames);
  if (!icon) {
    return false;
  }
  const storage2 = getStorage(icon.provider, icon.prefix);
  return addIconToStorage(storage2, icon.name, data);
}
function addCollection$1(data, provider) {
  if (typeof data !== "object") {
    return false;
  }
  if (typeof provider !== "string") {
    provider = data.provider || "";
  }
  if (simpleNames && !provider && !data.prefix) {
    let added = false;
    if (quicklyValidateIconSet(data)) {
      data.prefix = "";
      parseIconSet(data, (name, icon) => {
        if (icon && addIcon$1(name, icon)) {
          added = true;
        }
      });
    }
    return added;
  }
  const prefix = data.prefix;
  if (!validateIconName({
    provider,
    prefix,
    name: "a"
  })) {
    return false;
  }
  const storage2 = getStorage(provider, prefix);
  return !!addIconSet(storage2, data);
}
function iconExists$1(name) {
  return !!getIconData(name);
}
function getIcon$1(name) {
  const result = getIconData(name);
  return result ? {
    ...defaultIconProps,
    ...result
  } : null;
}
function sortIcons(icons) {
  const result = {
    loaded: [],
    missing: [],
    pending: []
  };
  const storage2 = /* @__PURE__ */ Object.create(null);
  icons.sort((a5, b4) => {
    if (a5.provider !== b4.provider) {
      return a5.provider.localeCompare(b4.provider);
    }
    if (a5.prefix !== b4.prefix) {
      return a5.prefix.localeCompare(b4.prefix);
    }
    return a5.name.localeCompare(b4.name);
  });
  let lastIcon = {
    provider: "",
    prefix: "",
    name: ""
  };
  icons.forEach((icon) => {
    if (lastIcon.name === icon.name && lastIcon.prefix === icon.prefix && lastIcon.provider === icon.provider) {
      return;
    }
    lastIcon = icon;
    const provider = icon.provider;
    const prefix = icon.prefix;
    const name = icon.name;
    const providerStorage = storage2[provider] || (storage2[provider] = /* @__PURE__ */ Object.create(null));
    const localStorage = providerStorage[prefix] || (providerStorage[prefix] = getStorage(provider, prefix));
    let list;
    if (name in localStorage.icons) {
      list = result.loaded;
    } else if (prefix === "" || localStorage.missing.has(name)) {
      list = result.missing;
    } else {
      list = result.pending;
    }
    const item = {
      provider,
      prefix,
      name
    };
    list.push(item);
  });
  return result;
}
function removeCallback(storages, id) {
  storages.forEach((storage2) => {
    const items = storage2.loaderCallbacks;
    if (items) {
      storage2.loaderCallbacks = items.filter((row) => row.id !== id);
    }
  });
}
function updateCallbacks(storage2) {
  if (!storage2.pendingCallbacksFlag) {
    storage2.pendingCallbacksFlag = true;
    setTimeout(() => {
      storage2.pendingCallbacksFlag = false;
      const items = storage2.loaderCallbacks ? storage2.loaderCallbacks.slice(0) : [];
      if (!items.length) {
        return;
      }
      let hasPending = false;
      const provider = storage2.provider;
      const prefix = storage2.prefix;
      items.forEach((item) => {
        const icons = item.icons;
        const oldLength = icons.pending.length;
        icons.pending = icons.pending.filter((icon) => {
          if (icon.prefix !== prefix) {
            return true;
          }
          const name = icon.name;
          if (storage2.icons[name]) {
            icons.loaded.push({
              provider,
              prefix,
              name
            });
          } else if (storage2.missing.has(name)) {
            icons.missing.push({
              provider,
              prefix,
              name
            });
          } else {
            hasPending = true;
            return true;
          }
          return false;
        });
        if (icons.pending.length !== oldLength) {
          if (!hasPending) {
            removeCallback([storage2], item.id);
          }
          item.callback(
            icons.loaded.slice(0),
            icons.missing.slice(0),
            icons.pending.slice(0),
            item.abort
          );
        }
      });
    });
  }
}
var idCounter2 = 0;
function storeCallback(callback, icons, pendingSources) {
  const id = idCounter2++;
  const abort = removeCallback.bind(null, pendingSources, id);
  if (!icons.pending.length) {
    return abort;
  }
  const item = {
    id,
    icons,
    callback,
    abort
  };
  pendingSources.forEach((storage2) => {
    (storage2.loaderCallbacks || (storage2.loaderCallbacks = [])).push(item);
  });
  return abort;
}
var storage = /* @__PURE__ */ Object.create(null);
function setAPIModule(provider, item) {
  storage[provider] = item;
}
function getAPIModule(provider) {
  return storage[provider] || storage[""];
}
function listToIcons(list, validate = true, simpleNames2 = false) {
  const result = [];
  list.forEach((item) => {
    const icon = typeof item === "string" ? stringToIcon(item, validate, simpleNames2) : item;
    if (icon) {
      result.push(icon);
    }
  });
  return result;
}
var defaultConfig = {
  resources: [],
  index: 0,
  timeout: 2e3,
  rotate: 750,
  random: false,
  dataAfterTimeout: false
};
function sendQuery(config, payload, query, done) {
  const resourcesCount = config.resources.length;
  const startIndex = config.random ? Math.floor(Math.random() * resourcesCount) : config.index;
  let resources;
  if (config.random) {
    let list = config.resources.slice(0);
    resources = [];
    while (list.length > 1) {
      const nextIndex = Math.floor(Math.random() * list.length);
      resources.push(list[nextIndex]);
      list = list.slice(0, nextIndex).concat(list.slice(nextIndex + 1));
    }
    resources = resources.concat(list);
  } else {
    resources = config.resources.slice(startIndex).concat(config.resources.slice(0, startIndex));
  }
  const startTime = Date.now();
  let status = "pending";
  let queriesSent = 0;
  let lastError;
  let timer = null;
  let queue = [];
  let doneCallbacks = [];
  if (typeof done === "function") {
    doneCallbacks.push(done);
  }
  function resetTimer() {
    if (timer) {
      clearTimeout(timer);
      timer = null;
    }
  }
  function abort() {
    if (status === "pending") {
      status = "aborted";
    }
    resetTimer();
    queue.forEach((item) => {
      if (item.status === "pending") {
        item.status = "aborted";
      }
    });
    queue = [];
  }
  function subscribe(callback, overwrite) {
    if (overwrite) {
      doneCallbacks = [];
    }
    if (typeof callback === "function") {
      doneCallbacks.push(callback);
    }
  }
  function getQueryStatus() {
    return {
      startTime,
      payload,
      status,
      queriesSent,
      queriesPending: queue.length,
      subscribe,
      abort
    };
  }
  function failQuery() {
    status = "failed";
    doneCallbacks.forEach((callback) => {
      callback(void 0, lastError);
    });
  }
  function clearQueue() {
    queue.forEach((item) => {
      if (item.status === "pending") {
        item.status = "aborted";
      }
    });
    queue = [];
  }
  function moduleResponse(item, response, data) {
    const isError = response !== "success";
    queue = queue.filter((queued) => queued !== item);
    switch (status) {
      case "pending":
        break;
      case "failed":
        if (isError || !config.dataAfterTimeout) {
          return;
        }
        break;
      default:
        return;
    }
    if (response === "abort") {
      lastError = data;
      failQuery();
      return;
    }
    if (isError) {
      lastError = data;
      if (!queue.length) {
        if (!resources.length) {
          failQuery();
        } else {
          execNext();
        }
      }
      return;
    }
    resetTimer();
    clearQueue();
    if (!config.random) {
      const index = config.resources.indexOf(item.resource);
      if (index !== -1 && index !== config.index) {
        config.index = index;
      }
    }
    status = "completed";
    doneCallbacks.forEach((callback) => {
      callback(data);
    });
  }
  function execNext() {
    if (status !== "pending") {
      return;
    }
    resetTimer();
    const resource = resources.shift();
    if (resource === void 0) {
      if (queue.length) {
        timer = setTimeout(() => {
          resetTimer();
          if (status === "pending") {
            clearQueue();
            failQuery();
          }
        }, config.timeout);
        return;
      }
      failQuery();
      return;
    }
    const item = {
      status: "pending",
      resource,
      callback: (status2, data) => {
        moduleResponse(item, status2, data);
      }
    };
    queue.push(item);
    queriesSent++;
    timer = setTimeout(execNext, config.rotate);
    query(resource, payload, item.callback);
  }
  setTimeout(execNext);
  return getQueryStatus;
}
function initRedundancy(cfg) {
  const config = {
    ...defaultConfig,
    ...cfg
  };
  let queries = [];
  function cleanup() {
    queries = queries.filter((item) => item().status === "pending");
  }
  function query(payload, queryCallback, doneCallback) {
    const query2 = sendQuery(
      config,
      payload,
      queryCallback,
      (data, error) => {
        cleanup();
        if (doneCallback) {
          doneCallback(data, error);
        }
      }
    );
    queries.push(query2);
    return query2;
  }
  function find(callback) {
    return queries.find((value) => {
      return callback(value);
    }) || null;
  }
  const instance = {
    query,
    find,
    setIndex: (index) => {
      config.index = index;
    },
    getIndex: () => config.index,
    cleanup
  };
  return instance;
}
function createAPIConfig(source) {
  let resources;
  if (typeof source.resources === "string") {
    resources = [source.resources];
  } else {
    resources = source.resources;
    if (!(resources instanceof Array) || !resources.length) {
      return null;
    }
  }
  const result = {
    resources,
    path: source.path || "/",
    maxURL: source.maxURL || 500,
    rotate: source.rotate || 750,
    timeout: source.timeout || 5e3,
    random: source.random === true,
    index: source.index || 0,
    dataAfterTimeout: source.dataAfterTimeout !== false
  };
  return result;
}
var configStorage = /* @__PURE__ */ Object.create(null);
var fallBackAPISources = [
  "https://api.simplesvg.com",
  "https://api.unisvg.com"
];
var fallBackAPI = [];
while (fallBackAPISources.length > 0) {
  if (fallBackAPISources.length === 1) {
    fallBackAPI.push(fallBackAPISources.shift());
  } else {
    if (Math.random() > 0.5) {
      fallBackAPI.push(fallBackAPISources.shift());
    } else {
      fallBackAPI.push(fallBackAPISources.pop());
    }
  }
}
configStorage[""] = createAPIConfig({
  resources: ["https://api.iconify.design"].concat(fallBackAPI)
});
function addAPIProvider$1(provider, customConfig) {
  const config = createAPIConfig(customConfig);
  if (config === null) {
    return false;
  }
  configStorage[provider] = config;
  return true;
}
function getAPIConfig(provider) {
  return configStorage[provider];
}
function listAPIProviders() {
  return Object.keys(configStorage);
}
function emptyCallback$1() {
}
var redundancyCache = /* @__PURE__ */ Object.create(null);
function getRedundancyCache(provider) {
  if (!redundancyCache[provider]) {
    const config = getAPIConfig(provider);
    if (!config) {
      return;
    }
    const redundancy = initRedundancy(config);
    const cachedReundancy = {
      config,
      redundancy
    };
    redundancyCache[provider] = cachedReundancy;
  }
  return redundancyCache[provider];
}
function sendAPIQuery(target, query, callback) {
  let redundancy;
  let send2;
  if (typeof target === "string") {
    const api = getAPIModule(target);
    if (!api) {
      callback(void 0, 424);
      return emptyCallback$1;
    }
    send2 = api.send;
    const cached = getRedundancyCache(target);
    if (cached) {
      redundancy = cached.redundancy;
    }
  } else {
    const config = createAPIConfig(target);
    if (config) {
      redundancy = initRedundancy(config);
      const moduleKey = target.resources ? target.resources[0] : "";
      const api = getAPIModule(moduleKey);
      if (api) {
        send2 = api.send;
      }
    }
  }
  if (!redundancy || !send2) {
    callback(void 0, 424);
    return emptyCallback$1;
  }
  return redundancy.query(query, send2, callback)().abort;
}
var browserCacheVersion = "iconify2";
var browserCachePrefix = "iconify";
var browserCacheCountKey = browserCachePrefix + "-count";
var browserCacheVersionKey = browserCachePrefix + "-version";
var browserStorageHour = 36e5;
var browserStorageCacheExpiration = 168;
function getStoredItem(func, key) {
  try {
    return func.getItem(key);
  } catch (err) {
  }
}
function setStoredItem(func, key, value) {
  try {
    func.setItem(key, value);
    return true;
  } catch (err) {
  }
}
function removeStoredItem(func, key) {
  try {
    func.removeItem(key);
  } catch (err) {
  }
}
function setBrowserStorageItemsCount(storage2, value) {
  return setStoredItem(storage2, browserCacheCountKey, value.toString());
}
function getBrowserStorageItemsCount(storage2) {
  return parseInt(getStoredItem(storage2, browserCacheCountKey)) || 0;
}
var browserStorageConfig = {
  local: true,
  session: true
};
var browserStorageEmptyItems = {
  local: /* @__PURE__ */ new Set(),
  session: /* @__PURE__ */ new Set()
};
var browserStorageStatus = false;
function setBrowserStorageStatus(status) {
  browserStorageStatus = status;
}
var _window = typeof window === "undefined" ? {} : window;
function getBrowserStorage(key) {
  const attr = key + "Storage";
  try {
    if (_window && _window[attr] && typeof _window[attr].length === "number") {
      return _window[attr];
    }
  } catch (err) {
  }
  browserStorageConfig[key] = false;
}
function iterateBrowserStorage(key, callback) {
  const func = getBrowserStorage(key);
  if (!func) {
    return;
  }
  const version = getStoredItem(func, browserCacheVersionKey);
  if (version !== browserCacheVersion) {
    if (version) {
      const total2 = getBrowserStorageItemsCount(func);
      for (let i6 = 0; i6 < total2; i6++) {
        removeStoredItem(func, browserCachePrefix + i6.toString());
      }
    }
    setStoredItem(func, browserCacheVersionKey, browserCacheVersion);
    setBrowserStorageItemsCount(func, 0);
    return;
  }
  const minTime = Math.floor(Date.now() / browserStorageHour) - browserStorageCacheExpiration;
  const parseItem = (index) => {
    const name = browserCachePrefix + index.toString();
    const item = getStoredItem(func, name);
    if (typeof item !== "string") {
      return;
    }
    try {
      const data = JSON.parse(item);
      if (typeof data === "object" && typeof data.cached === "number" && data.cached > minTime && typeof data.provider === "string" && typeof data.data === "object" && typeof data.data.prefix === "string" && callback(data, index)) {
        return true;
      }
    } catch (err) {
    }
    removeStoredItem(func, name);
  };
  let total = getBrowserStorageItemsCount(func);
  for (let i6 = total - 1; i6 >= 0; i6--) {
    if (!parseItem(i6)) {
      if (i6 === total - 1) {
        total--;
        setBrowserStorageItemsCount(func, total);
      } else {
        browserStorageEmptyItems[key].add(i6);
      }
    }
  }
}
function initBrowserStorage() {
  if (browserStorageStatus) {
    return;
  }
  setBrowserStorageStatus(true);
  for (const key in browserStorageConfig) {
    iterateBrowserStorage(key, (item) => {
      const iconSet = item.data;
      const provider = item.provider;
      const prefix = iconSet.prefix;
      const storage2 = getStorage(
        provider,
        prefix
      );
      if (!addIconSet(storage2, iconSet).length) {
        return false;
      }
      const lastModified = iconSet.lastModified || -1;
      storage2.lastModifiedCached = storage2.lastModifiedCached ? Math.min(storage2.lastModifiedCached, lastModified) : lastModified;
      return true;
    });
  }
}
function updateLastModified(storage2, lastModified) {
  const lastValue = storage2.lastModifiedCached;
  if (lastValue && lastValue >= lastModified) {
    return lastValue === lastModified;
  }
  storage2.lastModifiedCached = lastModified;
  if (lastValue) {
    for (const key in browserStorageConfig) {
      iterateBrowserStorage(key, (item) => {
        const iconSet = item.data;
        return item.provider !== storage2.provider || iconSet.prefix !== storage2.prefix || iconSet.lastModified === lastModified;
      });
    }
  }
  return true;
}
function storeInBrowserStorage(storage2, data) {
  if (!browserStorageStatus) {
    initBrowserStorage();
  }
  function store(key) {
    let func;
    if (!browserStorageConfig[key] || !(func = getBrowserStorage(key))) {
      return;
    }
    const set = browserStorageEmptyItems[key];
    let index;
    if (set.size) {
      set.delete(index = Array.from(set).shift());
    } else {
      index = getBrowserStorageItemsCount(func);
      if (!setBrowserStorageItemsCount(func, index + 1)) {
        return;
      }
    }
    const item = {
      cached: Math.floor(Date.now() / browserStorageHour),
      provider: storage2.provider,
      data
    };
    return setStoredItem(
      func,
      browserCachePrefix + index.toString(),
      JSON.stringify(item)
    );
  }
  if (data.lastModified && !updateLastModified(storage2, data.lastModified)) {
    return;
  }
  if (!Object.keys(data.icons).length) {
    return;
  }
  if (data.not_found) {
    data = Object.assign({}, data);
    delete data.not_found;
  }
  if (!store("local")) {
    store("session");
  }
}
function emptyCallback() {
}
function loadedNewIcons(storage2) {
  if (!storage2.iconsLoaderFlag) {
    storage2.iconsLoaderFlag = true;
    setTimeout(() => {
      storage2.iconsLoaderFlag = false;
      updateCallbacks(storage2);
    });
  }
}
function loadNewIcons(storage2, icons) {
  if (!storage2.iconsToLoad) {
    storage2.iconsToLoad = icons;
  } else {
    storage2.iconsToLoad = storage2.iconsToLoad.concat(icons).sort();
  }
  if (!storage2.iconsQueueFlag) {
    storage2.iconsQueueFlag = true;
    setTimeout(() => {
      storage2.iconsQueueFlag = false;
      const { provider, prefix } = storage2;
      const icons2 = storage2.iconsToLoad;
      delete storage2.iconsToLoad;
      let api;
      if (!icons2 || !(api = getAPIModule(provider))) {
        return;
      }
      const params = api.prepare(provider, prefix, icons2);
      params.forEach((item) => {
        sendAPIQuery(provider, item, (data) => {
          if (typeof data !== "object") {
            item.icons.forEach((name) => {
              storage2.missing.add(name);
            });
          } else {
            try {
              const parsed = addIconSet(
                storage2,
                data
              );
              if (!parsed.length) {
                return;
              }
              const pending = storage2.pendingIcons;
              if (pending) {
                parsed.forEach((name) => {
                  pending.delete(name);
                });
              }
              storeInBrowserStorage(storage2, data);
            } catch (err) {
              console.error(err);
            }
          }
          loadedNewIcons(storage2);
        });
      });
    });
  }
}
var loadIcons$1 = (icons, callback) => {
  const cleanedIcons = listToIcons(icons, true, allowSimpleNames());
  const sortedIcons = sortIcons(cleanedIcons);
  if (!sortedIcons.pending.length) {
    let callCallback = true;
    if (callback) {
      setTimeout(() => {
        if (callCallback) {
          callback(
            sortedIcons.loaded,
            sortedIcons.missing,
            sortedIcons.pending,
            emptyCallback
          );
        }
      });
    }
    return () => {
      callCallback = false;
    };
  }
  const newIcons = /* @__PURE__ */ Object.create(null);
  const sources = [];
  let lastProvider, lastPrefix;
  sortedIcons.pending.forEach((icon) => {
    const { provider, prefix } = icon;
    if (prefix === lastPrefix && provider === lastProvider) {
      return;
    }
    lastProvider = provider;
    lastPrefix = prefix;
    sources.push(getStorage(provider, prefix));
    const providerNewIcons = newIcons[provider] || (newIcons[provider] = /* @__PURE__ */ Object.create(null));
    if (!providerNewIcons[prefix]) {
      providerNewIcons[prefix] = [];
    }
  });
  sortedIcons.pending.forEach((icon) => {
    const { provider, prefix, name } = icon;
    const storage2 = getStorage(provider, prefix);
    const pendingQueue = storage2.pendingIcons || (storage2.pendingIcons = /* @__PURE__ */ new Set());
    if (!pendingQueue.has(name)) {
      pendingQueue.add(name);
      newIcons[provider][prefix].push(name);
    }
  });
  sources.forEach((storage2) => {
    const { provider, prefix } = storage2;
    if (newIcons[provider][prefix].length) {
      loadNewIcons(storage2, newIcons[provider][prefix]);
    }
  });
  return callback ? storeCallback(callback, sortedIcons, sources) : emptyCallback;
};
var loadIcon$1 = (icon) => {
  return new Promise((fulfill, reject) => {
    const iconObj = typeof icon === "string" ? stringToIcon(icon, true) : icon;
    if (!iconObj) {
      reject(icon);
      return;
    }
    loadIcons$1([iconObj || icon], (loaded) => {
      if (loaded.length && iconObj) {
        const data = getIconData(iconObj);
        if (data) {
          fulfill({
            ...defaultIconProps,
            ...data
          });
          return;
        }
      }
      reject(icon);
    });
  });
};
function testIconObject(value) {
  try {
    const obj = typeof value === "string" ? JSON.parse(value) : value;
    if (typeof obj.body === "string") {
      return {
        ...obj
      };
    }
  } catch (err) {
  }
}
function parseIconValue(value, onload) {
  const name = typeof value === "string" ? stringToIcon(value, true, true) : null;
  if (!name) {
    const data2 = testIconObject(value);
    return {
      value,
      data: data2
    };
  }
  const data = getIconData(name);
  if (data !== void 0 || !name.prefix) {
    return {
      value,
      name,
      data
      // could be 'null' -> icon is missing
    };
  }
  const loading = loadIcons$1([name], () => onload(value, name, getIconData(name)));
  return {
    value,
    name,
    loading
  };
}
function getInline(node) {
  return node.hasAttribute("inline");
}
var isBuggedSafari = false;
try {
  isBuggedSafari = navigator.vendor.indexOf("Apple") === 0;
} catch (err) {
}
function getRenderMode(body, mode) {
  switch (mode) {
    case "svg":
    case "bg":
    case "mask":
      return mode;
  }
  if (mode !== "style" && (isBuggedSafari || body.indexOf("<a") === -1)) {
    return "svg";
  }
  return body.indexOf("currentColor") === -1 ? "bg" : "mask";
}
var unitsSplit = /(-?[0-9.]*[0-9]+[0-9.]*)/g;
var unitsTest = /^-?[0-9.]*[0-9]+[0-9.]*$/g;
function calculateSize$1(size, ratio, precision) {
  if (ratio === 1) {
    return size;
  }
  precision = precision || 100;
  if (typeof size === "number") {
    return Math.ceil(size * ratio * precision) / precision;
  }
  if (typeof size !== "string") {
    return size;
  }
  const oldParts = size.split(unitsSplit);
  if (oldParts === null || !oldParts.length) {
    return size;
  }
  const newParts = [];
  let code = oldParts.shift();
  let isNumber = unitsTest.test(code);
  while (true) {
    if (isNumber) {
      const num = parseFloat(code);
      if (isNaN(num)) {
        newParts.push(code);
      } else {
        newParts.push(Math.ceil(num * ratio * precision) / precision);
      }
    } else {
      newParts.push(code);
    }
    code = oldParts.shift();
    if (code === void 0) {
      return newParts.join("");
    }
    isNumber = !isNumber;
  }
}
var isUnsetKeyword = (value) => value === "unset" || value === "undefined" || value === "none";
function iconToSVG(icon, customisations) {
  const fullIcon = {
    ...defaultIconProps,
    ...icon
  };
  const fullCustomisations = {
    ...defaultIconCustomisations,
    ...customisations
  };
  const box = {
    left: fullIcon.left,
    top: fullIcon.top,
    width: fullIcon.width,
    height: fullIcon.height
  };
  let body = fullIcon.body;
  [fullIcon, fullCustomisations].forEach((props) => {
    const transformations = [];
    const hFlip = props.hFlip;
    const vFlip = props.vFlip;
    let rotation = props.rotate;
    if (hFlip) {
      if (vFlip) {
        rotation += 2;
      } else {
        transformations.push(
          "translate(" + (box.width + box.left).toString() + " " + (0 - box.top).toString() + ")"
        );
        transformations.push("scale(-1 1)");
        box.top = box.left = 0;
      }
    } else if (vFlip) {
      transformations.push(
        "translate(" + (0 - box.left).toString() + " " + (box.height + box.top).toString() + ")"
      );
      transformations.push("scale(1 -1)");
      box.top = box.left = 0;
    }
    let tempValue;
    if (rotation < 0) {
      rotation -= Math.floor(rotation / 4) * 4;
    }
    rotation = rotation % 4;
    switch (rotation) {
      case 1:
        tempValue = box.height / 2 + box.top;
        transformations.unshift(
          "rotate(90 " + tempValue.toString() + " " + tempValue.toString() + ")"
        );
        break;
      case 2:
        transformations.unshift(
          "rotate(180 " + (box.width / 2 + box.left).toString() + " " + (box.height / 2 + box.top).toString() + ")"
        );
        break;
      case 3:
        tempValue = box.width / 2 + box.left;
        transformations.unshift(
          "rotate(-90 " + tempValue.toString() + " " + tempValue.toString() + ")"
        );
        break;
    }
    if (rotation % 2 === 1) {
      if (box.left !== box.top) {
        tempValue = box.left;
        box.left = box.top;
        box.top = tempValue;
      }
      if (box.width !== box.height) {
        tempValue = box.width;
        box.width = box.height;
        box.height = tempValue;
      }
    }
    if (transformations.length) {
      body = '<g transform="' + transformations.join(" ") + '">' + body + "</g>";
    }
  });
  const customisationsWidth = fullCustomisations.width;
  const customisationsHeight = fullCustomisations.height;
  const boxWidth = box.width;
  const boxHeight = box.height;
  let width;
  let height;
  if (customisationsWidth === null) {
    height = customisationsHeight === null ? "1em" : customisationsHeight === "auto" ? boxHeight : customisationsHeight;
    width = calculateSize$1(height, boxWidth / boxHeight);
  } else {
    width = customisationsWidth === "auto" ? boxWidth : customisationsWidth;
    height = customisationsHeight === null ? calculateSize$1(width, boxHeight / boxWidth) : customisationsHeight === "auto" ? boxHeight : customisationsHeight;
  }
  const attributes = {};
  const setAttr = (prop, value) => {
    if (!isUnsetKeyword(value)) {
      attributes[prop] = value.toString();
    }
  };
  setAttr("width", width);
  setAttr("height", height);
  attributes.viewBox = box.left.toString() + " " + box.top.toString() + " " + boxWidth.toString() + " " + boxHeight.toString();
  return {
    attributes,
    body
  };
}
var detectFetch = () => {
  let callback;
  try {
    callback = fetch;
    if (typeof callback === "function") {
      return callback;
    }
  } catch (err) {
  }
};
var fetchModule = detectFetch();
function setFetch(fetch2) {
  fetchModule = fetch2;
}
function getFetch() {
  return fetchModule;
}
function calculateMaxLength(provider, prefix) {
  const config = getAPIConfig(provider);
  if (!config) {
    return 0;
  }
  let result;
  if (!config.maxURL) {
    result = 0;
  } else {
    let maxHostLength = 0;
    config.resources.forEach((item) => {
      const host = item;
      maxHostLength = Math.max(maxHostLength, host.length);
    });
    const url = prefix + ".json?icons=";
    result = config.maxURL - maxHostLength - config.path.length - url.length;
  }
  return result;
}
function shouldAbort(status) {
  return status === 404;
}
var prepare = (provider, prefix, icons) => {
  const results = [];
  const maxLength = calculateMaxLength(provider, prefix);
  const type = "icons";
  let item = {
    type,
    provider,
    prefix,
    icons: []
  };
  let length = 0;
  icons.forEach((name, index) => {
    length += name.length + 1;
    if (length >= maxLength && index > 0) {
      results.push(item);
      item = {
        type,
        provider,
        prefix,
        icons: []
      };
      length = name.length;
    }
    item.icons.push(name);
  });
  results.push(item);
  return results;
};
function getPath(provider) {
  if (typeof provider === "string") {
    const config = getAPIConfig(provider);
    if (config) {
      return config.path;
    }
  }
  return "/";
}
var send = (host, params, callback) => {
  if (!fetchModule) {
    callback("abort", 424);
    return;
  }
  let path = getPath(params.provider);
  switch (params.type) {
    case "icons": {
      const prefix = params.prefix;
      const icons = params.icons;
      const iconsList = icons.join(",");
      const urlParams = new URLSearchParams({
        icons: iconsList
      });
      path += prefix + ".json?" + urlParams.toString();
      break;
    }
    case "custom": {
      const uri = params.uri;
      path += uri.slice(0, 1) === "/" ? uri.slice(1) : uri;
      break;
    }
    default:
      callback("abort", 400);
      return;
  }
  let defaultError = 503;
  fetchModule(host + path).then((response) => {
    const status = response.status;
    if (status !== 200) {
      setTimeout(() => {
        callback(shouldAbort(status) ? "abort" : "next", status);
      });
      return;
    }
    defaultError = 501;
    return response.json();
  }).then((data) => {
    if (typeof data !== "object" || data === null) {
      setTimeout(() => {
        if (data === 404) {
          callback("abort", data);
        } else {
          callback("next", defaultError);
        }
      });
      return;
    }
    setTimeout(() => {
      callback("success", data);
    });
  }).catch(() => {
    callback("next", defaultError);
  });
};
var fetchAPIModule = {
  prepare,
  send
};
function toggleBrowserCache(storage2, value) {
  switch (storage2) {
    case "local":
    case "session":
      browserStorageConfig[storage2] = value;
      break;
    case "all":
      for (const key in browserStorageConfig) {
        browserStorageConfig[key] = value;
      }
      break;
  }
}
var nodeAttr = "data-style";
var customStyle = "";
function appendCustomStyle(style) {
  customStyle = style;
}
function updateStyle(parent, inline) {
  let styleNode = Array.from(parent.childNodes).find((node) => node.hasAttribute && node.hasAttribute(nodeAttr));
  if (!styleNode) {
    styleNode = document.createElement("style");
    styleNode.setAttribute(nodeAttr, nodeAttr);
    parent.appendChild(styleNode);
  }
  styleNode.textContent = ":host{display:inline-block;vertical-align:" + (inline ? "-0.125em" : "0") + "}span,svg{display:block}" + customStyle;
}
function exportFunctions() {
  setAPIModule("", fetchAPIModule);
  allowSimpleNames(true);
  let _window2;
  try {
    _window2 = window;
  } catch (err) {
  }
  if (_window2) {
    initBrowserStorage();
    if (_window2.IconifyPreload !== void 0) {
      const preload = _window2.IconifyPreload;
      const err = "Invalid IconifyPreload syntax.";
      if (typeof preload === "object" && preload !== null) {
        (preload instanceof Array ? preload : [preload]).forEach((item) => {
          try {
            if (
              // Check if item is an object and not null/array
              typeof item !== "object" || item === null || item instanceof Array || // Check for 'icons' and 'prefix'
              typeof item.icons !== "object" || typeof item.prefix !== "string" || // Add icon set
              !addCollection$1(item)
            ) {
              console.error(err);
            }
          } catch (e9) {
            console.error(err);
          }
        });
      }
    }
    if (_window2.IconifyProviders !== void 0) {
      const providers = _window2.IconifyProviders;
      if (typeof providers === "object" && providers !== null) {
        for (const key in providers) {
          const err = "IconifyProviders[" + key + "] is invalid.";
          try {
            const value = providers[key];
            if (typeof value !== "object" || !value || value.resources === void 0) {
              continue;
            }
            if (!addAPIProvider$1(key, value)) {
              console.error(err);
            }
          } catch (e9) {
            console.error(err);
          }
        }
      }
    }
  }
  const _api2 = {
    getAPIConfig,
    setAPIModule,
    sendAPIQuery,
    setFetch,
    getFetch,
    listAPIProviders
  };
  return {
    enableCache: (storage2) => toggleBrowserCache(storage2, true),
    disableCache: (storage2) => toggleBrowserCache(storage2, false),
    iconExists: iconExists$1,
    getIcon: getIcon$1,
    listIcons: listIcons$1,
    addIcon: addIcon$1,
    addCollection: addCollection$1,
    calculateSize: calculateSize$1,
    buildIcon: iconToSVG,
    loadIcons: loadIcons$1,
    loadIcon: loadIcon$1,
    addAPIProvider: addAPIProvider$1,
    appendCustomStyle,
    _api: _api2
  };
}
function iconToHTML(body, attributes) {
  let renderAttribsHTML = body.indexOf("xlink:") === -1 ? "" : ' xmlns:xlink="http://www.w3.org/1999/xlink"';
  for (const attr in attributes) {
    renderAttribsHTML += " " + attr + '="' + attributes[attr] + '"';
  }
  return '<svg xmlns="http://www.w3.org/2000/svg"' + renderAttribsHTML + ">" + body + "</svg>";
}
function encodeSVGforURL(svg) {
  return svg.replace(/"/g, "'").replace(/%/g, "%25").replace(/#/g, "%23").replace(/</g, "%3C").replace(/>/g, "%3E").replace(/\s+/g, " ");
}
function svgToURL(svg) {
  return 'url("data:image/svg+xml,' + encodeSVGforURL(svg) + '")';
}
var monotoneProps = {
  "background-color": "currentColor"
};
var coloredProps = {
  "background-color": "transparent"
};
var propsToAdd = {
  image: "var(--svg)",
  repeat: "no-repeat",
  size: "100% 100%"
};
var propsToAddTo = {
  "-webkit-mask": monotoneProps,
  "mask": monotoneProps,
  "background": coloredProps
};
for (const prefix in propsToAddTo) {
  const list = propsToAddTo[prefix];
  for (const prop in propsToAdd) {
    list[prefix + "-" + prop] = propsToAdd[prop];
  }
}
function fixSize(value) {
  return value ? value + (value.match(/^[-0-9.]+$/) ? "px" : "") : "inherit";
}
function renderSPAN(data, icon, useMask) {
  const node = document.createElement("span");
  let body = data.body;
  if (body.indexOf("<a") !== -1) {
    body += "<!-- " + Date.now() + " -->";
  }
  const renderAttribs = data.attributes;
  const html = iconToHTML(body, {
    ...renderAttribs,
    width: icon.width + "",
    height: icon.height + ""
  });
  const url = svgToURL(html);
  const svgStyle = node.style;
  const styles = {
    "--svg": url,
    "width": fixSize(renderAttribs.width),
    "height": fixSize(renderAttribs.height),
    ...useMask ? monotoneProps : coloredProps
  };
  for (const prop in styles) {
    svgStyle.setProperty(prop, styles[prop]);
  }
  return node;
}
function renderSVG(data) {
  const node = document.createElement("span");
  const attr = data.attributes;
  let style = "";
  if (!attr.width) {
    style = "width: inherit;";
  }
  if (!attr.height) {
    style += "height: inherit;";
  }
  if (style) {
    attr.style = style;
  }
  node.innerHTML = iconToHTML(data.body, attr);
  return node.firstChild;
}
function renderIcon(parent, state) {
  const iconData = state.icon.data;
  const customisations = state.customisations;
  const renderData = iconToSVG(iconData, customisations);
  if (customisations.preserveAspectRatio) {
    renderData.attributes["preserveAspectRatio"] = customisations.preserveAspectRatio;
  }
  const mode = state.renderedMode;
  let node;
  switch (mode) {
    case "svg":
      node = renderSVG(renderData);
      break;
    default:
      node = renderSPAN(renderData, {
        ...defaultIconProps,
        ...iconData
      }, mode === "mask");
  }
  const oldNode = Array.from(parent.childNodes).find((node2) => {
    const tag = node2.tagName && node2.tagName.toUpperCase();
    return tag === "SPAN" || tag === "SVG";
  });
  if (oldNode) {
    if (node.tagName === "SPAN" && oldNode.tagName === node.tagName) {
      oldNode.setAttribute("style", node.getAttribute("style"));
    } else {
      parent.replaceChild(node, oldNode);
    }
  } else {
    parent.appendChild(node);
  }
}
function setPendingState(icon, inline, lastState) {
  const lastRender = lastState && (lastState.rendered ? lastState : lastState.lastRender);
  return {
    rendered: false,
    inline,
    icon,
    lastRender
  };
}
function defineIconifyIcon(name = "iconify-icon") {
  let customElements2;
  let ParentClass;
  try {
    customElements2 = window.customElements;
    ParentClass = window.HTMLElement;
  } catch (err) {
    return;
  }
  if (!customElements2 || !ParentClass) {
    return;
  }
  const ConflictingClass = customElements2.get(name);
  if (ConflictingClass) {
    return ConflictingClass;
  }
  const attributes = [
    // Icon
    "icon",
    // Mode
    "mode",
    "inline",
    // Customisations
    "width",
    "height",
    "rotate",
    "flip"
  ];
  const IconifyIcon = class extends ParentClass {
    // Root
    _shadowRoot;
    // State
    _state;
    // Attributes check queued
    _checkQueued = false;
    /**
     * Constructor
     */
    constructor() {
      super();
      const root2 = this._shadowRoot = this.attachShadow({
        mode: "open"
      });
      const inline = getInline(this);
      updateStyle(root2, inline);
      this._state = setPendingState({
        value: ""
      }, inline);
      this._queueCheck();
    }
    /**
     * Observed attributes
     */
    static get observedAttributes() {
      return attributes.slice(0);
    }
    /**
     * Observed properties that are different from attributes
     *
     * Experimental! Need to test with various frameworks that support it
     */
    /*
    static get properties() {
        return {
            inline: {
                type: Boolean,
                reflect: true,
            },
            // Not listing other attributes because they are strings or combination
            // of string and another type. Cannot have multiple types
        };
    }
    */
    /**
     * Attribute has changed
     */
    attributeChangedCallback(name2) {
      if (name2 === "inline") {
        const newInline = getInline(this);
        const state = this._state;
        if (newInline !== state.inline) {
          state.inline = newInline;
          updateStyle(this._shadowRoot, newInline);
        }
      } else {
        this._queueCheck();
      }
    }
    /**
     * Get/set icon
     */
    get icon() {
      const value = this.getAttribute("icon");
      if (value && value.slice(0, 1) === "{") {
        try {
          return JSON.parse(value);
        } catch (err) {
        }
      }
      return value;
    }
    set icon(value) {
      if (typeof value === "object") {
        value = JSON.stringify(value);
      }
      this.setAttribute("icon", value);
    }
    /**
     * Get/set inline
     */
    get inline() {
      return getInline(this);
    }
    set inline(value) {
      if (value) {
        this.setAttribute("inline", "true");
      } else {
        this.removeAttribute("inline");
      }
    }
    /**
     * Restart animation
     */
    restartAnimation() {
      const state = this._state;
      if (state.rendered) {
        const root2 = this._shadowRoot;
        if (state.renderedMode === "svg") {
          try {
            root2.lastChild.setCurrentTime(0);
            return;
          } catch (err) {
          }
        }
        renderIcon(root2, state);
      }
    }
    /**
     * Get status
     */
    get status() {
      const state = this._state;
      return state.rendered ? "rendered" : state.icon.data === null ? "failed" : "loading";
    }
    /**
     * Queue attributes re-check
     */
    _queueCheck() {
      if (!this._checkQueued) {
        this._checkQueued = true;
        setTimeout(() => {
          this._check();
        });
      }
    }
    /**
     * Check for changes
     */
    _check() {
      if (!this._checkQueued) {
        return;
      }
      this._checkQueued = false;
      const state = this._state;
      const newIcon = this.getAttribute("icon");
      if (newIcon !== state.icon.value) {
        this._iconChanged(newIcon);
        return;
      }
      if (!state.rendered) {
        return;
      }
      const mode = this.getAttribute("mode");
      const customisations = getCustomisations(this);
      if (state.attrMode !== mode || haveCustomisationsChanged(state.customisations, customisations)) {
        this._renderIcon(state.icon, customisations, mode);
      }
    }
    /**
     * Icon value has changed
     */
    _iconChanged(newValue) {
      const icon = parseIconValue(newValue, (value, name2, data) => {
        const state = this._state;
        if (state.rendered || this.getAttribute("icon") !== value) {
          return;
        }
        const icon2 = {
          value,
          name: name2,
          data
        };
        if (icon2.data) {
          this._gotIconData(icon2);
        } else {
          state.icon = icon2;
        }
      });
      if (icon.data) {
        this._gotIconData(icon);
      } else {
        this._state = setPendingState(icon, this._state.inline, this._state);
      }
    }
    /**
     * Got new icon data, icon is ready to (re)render
     */
    _gotIconData(icon) {
      this._checkQueued = false;
      this._renderIcon(icon, getCustomisations(this), this.getAttribute("mode"));
    }
    /**
     * Re-render based on icon data
     */
    _renderIcon(icon, customisations, attrMode) {
      const renderedMode = getRenderMode(icon.data.body, attrMode);
      const inline = this._state.inline;
      renderIcon(this._shadowRoot, this._state = {
        rendered: true,
        icon,
        inline,
        customisations,
        attrMode,
        renderedMode
      });
    }
  };
  attributes.forEach((attr) => {
    if (!(attr in IconifyIcon.prototype)) {
      Object.defineProperty(IconifyIcon.prototype, attr, {
        get: function() {
          return this.getAttribute(attr);
        },
        set: function(value) {
          if (value !== null) {
            this.setAttribute(attr, value);
          } else {
            this.removeAttribute(attr);
          }
        }
      });
    }
  });
  const functions = exportFunctions();
  for (const key in functions) {
    IconifyIcon[key] = IconifyIcon.prototype[key] = functions[key];
  }
  customElements2.define(name, IconifyIcon);
  return IconifyIcon;
}
var IconifyIconComponent = defineIconifyIcon() || exportFunctions();
var { enableCache, disableCache, iconExists, getIcon, listIcons, addIcon, addCollection, calculateSize, buildIcon, loadIcons, loadIcon, addAPIProvider, _api } = IconifyIconComponent;

// src/icon.ts
var ShinyIcon = class extends s4 {
  constructor() {
    super(...arguments);
    this.name = "info-circle";
  }
  /**
   * Renders the ShinyIcon element.
   * @returns {TemplateResult} The rendered template for the ShinyIcon element.
   */
  render() {
    return x`<iconify-icon icon="${this.name}"></iconify-icon>`;
  }
};
/**
 * The styles for the ShinyIcon element.
 * @static
 * @property {CSSResult} styles
 */
ShinyIcon.styles = i`
    :host {
      display: inline-block;
      height: 1em;
    }
  `;
__decorateClass([
  n6()
], ShinyIcon.prototype, "name", 2);
ShinyIcon = __decorateClass([
  e6("shiny-icon")
], ShinyIcon);

// src/output_plot.ts
var OutputPlot = class extends s4 {
  connectedCallback() {
    super.connectedCallback();
    if (this.height) {
      this.style.setProperty("--plot-h", `${this.height}px`);
    }
  }
  render() {
    return x`<div class="plot"></div>`;
  }
};
OutputPlot.styles = i`
    * {
      box-sizing: border-box;
      min-width: 0;
    }

    :host {
      display: block;
      height: var(--plot-h, 400px);
      flex: 1 1 auto;
    }

    :host([height]) {
      flex: 0 0 var(--plot-h, 400px);
    }

    .plot {
      background-image: var(--gradient-17);
      height: 100%;
    }
  `;
__decorateClass([
  n6({ reflect: true })
], OutputPlot.prototype, "height", 2);
OutputPlot = __decorateClass([
  e6("output-plot")
], OutputPlot);

// src/posit-logo.ts
var PositLogo = class extends s4 {
  constructor() {
    super(...arguments);
    this.withName = false;
    this.width = 40;
    this.height = 40;
  }
  render() {
    const nameText = this.withName ? x`<path
          class="masked-path"
          d="M87.818 9.225c7.25 0 12.361 4.903 12.361 11.713S95.069 32.61 87.818 32.61c-7.252 0-12.275-4.903-12.275-11.672 0-6.768 5.023-11.713 12.275-11.713Zm0 17.528c3.451 0 5.81-2.17 5.81-5.815 0-3.644-2.62-5.856-5.81-5.856-3.19 0-5.723 2.125-5.723 5.856 0 3.299 2.316 5.815 5.723 5.815ZM128.042 0c2.053 0 3.538 1.46 3.538 3.389 0 2.026-1.485 3.484-3.538 3.484-2.227 0-3.583-1.458-3.583-3.484S125.944 0 128.042 0Zm-3.19 9.65h6.335v22.563h-6.335V9.65ZM134.045 9.65h4.325V4.4h6.334v5.25h6.845v5.857h-6.845v7.332c0 2.733.611 3.775 2.316 3.775 1.485 0 2.665-.52 3.887-1.475l3.227 3.973c-1.574 1.65-4.625 3.359-7.725 3.359-4.761 0-8.037-2.561-8.037-7.767v-9.199h-4.325V9.648l-.002.003ZM155.519 11.998h-.504v-1.942h-.644v-.417h1.791v.417h-.643v1.942ZM157.466 11.998l-.572-1.85h-.014c.021.377.031.629.031.754v1.096h-.45V9.639h.686l.562 1.803h.009l.595-1.803h.686v2.359h-.468V10.88c0-.053 0-.114.002-.181 0-.07.01-.251.021-.55h-.014l-.611 1.848h-.463ZM121.573 12.41c-1.553-1.48-4.773-3.392-9.346-3.392-6.512 0-10.343 2.675-10.343 7.062 0 6.808 10.917 6.973 13.495 8.476.466.258.742.618.576 1.142-.485 1.51-6.603 2.247-11.116-2.087l-3.681 4.36c1.639 2.155 5.255 4.686 11.121 4.686 5.449 0 10.16-2.193 10.16-7.192 0-4.482-4.203-6.285-7.94-7.34-1.064-.291-2.092-.531-2.981-.768-1.473-.375-3.447-.796-3.131-1.889.574-1.986 7.142-.742 9.439 1.347l3.754-4.403-.007-.003ZM50.88 9.704h6.344v1.175c1.18-1.087 3.326-1.652 5.077-1.652 6.913 0 11.203 4.738 11.203 11.432S69.04 32.654 62.125 32.654c-2.187 0-4.2-.346-4.9-1.13V41H50.88V9.704Zm6.344 7.955v7.215c.7 1.042 2.232 1.912 4.026 1.912 3.545 0 5.688-2.217 5.688-5.65 0-3.998-2.012-6.04-5.34-6.04-2.1 0-3.542 1.041-4.374 2.563Z"
          fill="#404041"
        ></path>` : null;
    return x`
      <svg width="1em" height="1em" viewBox="0 0 41 41" fill="none">
        <path
          d="m10.043 24.362 1.855.83 8.577-3.625-1.909-.808-8.523 3.603Z"
          fill="#447099"
        ></path>
        <path
          d="m12.034 16.384-1.874.821 8.404 3.555 1.909-.808-8.44-3.568Z"
          fill="#447099"
        ></path>
        <path
          d="m32.67 16.41-1.873-.824-8.474-3.719-1.85-.812L0 2.074v10.836l8.278 3.5 1.873-.822-8.657-3.66V4.353l17.13 7.515 1.849.814 8.44 3.703 1.873.821 5.973 2.622v1.944l-5.882 2.58-1.873.823-8.662 3.8-1.836.808-17.012 7.464v-7.655l8.53-3.607-1.854-.828L0 28.61v10.916L20.337 30.6l1.836-.805 8.716-3.826 1.873-.821 5.491-2.41v-3.88l-5.582-2.45Z"
          fill="#447099"
        ></path>
        <path
          d="m22.38 20.76 8.404-3.555-1.874-.82-8.44 3.567-1.907.807 1.908.808L29 25.174l1.874-.823-8.496-3.591ZM39.45 29.591v7.94l-17.278-7.737-1.836.807 20.611 9.227V28.61l-8.186-3.461-1.874.821 8.564 3.622ZM40.948 2.073l-20.475 8.983 1.85.811 17.129-7.515v7.576l-8.655 3.658 1.873.824 8.278-3.5V2.072Z"
          fill="#ED642F"
        ></path>
        <path
          d="m10.04 24.362-5.852-2.59v-1.945l5.97-2.622 1.874-.82 8.44-3.706-1.85-.812-8.473 3.72-1.875.823-5.583 2.449v3.88l5.478 2.416 1.854.83 8.482 3.797 1.835-.807-8.446-3.782-1.854-.83Z"
          fill="#ED642F"
        ></path>
        <path
          d="m10.043 24.362 1.855.83 8.577-3.625-1.909-.808-8.523 3.603Z"
          fill="#447099"
        ></path>
        <path
          d="m12.034 16.384-1.874.821 8.404 3.555 1.909-.808-8.44-3.568Z"
          fill="#447099"
        ></path>
        <path
          d="m32.67 16.41-1.873-.824-8.474-3.719-1.85-.812L0 2.074v10.836l8.278 3.5 1.873-.822-8.657-3.66V4.353l17.13 7.515 1.849.814 8.44 3.703 1.873.821 5.973 2.622v1.944l-5.882 2.58-1.873.823-8.662 3.8-1.836.808-17.012 7.464v-7.655l8.53-3.607-1.854-.828L0 28.61v10.916L20.337 30.6l1.836-.805 8.716-3.826 1.873-.821 5.491-2.41v-3.88l-5.582-2.45Z"
          fill="#447099"
        ></path>
        <path
          d="m22.38 20.76 8.404-3.555-1.874-.82-8.44 3.567-1.907.807 1.908.808L29 25.174l1.874-.823-8.496-3.591ZM39.45 29.591v7.94l-17.278-7.737-1.836.807 20.611 9.227V28.61l-8.186-3.461-1.874.821 8.564 3.622ZM40.948 2.073l-20.475 8.983 1.85.811 17.129-7.515v7.576l-8.655 3.658 1.873.824 8.278-3.5V2.072Z"
          fill="#ED642F"
        ></path>
        <path
          d="m10.04 24.362-5.852-2.59v-1.945l5.97-2.622 1.874-.82 8.44-3.706-1.85-.812-8.473 3.72-1.875.823-5.583 2.449v3.88l5.478 2.416 1.854.83 8.482 3.797 1.835-.807-8.446-3.782-1.854-.83Z"
          fill="#ED642F"
        ></path>
        ${nameText}
      </svg>
    `;
  }
};
PositLogo.styles = i`
    svg {
      translate: 0 3.5px;
    }
  `;
__decorateClass([
  n6({ type: Boolean })
], PositLogo.prototype, "withName", 2);
__decorateClass([
  n6({ type: Number })
], PositLogo.prototype, "width", 2);
__decorateClass([
  n6({ type: Number })
], PositLogo.prototype, "height", 2);
PositLogo = __decorateClass([
  e6("posit-logo")
], PositLogo);

// src/styles/op-classes.ts
var surface1 = i`
  background-color: var(--surface-1);
  color: var(--text-2);
`;
var themePrimitives = {
  brand: i`
    color: var(--brand);
    background-color: var(--brand);
  `,
  surface_1: i`
    background-color: var(--surface-1);
    color: var(--text-1);
  `,
  surface_2: i`
    background-color: var(--surface-2);
    color: var(--text-1);
  `,
  surface_3: i`
    background-color: var(--surface-3);
    color: var(--text-1);
  `,
  surface_4: i`
    background-color: var(--surface-4);
    color: var(--text-1);
  `,
  fancy_shadow: i`
    border: 1px solid hsl(var(--brand-hue) 10% 50% / 15%);
    box-shadow: 0 1rem 0.5rem -0.5rem;
    box-shadow: 0 2.8px 2.2px
        hsl(var(--shadow-color) / calc(var(--shadow-strength) + 3%)),
      0 6.7px 5.3px hsl(var(--shadow-color) / calc(var(--shadow-strength) + 1%)),
      0 12.5px 10px hsl(var(--shadow-color) / calc(var(--shadow-strength) + 2%)),
      0 22.3px 17.9px
        hsl(var(--shadow-color) / calc(var(--shadow-strength) + 2%)),
      0 41.8px 33.4px
        hsl(var(--shadow-color) / calc(var(--shadow-strength) + 3%)),
      0 100px 80px hsl(var(--shadow-color) / var(--shadow-strength));
  `,
  /**
   * A series of definitions that will reset text in a component to use standards without having to manually assign everything.
   */
  text_reset: i`
    :where(h1, h2, h3, h4, h5, h6) {
      line-height: var(--line-height-headings);
      font-weight: var(--font-weight-headings);
    }

    :where(h1) {
      font-size: var(--font-size-h1);
    }

    :where(h2) {
      font-size: var(--font-size-h2);
    }

    :where(h3) {
      font-size: var(--font-size-h3);
    }

    :where(h4) {
      font-size: var(--font-size-h4);
    }

    :where(h5) {
      font-size: var(--font-size-h5);
    }

    :where(p, ul, ol, dl, h6) {
      font-size: var(--font-size-m);
    }

    :where(a, u, ins, abbr) {
      text-underline-offset: 1px;

      @supports (-moz-appearance: none) {
        text-underline-offset: 2px;
      }
    }
  `
};

// src/shiny-avatar.ts
var ShinyAvatar = class extends s4 {
  constructor() {
    super(...arguments);
    this.size = 40;
    this.src = "";
    this.alt = "Avatar photo";
    this.variant = "circle";
    this.name = "";
    this.inline = true;
  }
  render() {
    return x`<span class="name">${this.name}</span>
      <img
        class="${this.variant}"
        style="width:${this.size}px;"
        src="${this.src}"
        alt="${this.alt}"
      />`;
  }
};
// Styles are scoped to this element: they won't conflict with styles
// on the main page or in other components. Styling API can be exposed
// via CSS custom properties.
ShinyAvatar.styles = i`
    :host {
      display: flex;
      align-items: center;
      gap: var(--size-s);
    }

    :host([inline]) {
      display: inline-flex;
    }

    img {
      aspect-ratio: 1;

      ${themePrimitives.fancy_shadow}
    }

    img.circle {
      border-radius: var(--radius-round);
    }

    img.blob {
      border-radius: var(--radius-blob-2);
    }

    .name {
      font-size: var(--font-size-m);
    }

    .name:empty {
      display: none;
    }

    * {
      box-sizing: border-box;
      min-width: 0;
    }
  `;
__decorateClass([
  n6()
], ShinyAvatar.prototype, "size", 2);
__decorateClass([
  n6()
], ShinyAvatar.prototype, "src", 2);
__decorateClass([
  n6()
], ShinyAvatar.prototype, "alt", 2);
__decorateClass([
  n6()
], ShinyAvatar.prototype, "variant", 2);
__decorateClass([
  n6()
], ShinyAvatar.prototype, "name", 2);
__decorateClass([
  n6({ type: Boolean, reflect: true })
], ShinyAvatar.prototype, "inline", 2);
ShinyAvatar = __decorateClass([
  e6("shiny-avatar")
], ShinyAvatar);

// src/shiny-card.ts
var ShinyCard = class extends s4 {
  constructor() {
    super(...arguments);
    this.centercontent = false;
    this.nofill = false;
  }
  connectedCallback() {
    super.connectedCallback();
    if (this.height) {
      const height = typeof this.height === "number" ? `${this.height}px` : this.height;
      this.style.setProperty("--card-h", height);
    }
  }
  render() {
    return x`
      <div class="header">
        <slot name="header"></slot>
      </div>
      <div class="sidebar">
        <slot name="sidebar"></slot>
      </div>
      <div class="body">
        <slot></slot>
      </div>
      <div class="footer">
        <slot name="footer"></slot>
      </div>
    `;
  }
};
ShinyCard.styles = i`
    * {
      box-sizing: border-box;
    }

    :host {
      --card-padding: var(--item-padding, var(--size-m));

      ${themePrimitives.surface_1}

      /* We use inline-size here because the more broad "size" value will force
      this element to declare its height explicitely. We only really care about
      width for container queries so that's fine. This is a funny gotcha though
      that isn't obvious */
      container-type: inline-size;
      border: var(--border-standard);
      border-radius: var(--card-radius, var(--radius-m));
      box-shadow: var(--card-shadow, var(--shadow-m));
      background-color: var(--card-bg, var(--surface-1));
      overflow: hidden;
      flex: 1 1 auto;
      display: grid;
      grid-template:
        "header header" auto
        "sidebar body" 1fr
        "footer footer" auto /
        auto 1fr;
      isolation: isolate;
    }

    :host([height]) {
      height: var(--card-h);
      flex: 0 0 var(--card-h);
    }

    :host([height="content"]) {
      height: fit-content;
      flex-basis: content;
    }

    .header {
      grid-area: header;
      z-index: 3;
      position: relative;
    }

    .footer {
      grid-area: footer;
      z-index: 2;
      position: relative;
    }

    .sidebar {
      grid-area: sidebar;
      position: relative;
      z-index: 1;
    }

    .body {
      /* For some reason this prevents scrollbars from appearing when they arent
      needed on wide contents... I wish there was a more satisfying solution */
      display: flex;
      grid-area: body;
      flex-direction: column;
      padding: var(--card-padding);
      gap: var(--spacing, var(--size-s));
      overflow: auto;
      z-index: 0;
    }

    :host([nofill]) .body {
      display: block;
    }

    /* Make block-layout slotted children stretch without neccesary needing to
    specify it themselves. This will leave text alone etc. It's unclear if this
    list should be expanded or not or if this is too strong of a selector but it
    seems reasonable. */
    ::slotted(:is(div, section)) {
      flex: 1;
    }

    /* Need to set all children as block display to keep behavior similar to flex */
    :host([nofill]) .body > ::slotted(*) {
      display: block;
      border-radius: var(--child-radius);
    }

    :host([centercontent]) .body {
      display: grid;
      place-content: center;
      overflow: auto;
    }
  `;
__decorateClass([
  n6()
], ShinyCard.prototype, "height", 2);
__decorateClass([
  n6({ type: Boolean, reflect: true })
], ShinyCard.prototype, "centercontent", 2);
__decorateClass([
  n6({ type: Boolean, reflect: true })
], ShinyCard.prototype, "nofill", 2);
ShinyCard = __decorateClass([
  e6("shiny-card")
], ShinyCard);
var ShinyCardSlot = class extends s4 {
  static {
    this.styles = i`
    * {
      box-sizing: border-box;
    }

    :host {
      --card-padding: var(--item-padding, var(--size-m));

      display: block;
      padding-inline: var(--card-padding);
      padding-block: var(--card-padding);
    }

    :host([slot="header"]) {
      border-bottom: var(--border-standard);
    }

    :host([slot="footer"]) {
      border-top: var(--border-standard);
    }

    ::slotted(*) {
      margin: 0;
    }
  `;
  }
  render() {
    return x`<slot></slot>`;
  }
};
var ShinyCardHeader = class extends ShinyCardSlot {
  constructor() {
    super();
    setElAttr(this, "slot", "header");
  }
};
ShinyCardHeader = __decorateClass([
  e6("shiny-card-header")
], ShinyCardHeader);
var ShinyCardFooter = class extends ShinyCardSlot {
  constructor() {
    super();
    setElAttr(this, "slot", "footer");
  }
};
ShinyCardFooter = __decorateClass([
  e6("shiny-card-footer")
], ShinyCardFooter);

// src/tab.ts
var Tab = class extends s4 {
  constructor() {
    super(...arguments);
    this.name = "tab";
    this.icon = "";
  }
  render() {
    return x` <slot></slot> `;
  }
};
/**
 * Styles are scoped to this element: they won't conflict with styles
 * on the main page or in other components. Styling API can be exposed
 * via CSS custom properties.
 */
Tab.styles = i`
    :host {
      display: block;
      position: relative;
      height: 100%;
      min-height: 0;
      width: 100%;
      min-width: 0;
      padding: var(--tab-padding);
    }
  `;
__decorateClass([
  n6({ type: String })
], Tab.prototype, "name", 2);
__decorateClass([
  n6({ type: String })
], Tab.prototype, "icon", 2);
Tab = __decorateClass([
  e6("shiny-tab")
], Tab);
var TabLabel = class extends s4 {
  render() {
    return x`<slot></slot>`;
  }
};
TabLabel.styles = [
  i`
      :host {
        display: flex;
        align-items: center;
        gap: var(--size-xxs);
      }
    `
];
TabLabel = __decorateClass([
  e6("tab-label")
], TabLabel);

// src/utils/getElementsFromSlotChangeEvent.ts
function getElementsFromSlotChangeEvent(e9) {
  const slot = e9.target;
  if (!slot)
    return [];
  return slot.assignedNodes({ flatten: true }).filter((node) => {
    return node instanceof HTMLElement && !/^\s*$/.test(node.innerHTML);
  });
}

// src/shiny-dashboard.ts
var ShinyDashboard = class extends s4 {
  constructor() {
    super(...arguments);
    this.dynamicHeight = false;
    this.selectedTabIndex = 0;
    this.tabsOnSide = false;
    this.tabs = [];
    this.hasHeaderContents = false;
    this.onChangeCallback = (x5) => {
    };
  }
  // Watch for additions the header slot. If they exist we make sure they're
  // legit and show the header.
  watchHeaderSlot(e9) {
    this.hasHeaderContents = getElementsFromSlotChangeEvent(e9).length > 0;
  }
  watchMainSlot(e9) {
    this.tabs = extractTabsFromElements(getElementsFromSlotChangeEvent(e9));
    console.log("Tab search results", this.tabs);
    this.selectTab();
  }
  selectTab(tabIndex = this.selectedTabIndex) {
    this.selectedTabIndex = tabIndex;
    selectTabByIndex(this.tabs, tabIndex);
    this.onChangeCallback(true);
  }
  // Callback used in the select input for mobile mode tab selection
  handleTabSelect(event) {
    const selectedTabName = event.target.value.replaceAll("_", " ");
    const selectedTabIndex = this.tabs.findIndex(
      (tab) => tab.name === selectedTabName
    );
    this.selectTab(selectedTabIndex);
  }
  currentTabName() {
    return this.tabs[this.selectedTabIndex].name;
  }
  getValue() {
    return this.currentTabName();
  }
  showHeader() {
    if (this.hasHeaderContents)
      return true;
    if (this.tabs.length > 0 && !this.tabsOnSide)
      return true;
    return false;
  }
  render() {
    const tabs = this.tabs.map((tab, i6) => {
      const isSelected = i6 === this.selectedTabIndex;
      return x`<div
        class="tab ${isSelected ? "selected-tab" : ""}"
        @click=${() => this.selectTab(i6)}
        title=${isSelected ? `Current: ${tab.name}` : `Switch to: ${tab.name}`}
      >
        ${tab.label}
      </div>`;
    });
    const tabContainer = x`<div
      class="nav ${this.tabsOnSide ? "sidebar-nav" : ""}"
    >
      <div class="nav-slot before-nav">
        <slot name="before_navigation"></slot>
      </div>
      <div class="tabs">${tabs}</div>
      <div class="mobile-tabs">
        <sl-select
          @sl-change=${this.handleTabSelect}
          value=${this.tabs[this.selectedTabIndex]?.value ?? ""}
        >
          ${this.tabs.map(
      (tab) => x`<sl-option value="${tab.value}">${tab.name}</sl-option>`
    )}
        </sl-select>
      </div>
      <div class="nav-slot after-nav">
        <slot name="after_navigation"></slot>
      </div>
    </div>`;
    return x`
      <div class="tabset">
        ${this.tabsOnSide ? tabContainer : ""}
        <div class="header ${this.showHeader() ? "" : "empty-header"}">
          <slot name="header" @slotchange=${this.watchHeaderSlot}></slot>
          ${this.tabsOnSide ? "" : tabContainer}
        </div>
        <div class="sidebar">
          <slot name="sidebar"></slot>
        </div>
        <div class="main">
          <slot @slotchange=${this.watchMainSlot}></slot>
        </div>
        <div class="footer">
          <slot name="footer"></slot>
        </div>
      </div>
    `;
  }
};
ShinyDashboard.styles = i`
    * {
      box-sizing: border-box;
    }

    :host {
      --padding: var(--size-m);
      --page-h: 100%;

      ${themePrimitives.surface_3}

      display: block;
      height: 100%;
      container-type: inline-size;
      overflow: auto;
    }

    :host([dynamicHeight]) {
      --page-h: auto;
    }

    .tabset {
      height: var(--page-h);
      width: 100%;
      display: grid;
      grid-template:
        "nav sidebar header" auto
        "nav sidebar content" 1fr
        "nav sidebar footer" auto /
        auto auto 1fr;
      isolation: isolate;
    }

    .tabset > * {
      min-width: 0;
      min-height: 0;
    }

    .sidebar {
      z-index: 3;
      padding: 0;
      grid-area: sidebar;

      ${themePrimitives.surface_1}
    }

    .main {
      z-index: 1;
      grid-area: content;
      padding: var(--padding);
    }

    .header,
    .footer {
      /* Use background image if passed */
      background-image: var(--header-bg-image);
      z-index: 2;
      margin: 0;
      display: flex;
      align-items: center;
      gap: var(--padding);
    }

    .header {
      grid-area: header;
    }

    .header.empty-header {
      display: none;
    }

    .header-right {
      margin-left: auto;
    }

    .nav {
      /* Some variables that control the little bars that demarkate tabs and
      also show what is selected */
      --tab-border-color: var(--text-2);

      grid-area: nav;
      display: flex;
      flex-flow: row nowrap;
      width: 100%;
      align-items: baseline;
      justify-content: space-between;
      border-block-end: 1px solid var(--border-color);
      padding: var(--size-m);
      gap: var(--size-s);
      background-color: var(--surface-1);
    }

    .tab {
      cursor: pointer;
      position: relative;
      padding-inline: var(--size-m);

      /* Use the container padding for the top of the tab */
      padding-block: var(--size-xs);
      color: var(--text-1);

      /* Add elipses to prevent overflow for tab names that are too long */
      overflow: hidden;
      white-space: nowrap;
      text-overflow: ellipsis;
      transition: background-color var(--transition-fast);
      border-radius: var(--radius-s);
    }

    .selected-tab {
      background-color: var(--surface-3);
    }

    .nav.sidebar-nav {
      overflow: auto;
      flex-flow: column nowrap;
      border-inline-end: 1px solid var(--border-color);
      border-block-end: unset;
    }

    :host([tabsOnSide]) .after-nav {
      margin-block-start: auto;
    }

    .sidebar-nav .tab {
      flex-shrink: 0;
    }

    .nav .mobile-tabs {
      display: none;
    }

    .nav > * {
      flex-shrink: 5;
    }

    .tabs {
      flex-shrink: 1;
      display: flex;
      align-items: end;
      row-gap: var(--size-xs);
      position: relative;
      width: auto;
      border-radius: var(--radius-s);
      background-color: var(--surface-1);
      overflow: hidden;
      gap: var(--size-xs);
    }

    .sidebar-nav .tabs {
      border-width: 1;
      min-width: unset;
      flex-flow: column nowrap;
      align-items: stretch;
      overflow: auto;
      max-width: var(--size-content-1);
    }

    .tab:last-child {
      border-inline-end: unset;
    }

    .tab:hover:not(.selected-tab) {
      background-color: var(--surface-4);
    }

    :host([tabsOnSide]) .tab {
      padding-block: var(--size-xs);
      border-inline-end: unset;
    }

    .footer {
      grid-area: footer;
    }

    .footer > ::slotted(*) {
      padding: var(--padding);
      padding-block-start: 0;
    }

    .header > ::slotted(div) {
      margin: 0;
      padding: 0;
    }

    /* Mobile styles */

    .mobile-tabs select {
      background-color: inherit;
      accent-color: pink;
    }

    @container (width < 500px) {
      /* Hide the tabs and show the select */
      .nav:not(.sidebar-nav) .mobile-tabs {
        display: unset;
      }

      .nav:not(.sidebar-nav) .tabs {
        display: none;
      }
    }
  `;
__decorateClass([
  n6({ type: Boolean })
], ShinyDashboard.prototype, "dynamicHeight", 2);
__decorateClass([
  n6({ type: Number })
], ShinyDashboard.prototype, "selectedTabIndex", 2);
__decorateClass([
  n6({ type: Boolean })
], ShinyDashboard.prototype, "tabsOnSide", 2);
__decorateClass([
  t5()
], ShinyDashboard.prototype, "tabs", 2);
__decorateClass([
  t5()
], ShinyDashboard.prototype, "hasHeaderContents", 2);
ShinyDashboard = __decorateClass([
  e6("shiny-dashboard")
], ShinyDashboard);
makeInputBinding("shiny-dashboard");
function extractTabsFromElements(elements) {
  const tabElements = [];
  const tabNodes = document.querySelectorAll("shiny-tab[name]");
  tabNodes.forEach((node) => {
    const tabName = node.attributes.getNamedItem("name")?.value;
    const tabIcon = node.attributes.getNamedItem("icon")?.value;
    if (!tabName) {
      return;
    }
    const tabLabel = node.querySelector("tab-label");
    tabElements.push({
      name: tabName,
      value: tabName.replaceAll(" ", "_"),
      el: node,
      label: tabLabel ?? x`
          <tab-label>
            ${tabIcon ? x`<shiny-icon name=${tabIcon}></shiny-icon>` : ""}
            ${tabName}
          </tab-label>
        `
    });
  });
  return tabElements;
}
function selectTabByIndex(tabs, index) {
  tabs.forEach((tab, i6) => {
    const isSelected = i6 === index;
    const currentlyHidden = tab.el.style.display === "none";
    const hidingTab = !currentlyHidden && !isSelected;
    if (hidingTab) {
      if (typeof $ !== "undefined") {
        $(tab.el).trigger("hidden");
      }
      tab.el.inert = true;
      tab.el.style.display = "none";
    }
    const showingTab = currentlyHidden && isSelected;
    if (showingTab) {
      if (typeof $ !== "undefined") {
        $(tab.el).trigger("shown");
      }
      tab.el.inert = false;
      tab.el.style.display = "block";
    }
  });
}

// src/shiny-section.ts
var Section = class extends s4 {
  constructor() {
    super(...arguments);
    this.icon = "";
  }
  render() {
    return x`<div class="icon">
        ${this.icon && x`<shiny-icon name=${this.icon}></shiny-icon>`}
        <slot name="icon"></slot>
      </div>
      <div class="content"><slot></slot></div>`;
  }
};
// Styles are scoped to this element: they won't conflict with styles
// on the main page or in other components. Styling API can be exposed
// via CSS custom properties.
Section.styles = i`
    :host {
      display: grid;
      align-items: center;
      grid-template-columns: var(--sidebar-content-columns, auto 1fr);
      gap: var(--sidebar-content-gap, var(--size-m));
      height: var(--sidebar-content-height, auto);
      padding-block: var(--padding, 100px);
    }

    * {
      box-sizing: border-box;
      min-width: 0;
    }

    [closed] :host {
      background-color: pink;
    }

    .icon {
      font-size: var(--size-l);
      text-align: center;
    }

    .content > ::slotted(h2) {
      margin: 0;
      padding-block: 0;
    }

    .content > ::slotted(*:last-child) {
      margin-bottom: 0 !important;
    }

    .content {
      overflow: var(--sidebar-content-overflow);
      display: flex;
      flex-direction: column;
      gap: var(--size-s);
    }
  `;
__decorateClass([
  n6()
], Section.prototype, "icon", 2);
Section = __decorateClass([
  e6("shiny-section")
], Section);

// src/sidebar.ts
var Sidebar = class extends s4 {
  constructor() {
    super();
    this.closed = false;
    this.openWidthPx = 320;
    this.collapseToIcons = false;
    this.inDashboard = false;
    setElAttr(this, "slot", "sidebar");
    this.addEventListener("click", (e9) => {
      if (!this.closed)
        return;
      this.toggleClosed();
    });
  }
  /**
   * Toggles the `closed` property on the sidebar which will be reflected in
   * styles.
   */
  toggleClosed() {
    this.closed = !this.closed;
  }
  /**
   * Handles the click event on the toggle button. This is a separate function
   * so that we can stop propagation of the event.
   * @param e - The click event.
   * @returns void
   */
  handleToggleBtnClick(e9) {
    e9.stopPropagation();
    this.toggleClosed();
  }
  /**
   * Recursively searches for the closest parent element that is a known container
   * for the sidebar.
   *
   * @param sidebar - The sidebar element to start the search from.
   * @returns The closest parent element that is a known container for the sidebar,
   * or `null` if no container is found.
   */
  findSidebarContainer(sidebar) {
    const parent = sidebar.parentElement;
    if (!parent) {
      return null;
    }
    if (parent instanceof ShinyDashboard) {
      this.inDashboard = true;
      return parent;
    }
    const parentIsContainer = Sidebar.allowedContainers.some(
      (p4) => parent instanceof p4
    );
    if (parentIsContainer) {
      return parent;
    }
    return this.findSidebarContainer(parent);
  }
  /**
   * Checks if the sidebar is in a small container and if so, automatically
   * collapses the sidebar to avoid it taking up too much space.
   */
  autoCollapseOnSmallScreens() {
    const container = this.findSidebarContainer(this);
    if (container && container.clientWidth < 700) {
      this.closed = true;
    }
  }
  /**
   * When the children of the sidebar change, we check if they are all
   * `<shiny-section>` elements. If they are, we collapse the sidebar to icons
   * on smaller screens.
   * @param e - The slotchange event.
   * @returns void
   */
  watchForIconSectionChildren(e9) {
    const elementsInSlot = getElementsFromSlotChangeEvent(e9);
    const hasOnlySections = elementsInSlot.every((el) => el instanceof Section);
    this.collapseToIcons = elementsInSlot.length > 0 && hasOnlySections;
  }
  connectedCallback() {
    super.connectedCallback();
    this.autoCollapseOnSmallScreens();
  }
  render() {
    return x`
      <div class="container ${this.inDashboard ? "dashboard-sidebar" : ""}">
        <div>
          <div
            class="toggle-icon"
            @click=${this.handleToggleBtnClick}
            title=${this.closed ? "Open sidebar" : "Close sidebar"}
          >
            <shiny-icon name="ri:expand-left-line"></shiny-icon>
          </div>
        </div>
        <div class="content" style="--sidebar-width: ${this.openWidthPx}px;">
          <slot @slotchange=${this.watchForIconSectionChildren}></slot>
        </div>
      </div>
    `;
  }
};
Sidebar.styles = i`
    * {
      box-sizing: border-box;
    }

    :host {
      /* How much padding is around the content and between items within the
      sidebar? This variable controls a lot of the visual appearance */
      --padding: var(--sidebar-padding, var(--size-m));

      /* Sizes related to the toggle icon */
      --toggle-size: var(--padding);
      --toggle-pad: calc(var(--padding) / 4);

      /* Internal calculated properties - change at your own risk! */
      --full-padded-w: calc(var(--toggle-size) + 2 * var(--toggle-pad));

      /* TODO: Use container query units here if available */
      --open-width: min(
        var(
          --sidebar-width,
          calc((var(--size-content-1) + var(--size-content-2)) / 2)
        ),
        calc(100vw - (3 * var(--padding)))
      );
      --closed-width: var(--full-padded-w);

      /* Animation for opening and closing */
      --transition: var(--speed-fast) var(--ease-3);

      /* All the variables that have "*-content-*" in their names are passed
      through to the <shiny-section> tag that lets it know how to control its
      content so that it can selectively hide or show the content associated
      with an icon or not. I don't like how confusing it is and think something
      like subgrid could help with this */
      --section-icon-w: var(--size-l);
      --sidebar-content-columns: var(--section-icon-w) 1fr;
      --sidebar-content-gap: var(--padding);

      height: 100%;
      display: flex;
      flex-direction: column;
      background-color: var(--sidebar-bg, var(--surface-1));
      width: var(--open-width);
      transition: width var(--transition), padding var(--transition);
    }

    :host([closed]) {
      width: var(--closed-width);
      cursor: e-resize;
      overflow: hidden;
    }

    /* Leave the sidebar wide enough to view the icons */
    :host([collapseToIcons]) {
      --closed-width: calc(var(--section-icon-w) + (2 * var(--padding)));
    }

    .content {
      height: 100%;
      overflow: auto;
      padding-inline: var(--padding);
      display: flex;
      flex-direction: column;
      background-color: inherit;
      width: var(--open-width);

      /* Move content up a bit so there's not an awkward amount of space before
      content starts */
      margin-top: calc(-2 * var(--toggle-pad));
      transition: opacity var(--transition);
    }

    /* For the normal sidebar collapse we want the opacity to go to zero when
    collapsed so the content doesn't show */
    :host([closed]:not([collapseToIcons])) .content {
      opacity: 0;
    }

    /* Styles for when the sidebar is in a very small container such as a card
    or mobile device */
    @container (max-width: 700px) {
      :host {
        width: var(--closed-width);
        z-index: 10;
      }

      .container {
        /* When on small screens we want the sidebar to slide over the main
        content rather than pushing it out of the way */
        position: absolute;
        background-color: inherit;
        width: var(--open-width);
        height: 100%;
        overflow: hidden;
        border-right: var(--border-standard);
      }

      .container.dashboard-sidebar {
        box-shadow: var(--shadow-l);
      }

      :host([closed]) .container {
        width: var(--closed-width);
      }
    }

    .content > ::slotted(shiny-section) {
      border-bottom: var(--border-normal);
    }

    .content > ::slotted(shiny-section:last-child) {
      border-bottom: none;
    }

    .toggle-icon {
      /* Resting state has a lower opacity to not make the toggle standout so
      much and distract from content */
      opacity: 0.5;
      font-size: var(--font-size-l);
      color: var(--text-3);
      cursor: pointer;
      user-select: none;

      /* Make sure we're always the same distance from the right of the sidebar
      when we're closed or open */
      margin-inline-start: auto;
      margin-inline-end: 0;
      width: var(--full-padded-w);
      height: var(--full-padded-w);
      padding: var(--toggle-pad);

      /* Make sure the icon itself is nice and centered */
      display: grid;
      place-content: center;

      /* We use a transform to flip icon to a collapse icon and also increase
      the opacity on hover, we animate these to look _cool_ */
      transition: transform var(--transition), opacity var(--transition);
    }

    /* Give feedback of action on hover */
    .toggle-icon:hover {
      opacity: 1;
    }

    /* When we're closed we invert the icon on the x-axis to make it an expand
    icon */
    :host([closed]) .toggle-icon {
      transform: scaleX(-1);
    }
  `;
/**
 * The list of elements that are allowed to be containers for the sidebar.
 * Currently, the known containers are `shiny-dashboard` and `shiny-card`. If
 * more containers are added in the future, this list will need to be updated
 * to generalize the search.
 * @static
 * @private
 * @memberof Sidebar
 * @readonly
 */
Sidebar.allowedContainers = [ShinyDashboard, ShinyCard];
__decorateClass([
  n6({ type: Boolean, reflect: true })
], Sidebar.prototype, "closed", 2);
__decorateClass([
  n6({ type: Number })
], Sidebar.prototype, "openWidthPx", 2);
__decorateClass([
  n6({ type: Boolean, reflect: true })
], Sidebar.prototype, "collapseToIcons", 2);
__decorateClass([
  t5()
], Sidebar.prototype, "inDashboard", 2);
Sidebar = __decorateClass([
  e6("shiny-sidebar")
], Sidebar);

// src/simple-number-input.ts
var SimpleNumberInput = class extends s4 {
  constructor() {
    super(...arguments);
    this.min = 0;
    this.max = 10;
    this.value = (this.min + this.max) / 2;
    this.invalid = false;
    this.onChangeCallback = (x5) => {
    };
    this.onValueChange = makeValueChangeEmitter(this, this.id);
  }
  static {
    this.properties = {
      min: { type: Number },
      max: { type: Number },
      value: { type: Number },
      invalid: { type: Boolean }
    };
  }
  static {
    this.styles = i`
    :host {
      --inline-padding: var(--number-input-padding-inline, var(--size-xs));
      --block-padding: var(--number-input-padding-block, var(--size-xs));

      font-size: var(--number-input-font-size, var(--font-size-3));
      position: relative;
      width: var(--number-input-width, fit-content);
      height: var(--number-input-height, fit-content);
    }

    .wrapper {
      display: inline-flex;
      background-color: var(
        --number-input-bg-color,
        var(--sl-input-background-color)
      );
      background-image: var(--number-input-bg-image);
      color: var(--number-input-text-color, var(--sl-input-color));
      border: none;
      border-radius: var(
        --number-input-border-radius,
        var(--sl-border-radius-pill)
      );
      outline: var(--number-input-border-width, var(--sl-input-border-width))
        solid var(--number-input-border-color, var(--sl-input-border-color));
      padding-inline: var(--inline-padding);
      padding-block: var(--block-padding);
    }

    .wrapper.invalid {
      outline-color: var(--warning);
    }

    input {
      font-size: inherit;
      border: none;
      background-color: transparent;
      color: inherit;
      outline-width: 0;
      text-align: center;
    }

    input:focus-visible {
      outline-width: 0;
    }

    /* Hide the number input's spin buttons */

    /* Chrome, Safari, Edge, Opera */
    input::-webkit-outer-spin-button,
    input::-webkit-inner-spin-button {
      -webkit-appearance: none;
      margin: 0;
    }

    /* Firefox */
    input[type="number"] {
      -moz-appearance: textfield;
    }

    .plusminus {
      font-size: inherit;
      border: var(--number-input-plusminus-border, none);
      background-color: transparent;
      color: inherit;
    }

    .plusminus:hover {
      cursor: pointer;
    }

    .plusminus.left {
      padding-inline-start: var(--inline-padding);
    }

    .plusminus.right {
      padding-inline-end: var(--inline-padding);
    }

    .validation-msg {
      position: absolute;

      /* margin-left: var(--space-x-small); */
      font-size: var(
        --number-input-warning-font-size,
        var(--sl-font-size-x-small)
      );
      top: calc(115%);
      color: var(--warning);
      transform: scaleX(0);
      transition: transform var(--sl-transition-fast) var(--ease-squish-2);
      transform-origin: left;
    }

    .wrapper.invalid .validation-msg {
      transform: scaleX(1);
    }
  `;
  }
  getInputElement() {
    return this.shadowRoot.querySelector("input");
  }
  handleMinus(e9) {
    const inputValue = this.getInputElement().valueAsNumber;
    let newValue;
    if (isNaN(inputValue)) {
      newValue = this.min;
    } else {
      newValue = clamp(inputValue - 1, this.min, this.max);
    }
    this.getInputElement().value = newValue.toString();
    this.value = newValue;
    this.invalid = false;
    this.alertOfChange();
  }
  handlePlus(e9) {
    const inputValue = this.getInputElement().valueAsNumber;
    let newValue;
    if (isNaN(inputValue)) {
      newValue = this.max;
    } else {
      newValue = clamp(inputValue + 1, this.min, this.max);
    }
    this.getInputElement().value = newValue.toString();
    this.value = newValue;
    this.invalid = false;
    this.alertOfChange();
  }
  handleChange(e9) {
    const inputValue = e9.target.valueAsNumber;
    const clampedValue = clamp(inputValue, this.min, this.max);
    if (clampedValue === inputValue) {
      this.value = clampedValue;
      this.invalid = false;
      this.alertOfChange();
    } else {
      this.invalid = true;
    }
  }
  alertOfChange() {
    this.onChangeCallback(true);
    this.onValueChange({ type: "number", value: this.value });
  }
  connectedCallback() {
    super.connectedCallback();
    setTimeout(() => {
      this.alertOfChange();
    }, 2);
  }
  render() {
    return x`
      <div class="wrapper ${this.invalid ? "invalid" : null}">
        <button
          part="minus-button"
          class="plusminus left"
          @mousedown=${this.handleMinus}
          @keydown=${(e9) => {
      if (e9.code === "Space")
        this.handleMinus(e9);
    }}
        >
          −</button
        ><input
          part="input"
          value=${this.value}
          min=${this.min}
          max=${this.max}
          @input=${this.handleChange}
          type="number"
        /><button
          part="plus-button"
          class="plusminus right"
          @mousedown=${this.handlePlus}
          @keydown=${(e9) => {
      if (e9.code === "Space")
        this.handlePlus(e9);
    }}
        >
          +
        </button>
        <span class="validation-msg"
          >Make sure your number is between ${this.min} and ${this.max}</span
        >
      </div>
    `;
  }
};
customElements.define("simple-number-input", SimpleNumberInput);
makeInputBinding("simple-number-input");
function clamp(x5, min, max) {
  return Math.max(Math.min(x5, max), min);
}

// src/simple-number-output.ts
var SimpleNumberOutput = class extends s4 {
  constructor() {
    super(...arguments);
    this.value = null;
    this.watch = "";
    this.watcher = dummyDataPassingWatcher;
  }
  static {
    this.properties = {
      value: { type: Number },
      watch: { type: String }
    };
  }
  connectedCallback() {
    super.connectedCallback();
    this.watcher = makeDataPassingWatcher(this.watch, (payload) => {
      if (payload.type !== "number") {
        console.error("Expected number, got", payload.value);
        return;
      }
      this.value = payload.value;
    });
  }
  static {
    this.styles = i`
    .value {
      display: block;
      font-size: var(--font-size-m);
      background-color: var(--surface-3);
    }
  `;
  }
  render() {
    return x` <div class="value">Your number is: ${this.value}</div> `;
  }
};
customElements.define("simple-number-output", SimpleNumberOutput);

// src/theme-chooser.ts
var themes = ["default", "light", "dark", "dim", "grape", "choco"];
var ThemeChooser = class extends s4 {
  constructor() {
    super();
    this.choice = themes[0];
    this.addEventListener("sl-change", this.handleChange);
  }
  handleChange(e9) {
    const radios = this.shadowRoot.querySelector("forge-input-radio-buttons");
    this.choice = radios.getValue();
    if (this.choice === "default") {
      delete document.documentElement.dataset["shinytheme"];
      return;
    }
    document.documentElement.dataset["shinytheme"] = this.choice;
  }
  render() {
    return x`
      <forge-input-radio-buttons
        choices=${JSON.stringify(themes)}
        selected="default"
        size="small"
        inline
        button
        pill
      >
      </forge-input-radio-buttons>
    `;
  }
};
ThemeChooser.styles = i`
    input {
      border-radius: var(--radius-s);
    }
  `;
__decorateClass([
  n6({ reflect: true })
], ThemeChooser.prototype, "choice", 2);
ThemeChooser = __decorateClass([
  e6("theme-chooser")
], ThemeChooser);
/*! Bundled license information:

react-is/cjs/react-is.development.js:
  (** @license React v16.13.1
   * react-is.development.js
   *
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

object-assign/index.js:
  (*
  object-assign
  (c) Sindre Sorhus
  @license MIT
  *)

@lit/reactive-element/css-tag.js:
  (**
   * @license
   * Copyright 2019 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/reactive-element.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

lit-html/lit-html.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

lit-element/lit-element.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

lit-html/is-server.js:
  (**
   * @license
   * Copyright 2022 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/decorators/custom-element.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/decorators/property.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/decorators/state.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/decorators/base.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/decorators/event-options.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/decorators/query.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/decorators/query-all.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/decorators/query-async.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/decorators/query-assigned-elements.js:
  (**
   * @license
   * Copyright 2021 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/decorators/query-assigned-nodes.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

iconify-icon/dist/iconify-icon.mjs:
  (**
  * (c) Iconify
  *
  * For the full copyright and license information, please view the license.txt
  * files at https://github.com/iconify/iconify
  *
  * Licensed under MIT.
  *
  * @license MIT
  * @version 1.0.7
  *)
*/
//# sourceMappingURL=components.js.map
